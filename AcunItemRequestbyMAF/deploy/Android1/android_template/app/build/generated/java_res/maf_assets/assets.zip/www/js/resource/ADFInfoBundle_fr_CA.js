/* Copyright (c) 2011, 2012, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ------------------- ADFInfoBundle_fr_CA.js ---------------------- */
/* ------------------------------------------------------ */
// AUTO-GENERATED FILE
// since this gets loaded programmatically, adf.mf.resource will already be defined

adf.mf.resource.ADFInfoBundle_fr_CA={
"WARN_SKIP_REMOTE_WRITE":"Java n\'est pas disponible. Nous devons donc ignorer l\'\u00e9criture distante.",
"LBL_CONFIRMATION_DISPLAY_STR":"Confirmation",
"WARN_MESSAGE_FOR_SELENIUM_TEST":"Message d\'\'avertissement pour le test de s\u00e9l\u00e9nium avec l\'\'argument : {0}",
"LBL_INFO_DISPLAY_STR":"Informations",
"WARN_JS_EL_PARSING_DEPRECATED":"L\'analyse de l\'expression EL dans JavaScript est obsol\u00e8te. \u00c9valuez les expressions EL du c\u00f4t\u00e9 int\u00e9gr\u00e9.",
"WARN_PROCESSING_REMOVE_DATA_CHANGE":"Un probl\u00e8me est survenu lors du traitement de la modification de donn\u00e9es (suppression)",
"LBL_OK_DISPLAY_STR":"OK",
"WARN_PROCESSING_UPDATE_DATA_CHANGE":"Un probl\u00e8me est survenu lors du traitement de la modification de donn\u00e9es (mise \u00e0 jour)",
"LBL_FATAL_DISPLAY_STR":"Erreur fatale",
"WARN_PROCESSING_CREATE_DATA_CHANGE":"Un probl\u00e8me est survenu lors du traitement de la modification de donn\u00e9es (cr\u00e9ation)",
"LBL_ERROR_DISPLAY_STR":"Erreur",
"WARN_PROCESSING_VAR_CHANGES":"Une erreur s\'est produite dans processDataChangeEvent lors du traitement des modifications de variable",
"LBL_WARNING_DISPLAY_STR":"Avertissement",
"WARN_COLLECTION_MODEL_NOT_FOUND":"Mod\u00e8le de collection introuvable",
"WARN_UNABLE_TO_FETCH_SET":"Impossible d\'extraire le jeu ",
"WARN_UPDATING_CACHE":"Un probl\u00e8me est survenu lors de la mise \u00e0 jour de la m\u00e9moire cache, ce qui a g\u00e9n\u00e9r\u00e9 un \u00e9v\u00e9nement de modification de donn\u00e9es.",
"WARN_PROCESSING_PROVIDER_CHANGES":"Une erreur s\'est produite dans processDataChangeEvent lors du traitement des modifications de fournisseur.",
"oracle.core.ojdl.logging.MessageIdKeyResourceBundle":""
}
