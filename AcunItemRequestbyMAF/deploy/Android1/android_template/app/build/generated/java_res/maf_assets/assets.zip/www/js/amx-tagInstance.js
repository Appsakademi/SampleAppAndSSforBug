/* Copyright (c) 2013, 2017, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ---------------- amx-tagInstance.js ------------------ */
/* ------------------------------------------------------ */

(function()
{
  var nextId = 0;
  var tagInstanceMap = {};

  /**
   * @namespace
   */
  adf.mf.internal.amx.AmxTagInstanceStates =
  {
    /** EL based attributes needed for rendering have not been fully loaded yet */
    "WAITING_ON_EL_EVALUATION": 0,
    /** EL attributes have been loaded, the node has not yet been rendered */
    "LOADED": 1
  };

  /**
   * Constructor for a tag instance. The tag instance represents a non-UI tag of an AMX
   * node and store node specific information. In the case of fragments, the tag instance
   * holds onto replaced EL strings that are specific to each individual node.
   *
   * @param {adf.mf.api.amx.AmxNode} parentAmxNode the AMX node that this tag instance
   *        belongs to
   * @param {adf.mf.internal.amx.AmxTagInstance} parentTagInstance the parent tag instance if
   *        nested
   * @param {adf.mf.api.amx.AmxTag} tag the refence to the tag for this instance
   * @param {Object} jsonData the data to initialize the tag instance when using the embedded
   *        side to build the node hierarchy
   * @constructor adf.mf.internal.amx.AmxTagInstance
   * @augments adf.mf.api.AdfObject
   */
  function AmxTagInstance(
    parentAmxNode,
    parentTagInstance,
    tag,
    jsonData)
  {
    this.Init(parentAmxNode, parentTagInstance, tag, jsonData);
  }

  adf.mf.internal.amx.AmxTagInstance = AmxTagInstance;
  adf.mf.api.AdfObject.createSubclass(adf.mf.internal.amx.AmxTagInstance, adf.mf.api.AdfObject,
    "adf.mf.internal.amx.AmxTagInstance");

  /**
   * Initialize the tag instance. This function will evaluate the EL expressions, storing the
   * cached values into the object so that the values may be retrieved later without EL
   * evaluation. It also sets up the EL dependencies that will be used for data change events
   * to ensure the cached values are kept up to date.
   *
   * @param {adf.mf.api.amx.AmxNode} parentAmxNode the AMX node that this tag instance
   *        belongs to
   * @param {adf.mf.internal.amx.AmxTagInstance} parentTagInstance the parent tag instance if
   *        nested
   * @param {adf.mf.api.amx.AmxTag} tag the refence to the tag for this instance
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.Init = function(
    parentAmxNode,
    parentTagInstance,
    tag,
    jsonData)
  {
    AmxTagInstance.superclass.Init.call(this);

    this._parentAmxNode = parentAmxNode;
    this._parentTagInstance = parentTagInstance;
    this._tag = tag;
    this._tagHandler = adf.mf.internal.amx.AmxTagHandler.__getHandler(
      tag.getNsPrefixedName());
    this._attributesWaitingOnEl = 0;
    this._attributeNamesWaitingOnEl = {};
    this._state = adf.mf.internal.amx.AmxTagInstanceStates["LOADED"];
    // Create a set of the attributes that have their values stored on the tag instance
    this._cachedAttributes = {};

    // A map of the local (cached) attribute values
    this._attrs = {};

    if (adf.mf.internal.amx._embeddedSideHandlingEnabled)
    {
      this._initFromJson(parentAmxNode, parentTagInstance, tag, jsonData);
    }
    else
    {
      this._initFromJavaScript(parentAmxNode, parentTagInstance, tag);
    }

    tagInstanceMap[this._id] = this;

    this._tagHandler.initializeTagInstance(this);

    this._children = [];

    if (parentTagInstance != null)
    {
      parentTagInstance._children.push(this);
    }
  };

  /**
   * Get the tag handler for this tag instance
   *
   * @return {adf.mf.internal.amx.AmxTagHandler} the tag handler
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.getTagHandler = function()
  {
    return this._tagHandler;
  };

  /**
   * Check if this tag instance represents a converter
   *
   * @return {boolean} true if this is a converter tag instance
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.isConverter = function()
  {
    return adf.mf.internal.amx["AmxConverterHandler"] != null &&
      this._tagHandler instanceof adf.mf.internal.amx.AmxConverterHandler;
  };

  /**
   * @return {adf.mf.api.amx.AmxNode} get the AMX node that this tag instance belongs to
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.getParentAmxNode = function()
  {
    return this._parentAmxNode;
  };

  /**
   * @return {(adf.mf.internal.amx.AmxTagInstance|null)} get the parent tag instance
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.getParentTagInstance = function()
  {
    return this._parentTagInstance;
  };

  /**
   * @return {adf.mf.api.amx.AmxTag} get the tag for this instance
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.getTag = function()
  {
    return this._tag;
  };

  /**
   * Get the unique identifier for this tag instance
   *
   * @return {string} the unique ID
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.getId = function()
  {
    return this._id;
  };

  /**
   * @param {(string|null)} namespace the namespace to filter the children by
   * @param {(string|null)} tagName the tag name to filter the children by (requires namespace to be
   *        provided)
   * @return {Array.<adf.mf.internal.amx.AmxTagInstance>} the children tag instances
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.getChildren = function(
    namespace,
    tagName)
  {
    var children = [];
    for (var i = 0, size = this._children.length; i < size; ++i)
    {
      var child = this._children[i];
      if (namespace != null)
      {
        var tag = child.getTag();
        if ((tagName != null && tagName != tag.getName()) ||
          namespace != tag.getNamespace())
        {
          continue;
        }
      }

      children.push(child);
    }
    return children;
  };

  /**
   * Get an EL expression for an attribute. For fragments, the EL expression will be already
   * replaced.
   *
   * @return {(ELExpression|null)} for EL bound attributes, returns the ELExpression of an attribute.
   *         Returns undefined for attributes that are not EL bound.
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.getAttributeExpression = function(name)
  {
    return this._elAttributeMap[name];
  };

  /**
   * Get an attribute value
   *
   * @param {string} name the name of the attribute to get the value
   * @param {boolean=} evaluateEl if not given, or true EL based attributes will be evaluated. If
   *        false, the EL string will be returned for EL based attributes.
   * @return {(Object|string)} returns the attribute value or the EL expression for the attribute.
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.getAttribute = function(
    name,
    evaluateEl)
  {
    // Default evaluateEl not being passed to a true value
    if (evaluateEl === undefined)
    {
      evaluateEl = true;
    }

    // Check to see if this is an attribute that has its value cached
    if (evaluateEl && this._cachedAttributes[name] == true)
    {
      return this._attrs[name];
    }

    if (adf.mf.internal.amx._embeddedSideHandlingEnabled)
    {
      return null;
    }
    else
    {
      var expr = this.getAttributeExpression(name);

      if (expr == null)
      {
        return this.getTag().getAttribute(name);
      }

      // If not evaluating the EL, return the expression
      return evaluateEl ? adf.mf.internal.amx.evaluateExpression(expr) : expr.getExpression();
    }
  };

  /**
   * Called from the node when a markNodeForUpdate call is being processed. This is
   * usually called as a result of a data change event.
   *
   * @param changes {adf.mf.internal.amx.AmxTagInstanceChanges} changes object
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.updateAttributes = function(
    changes)
  {
    var oldValues = {};
    var embedded = adf.mf.internal.amx._embeddedSideHandlingEnabled;
    var attributeNames = changes.getChangedAttributes();

    for (var a = 0, numAttrs = attributeNames.length; a < numAttrs; ++a)
    {
      var attrName = attributeNames[a];
      var oldValue = this._attrs[attrName];
      var newValue;

      if (embedded)
      {
        // When the embedded side is handling the changes, just use the value from the embedded side
        newValue = changes.getNewAttributeValue(attrName);
        this._attrs[attrName] = newValue;
        this._cachedAttributes[attrName] = true;
      }
      else if (this._cachedAttributes[attrName] == true)
      {
        var expr = this.getAttributeExpression(attrName);
        newValue = adf.mf.internal.amx.evaluateExpression(expr);

        oldValues[attrName] = oldValue;
        this._attrs[attrName] = newValue;

        if (newValue !== undefined && this._attributeNamesWaitingOnEl[attrName])
        {
          delete this._attributeNamesWaitingOnEl[attrName];

          if (--this._attributesWaitingOnEl == 0)
          {
            this._state = adf.mf.internal.amx.AmxTagInstanceStates["LOADED"];
          }
        }
      }

      // Notify the tag handler that a cached attribute's value has been changed
      this._tagHandler.attributeUpdated(this, attrName, oldValue, newValue);
    }
  };

  /**
   * Set a local value for an attribute on a tag instance. Allows type handlers and
   * tag instance handlers to store attributes on a tag instance
   *
   * @param {string} attributeName the name of the attribute
   * @param {Object} value the value to store. If undefined is passed, the attribute
   *        is removed from the cache
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.setAttribute = function(
    attributeName,
    value)
  {
    if (value === undefined)
    {
      delete this._cachedAttributes[attributeName];
      delete this._attrs[attributeName];
    }
    else
    {
      this._cachedAttributes[attributeName] = true;
      this._attrs[attributeName] = value;
    }
  };

  /**
   * Get the EL dependencies of this tag instance
   *
   * @return {adf.mf.internal.amx.AmxElDependencies} EL dependencies object
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.getElDependencies = function()
  {
    return this._elDependencies;
  };

  adf.mf.internal.amx.AmxTagInstance.prototype.getState = function()
  {
    return this._state;
  };

  /**
   * Method called when an AMX event is being fired. The callback will be invoked before and after the call
   * to the embedded side. The beforeEmbeddedCall attribute notifies on which side this method is being invoked.
   *
   * @param {string} amxEventType String that represents the event type that triggered the call
   * @param {Object} amxEvent The new AmxEvent being fired
   * @param {number} mode one of the adf.mf.internal.amx.AmxEventHandlingMode constants
   * @param {boolean} beforeEmbeddedCall true if this is the callback before the embedded call
   * @return {adf.mf.internal.BasePromise|null} a promise object or null. If a promise object is returned in the before
   *         callback, the code will wait for it to resolve successfully before invoking the event handling on
   *         the embedded side
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.handleAmxEvent = function(
    amxNode,
    amxEventType,
    amxEvent,
    mode,
    beforeEmbeddedCall)
  {
    return this._tagHandler.handleAmxEvent(this, amxNode, amxEventType, amxEvent, mode, beforeEmbeddedCall);
  };

  /**
   * Checks if this tag handler can handle the given event type
   *
   * @param {adf.mf.internal.amx.AmxTagInstance} tagInstance the tag instance
   * @param {string} amxEventType the event type to check
   * @return {boolean} true if this tag handler can handle the given event type
   */
  adf.mf.internal.amx.AmxTagInstance.prototype.handlesEventType = function(tagInstance, amxEventType)
  {
    var eventTypes = this._tagHandler.getHandledEventTypes(tagInstance);

    for (var t = 0, numTypes = eventTypes.length; t < numTypes; t++)
    {
      if (eventTypes[t] === amxEventType)
      {
        return true;
      }
    }

    return false;
  };

  adf.mf.internal.amx.AmxTagInstance.prototype.__removed = function()
  {
    delete tagInstanceMap[this._id];
  };

  /**
   * Initialize the tag instance. This function will evaluate the EL expressions, storing the
   * cached values into the object so that the values may be retrieved later without EL
   * evaluation. It also sets up the EL dependencies that will be used for data change events
   * to ensure the cached values are kept up to date.
   *
   * @param {adf.mf.api.amx.AmxNode} parentAmxNode the AMX node that this tag instance
   *        belongs to
   * @param {adf.mf.internal.amx.AmxTagInstance} parentTagInstance the parent tag instance if
   *        nested
   * @param {adf.mf.api.amx.AmxTag} tag the refence to the tag for this instance
   */
  adf.mf.internal.amx.AmxTagInstance.prototype._initFromJavaScript = function(
    parentAmxNode,
    parentTagInstance,
    tag)
  {
    AmxTagInstance.superclass.Init.call(this);

    this._elAttributeMap = {}; // maps string (attribute name) to ELExpression (attribute value)

    var attrs = tag.getAttributes();
    for (var attrName in attrs)
    {
      var value = attrs[attrName];

      if (attrName != "id" && adf.mf.api.amx.AmxTag.__isELExpression(value))
      {
        var elExpression = adf.mf.internal.el.parser.parse(value);
        var expr = adf.mf.api.amx.AmxNode.__performElSubstitutions(elExpression);
        this._elAttributeMap[attrName] = expr;

        if (this._tagHandler.shouldPrefetchAttribute(attrName, expr))
        {
          var value = adf.mf.internal.amx.evaluateExpression(expr);
          this._attrs[attrName] = value;
          this._cachedAttributes[attrName] = true;
          if (value === undefined)
          {
            this._state = adf.mf.internal.amx.AmxTagInstanceStates["WAITING_ON_EL_EVALUATION"];
            ++this._attributesWaitingOnEl;
            this._attributeNamesWaitingOnEl[attrName] = true;
          }
        }
      }
    }

    var id = attrs["id"];

    if (id == null)
    {
      id = "_autoTI" + nextId++;
    }

    this._id = parentAmxNode.getId() + ":" + id;
    this._elDependencies = new adf.mf.internal.amx.AmxElDependencies(this._elAttributeMap);
  };

  /**
   * Initialize the tag instance from a JSON object created by the embedded side
   *
   * @param {adf.mf.api.amx.AmxNode} parentAmxNode the AMX node that this tag instance
   *        belongs to
   * @param {adf.mf.internal.amx.AmxTagInstance} parentTagInstance the parent tag instance if
   *        nested
   * @param {adf.mf.api.amx.AmxTag} tag the refence to the tag for this instance
   */
  adf.mf.internal.amx.AmxTagInstance.prototype._initFromJson = function(
    parentAmxNode,
    parentTagInstance,
    tag,
    jsonData)
  {
    var jsonAttrs = jsonData["attrs"];

    this._state = adf.mf.internal.amx.AmxTagInstanceStates["LOADED"];
    this._id = jsonData["id"];
    this._elAttributeMap = {};

    for (var attrName in jsonAttrs)
    {
      this._attrs[attrName] = jsonAttrs[attrName];
      this._cachedAttributes[attrName] = true;
    }
  };

  /**
   * Find a tag instance by its ID
   *
   * @param {string} id the ID
   * @return {adf.mf.internal.amx.AmxTagInstance|null} the tag instance if found
   */
  adf.mf.internal.amx.AmxTagInstance.__getById = function(id)
  {
    return tagInstanceMap[id];
  };

  /**
   * Creates a tag instance from JSON sent by the embedded side
   * @param {adf.mf.api.amx.AmxNode} parentAmxNode the AMX node that this tag instance
   *        belongs to
   * @param {adf.mf.internal.amx.AmxTagInstance} parentTagInstance the parent tag instance if
   *        nested
   * @param {adf.mf.api.amx.AmxTag} tag the tag for the tag instance
   * @param {Object} tagInstanceJson the JSON from the embedded side
   */
  adf.mf.internal.amx.AmxTagInstance.__fromJson = function(
    parentAmxNode,
    parentTagInstance,
    tag,
    tagInstanceJson)
  {
    var tagInstance = new AmxTagInstance(parentAmxNode, parentTagInstance, tag, tagInstanceJson);

    parentAmxNode.__tagInstanceCreated(tagInstance);

    var children = tagInstanceJson["children"];

    if (children != null)
    {
      for (var c = 0, numChildren = children.length; c < numChildren; c++)
      {
        var childJson = children[c];
        var childTag = adf.mf.api.amx.AmxTag.__getTagByUid(childJson["tag"]);

        adf.mf.internal.amx.AmxTagInstance.__fromJson(amxNode, tagInstance, chilTag, childJson);
      }
    }

    return tagInstance;
  };
})();
