/* Copyright (c) 2011, 2012, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ------------------- ADFInfoBundle_cs.js ---------------------- */
/* ------------------------------------------------------ */
// AUTO-GENERATED FILE
// since this gets loaded programmatically, adf.mf.resource will already be defined

adf.mf.resource.ADFInfoBundle_cs={
"WARN_SKIP_REMOTE_WRITE":"Proto\u017ee java nen\u00ed dostupn\u00e1, p\u0159esko\u010d\u00edme vzd\u00e1len\u00e9 zapisov\u00e1n\u00ed.",
"LBL_CONFIRMATION_DISPLAY_STR":"Potvrzen\u00ed",
"WARN_MESSAGE_FOR_SELENIUM_TEST":"Varovn\u00e1 zpr\u00e1va pro test Selenium s argumentem: {0}",
"LBL_INFO_DISPLAY_STR":"Informace",
"WARN_JS_EL_PARSING_DEPRECATED":"Syntaktick\u00e1 anal\u00fdza EL v JavaScript byla odm\u00edtnuta. Pou\u017eijte vyhodnocen\u00ed EL ve vlo\u017een\u00e9 stran\u011b.",
"WARN_PROCESSING_REMOVE_DATA_CHANGE":"Vyskytl se probl\u00e9m p\u0159i zpracov\u00e1n\u00ed zm\u011bny dat (odebr\u00e1n\u00ed)",
"LBL_OK_DISPLAY_STR":"OK",
"WARN_PROCESSING_UPDATE_DATA_CHANGE":"Vyskytl se probl\u00e9m p\u0159i zpracov\u00e1n\u00ed zm\u011bny dat (aktualizace)",
"LBL_FATAL_DISPLAY_STR":"Kritick\u00e1",
"WARN_PROCESSING_CREATE_DATA_CHANGE":"Vyskytl se probl\u00e9m p\u0159i zpracov\u00e1n\u00ed zm\u011bny dat (vytvo\u0159en\u00ed)",
"LBL_ERROR_DISPLAY_STR":"Chyba",
"WARN_PROCESSING_VAR_CHANGES":"Chyba v processDataChangeEvent p\u0159i zpracov\u00e1n\u00ed zm\u011bn prom\u011bnn\u00e9",
"LBL_WARNING_DISPLAY_STR":"Varov\u00e1n\u00ed",
"WARN_COLLECTION_MODEL_NOT_FOUND":"Selhalo vyhled\u00e1n\u00ed modelu kolekce",
"WARN_UNABLE_TO_FETCH_SET":"Nelze na\u010d\u00edst sadu",
"WARN_UPDATING_CACHE":"Vyskytl se probl\u00e9m p\u0159i aktualizaci pam\u011bti cache v d\u016fsledku ud\u00e1losti zm\u011bny dat.",
"WARN_PROCESSING_PROVIDER_CHANGES":"Chyba v processDataChangeEvent p\u0159i zpracov\u00e1n\u00ed zm\u011bn poskytovatele.",
"oracle.core.ojdl.logging.MessageIdKeyResourceBundle":""
}
