/* Copyright (c) 2013, 2017 Oracle and/or its affiliates. All rights reserved. */
/*
 *    geoMap/DvtGeographicMap.js
 */
(function()
{
  var DvtGeographicMap = function(callback, callbackObj)
  {
    this.Init(callback, callbackObj);
  };

  adf.mf.internal.dvt.DvtmObject.createSubclass(DvtGeographicMap, 'adf.mf.internal.dvt.DvtmObject', 'adf.mf.internal.dvt.geomap.DvtGeographicMap');

  /** @private */
  // TODO change to supported map providers
  DvtGeographicMap.MAP_VIEWER_URL = 'https://elocation.oracle.com/mapviewer';
  DvtGeographicMap.ELOCATION_BASE_URL = 'https://elocation.oracle.com/elocation';

  DvtGeographicMap.BASE_MAP = 'ELOCATION_MERCATOR.WORLD_MAP';
  DvtGeographicMap.DEFAULT_PROVIDER = 'googlemaps';

  DvtGeographicMap.RENDERERS = {};

  DvtGeographicMap.prototype.Init = function(callback, callbackObj)
  {
    this._callback = callback;
    this._callbackObj = callbackObj;
    // by default, use google map as the provider
    this.mapProvider = DvtGeographicMap.DEFAULT_PROVIDER;
    this.mapViewerUrl = DvtGeographicMap.MAP_VIEWER_URL;
    this.eLocationUrl = DvtGeographicMap.ELOCATION_BASE_URL;
    this.baseMap = DvtGeographicMap.BASE_MAP;
    this.selection = [];
    this.initialSelectionApplied = false;// apply selectedRowKeys on a new instance only
    this.screenReaderMode = false;
  };

  /**
   * Returns a new instance of DvtGeographicMap.
   * @param {string} callback The function that should be called to dispatch component events.
   * @param {object} callbackObj The optional object instance on which the callback function is defined.
   * @param {object} options The object containing options specifications for this component.
   * @return {DvtGeographicMap}
   */
  DvtGeographicMap.newInstance = function(callback, callbackObj, options)
  {
    var map = new DvtGeographicMap(callback, callbackObj);
    map.setOptions(options);
    return map;
  };

  /**
   * Returns the map provider
   * @return {string}
   */
  DvtGeographicMap.prototype.getMapProvider = function()
  {
    return this.mapProvider;
  };

  /**
   * Specifies the map provider
   * @param {string} provider The map provider.
   */
  DvtGeographicMap.prototype.setMapProvider = function(provider)
  {
    // TODO change to supported map providers
    if (DvtGeographicMap.RENDERERS[provider])
    {
      this.mapProvider = provider;
    }
  };

  /**
   * Returns the map viewer url
   * @return {string}
   */
  DvtGeographicMap.prototype.getMapViewerUrl = function()
  {
    return this.mapViewerUrl;
  };

  DvtGeographicMap.prototype.getELocationUrl = function()
  {
    return this.eLocationUrl;
  };

  /**
   * Specifies the map viewer url
   * @param {string} mapViewerUrl The map viewer url
   */
  DvtGeographicMap.prototype.setMapViewerUrl = function(url)
  {
    if (url)
    {
      this.mapViewerUrl = url;
    }
  };

  DvtGeographicMap.prototype.setELocationUrl = function(url)
  {
    if (url)
    {
      this.eLocationUrl = url;
    }
  };
  /**
   * Returns the base map
   * @return {string}
   */
  DvtGeographicMap.prototype.getBaseMap = function()
  {
    return this.baseMap;
  };

  /**
   * Specifies the base map for oracle maps
   * @param {string} baseMap The base map
   */
  DvtGeographicMap.prototype.setBaseMap = function(baseMap)
  {
    if (baseMap)
    {
      this.baseMap = baseMap;
    }
  };

  /**
   * Specifies the non-data options for this component.
   * @param {object} options The object containing options specifications for this component.
   * @protected
   */
  DvtGeographicMap.prototype.setOptions = function(options)
  {
    this.Options = DvtGeographicMapDefaults.calcOptions(options);
  };

  /**
   * Returns the screenReaderMode
   * @return {boolean}
   */
  DvtGeographicMap.prototype.getScreenReaderMode = function()
  {
    return this.screenReaderMode;
  };

  /**
   * Set the screen reader mode
   * @param {boolean} mode
   */
  DvtGeographicMap.prototype.setScreenReaderMode = function(mode)
  {
    this.screenReaderMode = mode;
  };

  /**
   * Dispatches the event to the callback function.
   * @param {object} event The event to be dispatched.
   */
  DvtGeographicMap.prototype.dispatchEvent = function(event)
  {
    if (!this._callback)
    {
      return;
    }
    else if (this._callback && this._callback.call)
    {
      this._callback.call(this._callbackObj, event, this);
    }
  };

  DvtGeographicMap.prototype.loadApi = function (configuration, success, failure)
  {
    var mapProvider = this.getMapProvider();
    var renderer = DvtGeographicMap.RENDERERS[mapProvider];
    if (renderer && adf.mf.internal.amx.implementsFunction(renderer, "loadApi"))
    {
      renderer.loadApi(configuration, success, failure);
    }
  };

  /**
   * Renders the component with the specified data.  If no data is supplied to a component
   * that has already been rendered, the component will be rerendered to the specified size.
   * @param {object} mapCanvas The div to render the map.
   * @param {object} data The object containing data for this component.
   * @param {number} width The width of the component.
   * @param {number} height The height of the component.
   */
  DvtGeographicMap.prototype.render = function(mapCanvas, data, width, height)
  {
    if (data)
    {
      this.Data = data;
    }
    this._width = width;
    this._height = height;

    var mapProvider = this.getMapProvider();
    var renderer = DvtGeographicMap.RENDERERS[mapProvider];
    if (renderer)
    {
      renderer.render(this, mapCanvas, width, height);
    }
  };

  DvtGeographicMap.prototype.destroy = function()
  {
    var mapProvider = this.getMapProvider();
    var renderer = DvtGeographicMap.RENDERERS[mapProvider];
    if (renderer)
    {
      renderer.destroy(this);
    }
  };

  /**
   * Updates the map center position. This method only delegates to 
   * the underlying DVT map renderer instance.
   * 
   * @param {string} centerX - new center x position
   * @param {string} centerY - new center y position
   */
  DvtGeographicMap.prototype.moveCenter = function (centerX, centerY)
  {
    var mapProvider = this.getMapProvider();
    var renderer = DvtGeographicMap.RENDERERS[mapProvider];
    if (renderer)
    {
      renderer.moveCenter(this, centerX, centerY);
    }
  };

  /**
   * Updates zoom level. This method only delegates to the underlying 
   * DVT map renderer instance.
   * 
   * @param {string} zoomLevel - new zoom level
   */ 
  DvtGeographicMap.prototype.updateZoomLevel = function (zoomLevel)
  {
    var mapProvider = this.getMapProvider();
    var renderer = DvtGeographicMap.RENDERERS[mapProvider];
    if (renderer)
    {
      renderer.updateZoomLevel(this, zoomLevel);
    }
  };

  /**
   * Allows to register custom map provider or replace current one with
   * custom JS. Please note that this provider has to solve issues with
   * loading of external libraries independently 
   */
  DvtGeographicMap.registerMapProvider = function(name, clazz)
  {
    DvtGeographicMap.RENDERERS[name.toLowerCase()] = new clazz();
  }

  /**
   * Default values and utility functions for chart versioning.
   * @class
   */
  var DvtGeographicMapDefaults = function()
  {};

  adf.mf.internal.dvt.DvtmObject.createSubclass(DvtGeographicMapDefaults, 'adf.mf.internal.dvt.DvtmObject', 'DvtGeographicMapDefaults', 'PRIVATE');

  /**
   * Defaults for version 1.
   */
  DvtGeographicMapDefaults.VERSION_1 =
    {
      'mapOptions':
      {
        'mapType' : 'ROADMAP',
        'zoomLevel' : '14',
        'centerX' : '-98.57',
        'centerY' : '39.82'
      }
    };

  /**
   * Combines the user options with the defaults for the specified version.  Returns the
   * combined options object.  This object will contain internal attribute values and
   * should be accessed in internal code only.
   * @param {object} userOptions The object containing options specifications for this component.
   * @return {object} The combined options object.
   */
  DvtGeographicMapDefaults.calcOptions = function(userOptions)
  {
    var defaults = DvtGeographicMapDefaults._getDefaults(userOptions);

    // Use defaults if no overrides specified
    if (!userOptions)
    {
      return defaults;
    }
    // add flag to identify if the zoom level is defined
    // in user options or not
    // this is needed during initial zooming
    var explicitZoom = userOptions['mapOptions']['zoomLevel'] ? true : false;
    // Merge the options object with the defaults
    var merged = adf.mf.internal.dvt.util.JSONUtils.mergeObjects(userOptions, defaults);
    merged['mapOptions']['explicitZoom'] = explicitZoom;

    return merged;
  };

  /**
   * Returns the default options object for the specified version of the component.
   * @param {object} userOptions The object containing options specifications for this component.
   * @private
   */
  DvtGeographicMapDefaults._getDefaults = function(userOptions)
  {
    // Note: Version checking will eventually get added here
    // Note: Future defaults objects are deltas on top of previous objects
    return adf.mf.internal.dvt.util.JSONUtils.cloneObject(DvtGeographicMapDefaults.VERSION_1);
  };
})();
/* Copyright (c) 2013, 2017, Oracle and/or its affiliates. All rights reserved. */
/*
 *    geoMap/GeographicMapRenderer.js
 */
(function ()
{
  var AttributeProcessor = adf.mf.internal.dvt.AttributeProcessor;
  var DOMUtils = adf.mf.internal.dvt.DOMUtils;
  var ImageProcessor = adf.mf.internal.dvt.ImageProcessor;

  var GeographicMapRenderer = function ()
  {
    this._configuration = null;
    this._googleApiLoaded = null;
    this._oracleMVApiLoaded = null;

    this._waitingNodes = [];
  };

  adf.mf.internal.dvt.DvtmObject.createSubclass(GeographicMapRenderer, 'adf.mf.internal.dvt.BaseComponentRenderer', 'adf.mf.internal.dvt.geomap.GeographicMapRenderer');
  
  GeographicMapRenderer.prototype.loadResources = function (amxNode) {
    // nothing to do here
  };

  GeographicMapRenderer.prototype.createChildrenNodes = function (amxNode)
  {
    if (this._configuration === null)
    {
      this._waitingNodes.push(amxNode);
      amxNode.setAttributeResolvedValue("_configuration", "waiting");

      this._loadConfiguration(
        function (config)
        {
          var args = new adf.mf.api.amx.AmxNodeUpdateArguments();
          var renderer = this;

          this._waitingNodes.forEach(function (node)
          {
            renderer._mapConfigurationToAmxNode(node, config);

            args.setAffectedAttribute(node, "_configuration");
          });

          this._waitingNodes.length = 0;
          adf.mf.api.amx.markNodeForUpdate(args);
        },
        function ()
        {
          // error
          var args = new adf.mf.api.amx.AmxNodeUpdateArguments();

          this._waitingNodes.forEach(function (node)
          {
            node.setAttributeResolvedValue("_configuration", "failure");
            args.setAffectedAttribute(node, "_configuration");
          });

          this._waitingNodes.length = 0;
          adf.mf.api.amx.markNodeForUpdate(args);
        });

      return adf.mf.api.amx.AmxNodeCreateChildrenNodesResult["HANDLED"];
    }

    this._mapConfigurationToAmxNode(amxNode, this._configuration);
    // let the framework create children
    return adf.mf.api.amx.AmxNodeCreateChildrenNodesResult["NONE"];
  };

  GeographicMapRenderer.prototype._mapConfigurationToAmxNode = function(amxNode, config)
  {
    amxNode.setAttributeResolvedValue("_configuration", "success");

    amxNode.setAttributeResolvedValue("_networkAvailable", config["networkStatus"] !== "NotReachable");
    amxNode.setAttributeResolvedValue("_mapProvider", config["mapProvider"]);
    amxNode.setAttributeResolvedValue("_mapViewerUrl", config["mapViewerUrl"]);
    amxNode.setAttributeResolvedValue("_eLocationUrl", config["eLocationUrl"]);
    amxNode.setAttributeResolvedValue("_enableXMLHTTP", adf.mf.api.amx.isValueTrue(config["enableXMLHTTP"]));
    amxNode.setAttributeResolvedValue("_proxyUrl", config["proxyUrl"]);
    amxNode.setAttributeResolvedValue("_baseMap", config["baseMap"]);
    amxNode.setAttributeResolvedValue("_geoMapClientId", config["geoMapClientId"]);
    amxNode.setAttributeResolvedValue("_geoMapKey", config["geoMapKey"]);
    amxNode.setAttributeResolvedValue("_accessibilityEnabled", adf.mf.api.amx.isValueTrue(config["accessibilityEnabled"]));
    amxNode.setAttributeResolvedValue("_apiVersion", config["apiVersion"]);
  };

  var _createApiLoadCallback = function(waitingNodes, state)
  {
    return function ()
    {
      var args = new adf.mf.api.amx.AmxNodeUpdateArguments();
      waitingNodes.forEach(function (node)
      {
        node.setAttributeResolvedValue("_apiLoaded", state);
        args.setAffectedAttribute(node, "_apiLoaded");
      });
      //
      waitingNodes.length = 0;
      //
      adf.mf.api.amx.markNodeForUpdate(args);
    };
  };

  GeographicMapRenderer.prototype._loadApi = function(rootElement, amxNode)
  {
    amxNode.setAttributeResolvedValue("_apiLoaded", "waiting");
    this._waitingNodes.push(amxNode);

    var instance = this.GetComponentInstance(rootElement, amxNode);
    instance.loadApi({
      'geoMapKey': amxNode.getAttribute('_geoMapKey'),
      'geoMapClientId': amxNode.getAttribute('_geoMapClientId'),
      'mapViewerUrl': amxNode.getAttribute('_mapViewerUrl'),
      'eLocationUrl': amxNode.getAttribute('_eLocationUrl'),
      'proxyUrl': amxNode.getAttribute('_proxyUrl'),
      'apiVersion': amxNode.getAttribute('_apiVersion')
    },
    _createApiLoadCallback(this._waitingNodes, "success"),
    _createApiLoadCallback(this._waitingNodes, "failure"));
  };

  GeographicMapRenderer.prototype.handleChanges = function (amxNode, attributeChanges)
  {
    if (attributeChanges.hasChanged("_configuration")
      && amxNode.getAttribute("_configuration") === "success")
    {
      return adf.mf.api.amx.AmxNodeChangeResult['REPLACE'];
    }

    if (attributeChanges.hasChanged("_configuration")
      && amxNode.getAttribute("_configuration") === "reload")
    {
      this._configuration = null;
      return adf.mf.api.amx.AmxNodeChangeResult['REPLACE'];
    }

    return adf.mf.api.amx.AmxNodeChangeResult['REFRESH'];
  };

  GeographicMapRenderer.prototype.getDescendentChangeAction = function (amxNode, descendentChanges)
  {
    descendentChanges.getAffectedNodes().forEach(function(node)
    {
      var changes = descendentChanges.getChanges(node);
      if (changes.hasChanged("selectedRowKeys") || changes.hasChanged("dataSelection"))
      {
        var userSelection = amxNode.getAttribute('__userselection') || {};
        delete userSelection[node.getId()];
        amxNode.setAttributeResolvedValue('__userselection', userSelection);
      }
    });
    return GeographicMapRenderer.superclass.getDescendentChangeAction.call(this, amxNode, descendentChanges);
  };

  GeographicMapRenderer.prototype.RefreshComponent = function (amxNode, attributeChanges, descendentChanges)
  {
    amxNode['_dataObj'] =
    {
      'dataLayers' : {},
      'routes' : [],
      'mapOptions' : {}
    };

    GeographicMapRenderer.superclass.RefreshComponent.call(this, amxNode, attributeChanges, descendentChanges)
  };

  GeographicMapRenderer.prototype._loadConfiguration = function (success, error)
  {
    if (this._isLoading === true)
    {
      return;
    }

    this._isLoading = true;

    var map =
    {
      "#{deviceScope.hardware.networkStatus}" : "networkStatus", // NotReachable
      "#{applicationScope.configuration.mapProvider}" : "mapProvider", //toLowerCase
      "#{applicationScope.configuration.geoMapKey}" : "geoMapKey",
      "#{applicationScope.configuration.geoMapClientId}" : "geoMapClientId",
      "#{applicationScope.configuration.mapViewerUrl}" : "mapViewerUrl",
      "#{applicationScope.configuration.eLocationUrl}" : "eLocationUrl",
      "#{applicationScope.configuration.proxyUrl}" : "proxyUrl",
      "#{applicationScope.configuration.enableXMLHTTP}" : "enableXMLHTTP", // boolean
      "#{applicationScope.configuration.baseMap}" : "baseMap",
      "#{applicationScope.configuration.accessibilityEnabled}" : "accessibilityEnabled", // bolean
      "#{applicationScope.configuration.apiVersion}" : "apiVersion"
    };

    var renderer = this;
    var els = Object.keys(map);

    this._configuration = null;

    if (adf.mf.internal.isJavaAvailable())
    {
      var scb = function (request, response)
      {
        var _configuration = {};
        var _dataChangeListener = function(result)
        {
          var expression = result.getExpression();
          var dcvalue = adf.mf.el.getLocalValue(expression);
          if (dcvalue && dcvalue[".null"] === true)
          {
            dcvalue = null;
          }
          // set new configuration value and continue without notification
          // of the nodes currently rendered
          if (renderer._configuration)
          {
            var name = map[expression];
            if (name === "mapProvider" && dcvalue)
            {
              dcvalue = dcvalue.toLowerCase();
            }
            renderer._configuration[name] = dcvalue;
          }
        };

        response.forEach(function (item)
        {
          var name = map[item.name];
          var value = item.value;
          if (value && value[".null"] === true)
          {
            value = null;
          }

          if (name === "mapProvider" && value)
          {
            value = value.toLowerCase();
          }

          _configuration[name] = value;
          // register listener to listen for configuration changes
          adf.mf.api.addDataChangeListeners(item.name, _dataChangeListener);
        });

        renderer._configuration = _configuration;
        renderer._isLoading = false;

        success.call(renderer, _configuration);
      };

      var ecb = function (request, response)
      {
        renderer._configuration = null;
        error.call(renderer);
        renderer._isLoading = false;
      };

      // ask backend for the fresh configuration
      adf.mf.el.getValue(els, scb, ecb);
    }
    else
    {
      this._configuration = {};
      // try to get configuration from local cache
      els.forEach(function (expression)
      {
        var name = map[expression];
        var value = adf.mf.el.getLocalValue(expression);
        if (value && value[".null"] === true)
        {
          value = null;
        }

        if (name === "mapProvider" && value)
        {
          value = value.toLowerCase();
        }
        renderer._configuration[name] = value;
      });

      this._isLoading = false;
      success.call(this, this._configuration);
    }
  };


  // create the DVT API namespace
  adf.mf.internal.dvt.DvtmObject.createPackage('adf.mf.api.dvt');

  /*
   * GeoMap event objects
   */

  /**
   * An event for map view property changes in DvtGeographicMap.
   * The event object is passed to the handler specified
   * in the mapBoundsChangeListener attribute.
   * See also the Java API oracle.adfmf.amx.event.MapBoundsChangeEvent.
   * @param {Object} minX minimum x coordinate (longitude) of map view
   * @param {Object} minY minimum y coordinate (latitude) of map view
   * @param {Object} maxX maximum x coordinate (longitude) of map view
   * @param {Object} maxY maximum y coordinate (latitude) of map view
   * @param {Object} centerX x coordinate (longitude) of map center
   * @param {Object} centerY y coordinate (latitude) of map center
   * @param {Number} zoomLevel current zoom level
   */
  adf.mf.api.dvt.MapBoundsChangeEvent = function (minX, minY, maxX, maxY, centerX, centerY, zoomLevel)
  {
    this.minX = minX;
    this.minY = minY;
    this.maxX = maxX;
    this.maxY = maxY;
    this.centerX = centerX;
    this.centerY = centerY;
    this.zoomLevel = zoomLevel;
    this[".type"] = "oracle.adfmf.amx.event.MapBoundsChangeEvent";
  };

  /**
   * An event fired when a click/tap, mousedown/up event occurs in DvtGeographicMap.
   * The event object is passed to the handler specified in the mapInputListener attribute.
   * Event properties include x/y coordinates (longitude/latitude) of the location where
   * the click/tap occurred and the event type id -- 'click', 'mousedown', 'mouseup'.
   * See also the Java API oracle.adfmf.amx.event.MapInputEvent.
   * @param {String} type event type id
   * @param {Object} pointX x coordinate (longitude) of the click point
   * @param {Object} pointY y coordinate (latitude) of the click point
   */
  adf.mf.api.dvt.MapInputEvent = function (type, pointX, pointY)
  {
    this.type = type;
    this.pointX = pointX;
    this.pointY = pointY;
    this[".type"] = "oracle.adfmf.amx.event.MapInputEvent";
  };

  GeographicMapRenderer.prototype.GetStyleClassesDefinition = function ()
  {
    var styleClasses = GeographicMapRenderer.superclass.GetStyleClassesDefinition.call(this);

    styleClasses['_self'] =
    {
      'path' : 'background-color', 'type' : adf.mf.internal.dvt.StyleProcessor['BACKGROUND']
    };

    return styleClasses;
  };

  GeographicMapRenderer.prototype.InitComponentOptions = function (amxNode, options)
  {
    GeographicMapRenderer.superclass.InitComponentOptions.call(this, amxNode, options)

    options['mapOptions'] = {};

    amxNode['_dataObj'] =
    {
      'dataLayers' : {},
      'routes' : [],
      'mapOptions' : {}
    };
  };

  GeographicMapRenderer.prototype.GetAttributesDefinition = function ()
  {
    var attrs = GeographicMapRenderer.superclass.GetAttributesDefinition.call(this);

    attrs['mapType'] = {'path' : 'mapOptions/mapType', 'type' : AttributeProcessor['TEXT']};
    attrs['currentCity'] = {'path' : 'mapOptions/currentCity', 'type' : AttributeProcessor['TEXT']};
    attrs['centerX'] = {'path' : 'mapOptions/centerX', 'type' : AttributeProcessor['FLOAT']};
    attrs['centerY'] = {'path' : 'mapOptions/centerY', 'type' : AttributeProcessor['FLOAT']};
    attrs['zoomLevel'] = {'path' : 'mapOptions/zoomLevel', 'type' : AttributeProcessor['INTEGER']};
    attrs['initialZooming'] = {'path' : 'mapOptions/initialZooming', 'type' : AttributeProcessor['TEXT'], 'default' : 'auto'};
    attrs['animationOnDisplay'] = {'path' : 'mapOptions/animationOnDisplay', 'type' : AttributeProcessor['TEXT']};
    attrs['shortDesc'] = {'path' : 'mapOptions/shortDesc', 'type' : AttributeProcessor['TEXT']};

    return attrs;
  };

  /**
   * Function processes supported attributes which are on amxNode. This attributes
   * should be converted into the options object.
   *
   * @param options main component options object
   * @param amxNode child amxNode
   * @param context rendering context
   */
  GeographicMapRenderer.prototype.ProcessAttributes = function (options, amxNode, context)
  {
    var changed = GeographicMapRenderer.superclass.ProcessAttributes.call(this, options, amxNode, context);
    // if refreshing existing map, turn off initial zoom and onDisplay animation
    var renderer = this;

    var routeCondition = function (n)
    {
      if (n.isAttributeDefined('rendered') && adf.mf.api.amx.isValueFalse(n.getAttribute('rendered')))
      {
        return false;
      }
      return "route" === n.getTag().getName();
    };

    var markerCondition = function (n)
    {
      if (n.isAttributeDefined('rendered') && adf.mf.api.amx.isValueFalse(n.getAttribute('rendered')))
      {
        return false;
      }
      return "marker" === n.getTag().getName();
    };

    var routePointCreator = function (waypointNode, index)
    {
      var position =
      {
        'id' : waypointNode.getId(),
        'x' : waypointNode.getAttribute('pointX'),
        'y' : waypointNode.getAttribute('pointY'),
        'address' : waypointNode.getAttribute('address'),
        '_rowKey' : '' + (index + 1),
        'displayMarker' : false
      };
      var markerNode = null;
      var list = waypointNode.getChildren();
      for (var i = 0;i < list.length;i++)
      {
        if (markerCondition.call(list, list[i]))
        {
          markerNode = list[i];
          break;
        }
      }
      // not supported on older versions
      // var markerNode = waypointNode.getChildren().find(markerCondition);
      if (markerNode)
      {
        if (markerNode.isAttributeDefined('rendered') && adf.mf.api.amx.isValueFalse(markerNode.getAttribute('rendered')))
        {
          return position;
        }
        position['displayMarker'] = true;
        renderer.processGeographicMapDataItem(null, position, markerNode);
      }

      return position;
    };

    var routeNodes = this.filterArray(amxNode.getChildren(), routeCondition);

    amxNode['_dataObj']['routes'] = routeNodes.map(function (routeNode)
    {
      var result =
      {
        'id' : routeNode.getId(), 'style' :
        {
          'default' :
          {
            'color' : routeNode.getAttribute("lineColor"), 'width' : routeNode.getAttribute("lineWidth"), 'opacity' : routeNode.getAttribute("lineOpacity")
          }
        },
        'travelMode' : routeNode.getAttribute("travelMode"), 'wayPoints' : routeNode.getRenderedChildren().map(routePointCreator)
      };

      if (renderer._hasAction(routeNode))
      {
        result['action'] = result['id'];
      }
      return result;
    });

    options['mapOptions']['hasMapInputActionListener'] = amxNode.isAttributeDefined('mapInputListener');
    options['mapOptions']['hasMapBoundsChangeActionListener'] = amxNode.isAttributeDefined('mapBoundsChangeListener');

    return changed;
  };

  /**
   * Sets the geographic map properties found on the amxNode
   * @param options main component options object
   * @param amxNode child amxNode
   * @param context rendering context
   */
  GeographicMapRenderer.prototype.ProcessChildren = function (options, amxNode, context)
  {
    return this.processGeographicMapPointDataLayerTags(context['amxNode'], amxNode, true);
  };

  GeographicMapRenderer.prototype.ProcessEvent = function(amxNode, event, component)
  {
    GeographicMapRenderer.superclass.ProcessEvent.call(this, amxNode, event, component);
    var renderer = this;
    // fire the selectionChange event
    var type = event.getType ? event.getType() : event['type'];
    var itemNode = null;

    if (type === "selection")
    {
      var userSelection = amxNode.getAttribute('__userselection') || {};
      var dataLayerId = event.getParamValue('dataLayerId');
      if (dataLayerId)
      {
        itemNode = this.findAmxNode(amxNode, dataLayerId);

        var selection = event.getSelection();
        selection = selection.map(function(item)
        {
          return item["rowKey"];
        });

        // filter all removed keys
        var removedKeys = this.filterArray(userSelection[dataLayerId], function(key)
        {
          return selection.indexOf(key) === -1;
        });

        var se = new adf.mf.api.amx.SelectionEvent(removedKeys, selection);

        userSelection[dataLayerId] = selection;

        amxNode.setAttributeResolvedValue('__userselection', userSelection);

        adf.mf.api.amx.processAmxEvent(itemNode, 'selection', undefined, undefined, se, null);
      }
      else
      {
        var oldSelections = userSelection;
        userSelection = {};
        amxNode.setAttributeResolvedValue('__userselection', userSelection);
        // component is deselecting all rowkeys in all layers so iterate through all previous
        // layers and trigger selection event
        var dataLayerIds = Object.keys(oldSelections);
        dataLayerIds.forEach(function(dlId)
        {
          itemNode = renderer.findAmxNode(amxNode, dlId);
          se = new adf.mf.api.amx.SelectionEvent(oldSelections[dlId], []);

          adf.mf.api.amx.processAmxEvent(itemNode, 'selection', undefined, undefined, se, null);
        });
      }
    }
    else if (type === "action")
    {
      itemNode = renderer.findAmxNode(amxNode, event.getClientId());

      if (itemNode)
      {
        // marker node found, fire event and handle action
        var point = event.getParamValue('pointXY');
        if (point)
        {
          var markerDiv = document.getElementById(itemNode.getId());
          if (!markerDiv)
          {
            var canvasId = amxNode.getId() + '_canvas';
            var canvas = document.getElementById(canvasId);
            markerDiv = DOMUtils.createDIV();
            DOMUtils.writeIDAttribute(markerDiv, itemNode.getId());
            DOMUtils.writeStyleAttribute(markerDiv, "position: absolute; width:1px; height:1px;");
            canvas.appendChild(markerDiv);
          }
          markerDiv.style.cssText += 'top:' + (point.y - 2) + 'px;' + 'left:' + (point.x + 1) + 'px;';
        }

        var actionEvent = new adf.mf.api.amx.ActionEvent();
        var actionType = event.getParamValue('actionType') || 'click';
        var callback = function() {/*default callback without any action*/};

        // toolkit returns action types click and tapHold. AMX layer
        // however supports action and tapHold events so it is necessary to
        // translate click to action.
        if (actionType === 'click')
        {
          actionType = 'action';
          // in case and only in case of action event we want to perform navigation
          callback = function()
          {
            // action callback which is able to invoke navigation
            var action = itemNode.getAttributeExpression("action", true);
            if (action != null)
            {
              adf.mf.api.amx.doNavigation(action);
            }
          };
        }

        adf.mf.api.amx.processAmxEvent(itemNode, actionType, undefined, undefined, actionEvent, callback);
      }
    }
    else if (type === "mapinput" && amxNode.isAttributeDefined('mapInputListener'))
    {
      var mie = new adf.mf.api.dvt.MapInputEvent(event.getEventId(), event.getPointX(), event.getPointY());
      adf.mf.api.amx.processAmxEvent(amxNode, 'mapInput', undefined, undefined, mie);
    }
    else if (type === 'mapboundschange' && amxNode.isAttributeDefined('mapBoundsChangeListener'))
    {
      var mbce = new adf.mf.api.dvt.MapBoundsChangeEvent(event.getMinX(), event.getMinY(), event.getMaxX(), event.getMaxY(), event.getCenterX(), event.getCenterY(), event.getZoomLevel());
      adf.mf.api.amx.processAmxEvent(amxNode, 'mapBoundsChange', undefined, undefined, mbce);
    }
  };

  GeographicMapRenderer.prototype.CreateComponentInstance = function (simpleNode, amxNode)
  {
    var callbackObj = this.CreateComponentCallback(amxNode);
    if (!callbackObj)
    {
      callbackObj = null;
    }

    var callback = (callbackObj === null) ? null : callbackObj['callback'];

    var instance = adf.mf.internal.dvt.geomap.DvtGeographicMap.newInstance(callback, callbackObj, this.GetDataObject(amxNode));

    instance.setMapProvider(amxNode.getAttribute("_mapProvider"));
    instance.setMapViewerUrl(amxNode.getAttribute("_mapViewerUrl"));
    instance.setELocationUrl(amxNode.getAttribute("_eLocationUrl"));
    instance.setBaseMap(amxNode.getAttribute("_baseMap"));
    instance.setScreenReaderMode(amxNode.getAttribute("_accessibilityEnabled"));

    return instance;
  };

  /**
   * sets up chart's outer div element
   *
   * @param amxNode
   */
  GeographicMapRenderer.prototype.SetupComponent = function (amxNode)
  {
    var contentDiv = GeographicMapRenderer.superclass.SetupComponent.call(this, amxNode);

    var canvasDiv = DOMUtils.createDIV();
    var id = amxNode.getId() + '_canvas';
    DOMUtils.writeIDAttribute(canvasDiv, id);
    DOMUtils.writeStyleAttribute(canvasDiv, 'width: 100%; height: 100%;');
    contentDiv.appendChild(canvasDiv);
    contentDiv.setAttribute('role', 'application');

    if (adf.mf.environment.profile.dtMode)
    {
      var readonly = document.createElement("div");
      readonly.className = "dvtm-readonly";
      contentDiv.appendChild(readonly);
    }
    return contentDiv;
  };

  GeographicMapRenderer.prototype._checkAndRenderWarning = function(amxNode, name)
  {
    switch(amxNode.getAttribute(name))
    {
      case "success":
        return true;
      case "failure":
        this._renderReloadPage(amxNode, amxNode.getId() + '_canvas');
        return false;
      case "waiting":
        default:
        this._renderPlaceholder(amxNode.getId() + '_canvas');
        return false;
    }
  };

  GeographicMapRenderer.prototype.postDisplay = function (rootElement, amxNode)
  {
    if (this.IsAncestor(document.body, rootElement))
    {
      this.GetComponentDimensions(rootElement, amxNode);
    }

    // render reload button when api is not available
    if (!this.isEmbeddedSideMaintainingHierarchy() && !this._checkAndRenderWarning(amxNode, "_configuration"))
    {
      return;
    }
    // render reload button when network is not available
    if (amxNode.getAttribute("_networkAvailable") === false)
    {
      this._renderReloadPage(amxNode, amxNode.getId() + '_canvas');
      return;
    }

    if (!this._checkAndRenderWarning(amxNode, "_apiLoaded"))
    {
      this._loadApi(rootElement, amxNode);
      return;
    }

    if (this.__isReadyToRender(amxNode) === false)
    {
      this._renderPlaceholder(amxNode.getId() + '_canvas');
      return;
    }

    GeographicMapRenderer.superclass.postDisplay.call(this, rootElement, amxNode);
  };

  GeographicMapRenderer.prototype.refresh = function(amxNode, attributeChanges, descendentChanges)
  {
    if (attributeChanges.hasChanged("inlineStyle"))
    {
      var element = document.getElementById(amxNode.getId());
      element.setAttribute("style", amxNode.getAttribute("inlineStyle"));
    }
    // render reload button when network is not available
    if (amxNode.getAttribute("_networkAvailable") === false)
    {
      this._renderReloadPage(amxNode, amxNode.getId() + '_canvas');
      return;
    }

    // check if center and/or zoomLevel are the only changed attributes
    // there will be no need to re-render the whole map then
    var simpleAttrChangeCount = 0;
    if (attributeChanges.hasChanged('centerX'))
    {
      simpleAttrChangeCount++;
    }
    if (attributeChanges.hasChanged('centerY'))
    {
      simpleAttrChangeCount++;
    }
    if (attributeChanges.hasChanged('zoomLevel'))
    {
      simpleAttrChangeCount++;
    }

    if (!this._checkAndRenderWarning(amxNode, "_apiLoaded"))
    {
      return;
    }

    // call real refresh only of needed
    if (this.__isReadyToRender(amxNode) && (descendentChanges || simpleAttrChangeCount !== attributeChanges.getSize()))
    {
      GeographicMapRenderer.superclass.refresh.call(this, amxNode, attributeChanges, descendentChanges);
    }
    
    // adjust the map position of center and/or zoomLevel attributes changed
    var simpleNode = document.getElementById(amxNode.getId());
    var instance = this.GetComponentInstance(simpleNode, amxNode);

    if (attributeChanges.hasChanged('centerX') || attributeChanges.hasChanged('centerY'))
    {
      instance.moveCenter(amxNode.getAttribute('centerX'), amxNode.getAttribute('centerY'));
    }

    if (attributeChanges.hasChanged('zoomLevel'))
    {
      instance.updateZoomLevel(amxNode.getAttribute('zoomLevel'));
    }   
  };

  GeographicMapRenderer.prototype.__isReadyToRender = function(amxNode)
  {
    if (!this.isEmbeddedSideMaintainingHierarchy())
    {
      return true;
    }

    var ready = true;
    amxNode.visitChildren(new adf.mf.api.amx.VisitContext(), function (visitContext, anode)
    {
      if (anode.isAttributeDefined('rendered') && adf.mf.api.amx.isValueFalse(anode.getAttribute('rendered')))
      {
        return adf.mf.api.amx.VisitResult['REJECT'];
      }

      if (anode.getTag().getName() === "pointDataLayer")
      {
        if (anode.isAttributeDefined("value"))
        {
          var items = anode.getAttribute("value");
          if (items === undefined)
          {
            ready = false;
            return adf.mf.api.amx.VisitResult['COMPLETE'];
          }

          if (items && items.treeNodeBindings)
          {
            var iter = adf.mf.api.amx.createIterator(items);
            if (iter.getTotalCount() > iter.getAvailableCount())
            {
              ready = false;
              return adf.mf.api.amx.VisitResult['COMPLETE'];
            }
          }
        }

        return adf.mf.api.amx.VisitResult['REJECT'];
      }
      return adf.mf.api.amx.VisitResult['ACCEPT'];
    });

    return ready;
  };

  GeographicMapRenderer.prototype.RenderComponent = function (instance, width, height, amxNode)
  {
    var mapCanvas = document.getElementById(amxNode.getId() + '_canvas');
    // everything is ok and we can rendere the map itself
    var options = this.GetDataObject(amxNode);

    // set options to project any changes to the map instance
    instance.setOptions(options);
    instance.render(mapCanvas, amxNode['_dataObj'], width, height);
  };

  GeographicMapRenderer.prototype._renderPlaceholder = function(canvasId)
  {
    var mapCanvas = document.getElementById(canvasId);
    adf.mf.api.amx.emptyHtmlElement(mapCanvas);

    var placeholder = document.createElement("div");
    placeholder.id = canvasId + "_placeholder";
    placeholder.className = "dvtm-component-placeholder amx-deferred-loading";

    var msgLoading = adf.mf.resource.getInfoString("AMXInfoBundle", "MSG_LOADING");
    placeholder.setAttribute("aria-label", msgLoading);

    mapCanvas.appendChild(placeholder);
  };

  GeographicMapRenderer.prototype._renderReloadPage = function(amxNode, canvasId)
  {
    var mapCanvas = document.getElementById(canvasId);
    adf.mf.api.amx.emptyHtmlElement(mapCanvas);

    var reloadDiv = document.createElement("div");
    reloadDiv.classList.add("dvtm-geographicMap-loadPage");

    var innerDiv = document.createElement("div");

    var label = document.createElement("div");
    label.appendChild(document.createTextNode(adf.mf.resource.getInfoString("AMXInfoBundle","dvtm_geographicMap_FAILED_LOAD_API")));
    innerDiv.appendChild(label);

    var button = document.createElement("div");
    button.setAttribute("tabindex", "0");
    label = document.createElement("label");
    label.classList.add("amx-commandButton-label");
    label.appendChild(document.createTextNode(adf.mf.resource.getInfoString("AMXInfoBundle","dvtm_geographicMap_RELOAD_BUTTON_LABEL")));
    button.appendChild(label);

    // Adding WAI-ARIA Attribute to the markup for the role attribute
    button.setAttribute("role", "button");
    button.classList.add("amx-node", "amx-commandButton");

    adf.mf.api.amx.addBubbleEventListener(button, 'tap', function (event)
    {
      var args = new adf.mf.api.amx.AmxNodeUpdateArguments();

      amxNode.setAttributeResolvedValue("_configuration", "reload");
      args.setAffectedAttribute(amxNode, "_configuration");

      adf.mf.api.amx.emptyHtmlElement(document.getElementById(canvasId));
      adf.mf.api.amx.markNodeForUpdate(args);
    });

    innerDiv.appendChild(button);

    reloadDiv.appendChild(innerDiv);

    mapCanvas.appendChild(reloadDiv);
    mapCanvas = null;
  };

  /**
   * Process the point data layer tag
   */
  GeographicMapRenderer.prototype.processGeographicMapPointDataLayerTags = function (amxNode, node, setMapProp)
  {
    var data = amxNode['_dataObj'];

    var children = node.getChildren();
    var iter = adf.mf.api.amx.createIterator(children);

    while (iter.hasNext())
    {
      var pointDataLayerNode = iter.next();

      if (pointDataLayerNode.isAttributeDefined('rendered') && adf.mf.api.amx.isValueFalse(pointDataLayerNode.getAttribute('rendered')))
        continue;

      // accept only dvtm:pointDataLayer nodes
      if (pointDataLayerNode.getTag().getName() !== 'pointDataLayer')
      {
        continue;
      }
      var idx = iter.getRowKey();
      var dataLayer = data['dataLayers'] [idx];
      if (!dataLayer) 
      {
        dataLayer = {
          idx: idx
        };
        data['dataLayers'] [idx] = dataLayer;
      }
      this.processSingleGeographicMapPointDataLayerTag(amxNode, pointDataLayerNode, dataLayer);
    }
  };

  GeographicMapRenderer.prototype.processSingleGeographicMapPointDataLayerTag = function (amxNode, pointDataLayerNode, dataLayer)
  {
    var attr;

    attr = pointDataLayerNode.getId();
    if (attr)
      dataLayer['id'] = attr;

    attr = pointDataLayerNode.getAttribute('animationOnDuration');
    if (attr)
      dataLayer['animationOnDuration'] = attr;

    attr = pointDataLayerNode.getAttribute('animationOnDataChange');
    if (attr)
      dataLayer['animationOnDataChange'] = attr;

    var strSelections = "";
    var k;
    var userSelection = amxNode.getAttribute('__userselection');
    userSelection = userSelection || {};
    var selection = userSelection[pointDataLayerNode.getId()];

    if (selection)
    {
      for (k = 0;k < selection.length;k++)
      {
        if (k)
          strSelections += " ";
        strSelections += selection[k];
      }
      dataLayer['selectedRowKeys'] = strSelections;
    }
    else
    {
      attr = pointDataLayerNode.getAttribute('selectedRowKeys');
      if (attr)
      {
        // geomap renderer currently expects selected rowkeys as a space-separated string
        // TODO: fix this when the renderer accepts an array
        var arSelections = AttributeProcessor['ROWKEYARRAY'](attr);
        if (arSelections && arSelections.length > 0)
        {
          for (k = 0;k < arSelections.length;k++)
          {
            if (k)
              strSelections += " ";
            strSelections += arSelections[k];
          }
        }
        dataLayer['selectedRowKeys'] = strSelections;

        userSelection[pointDataLayerNode.getId()] = arSelections;
        amxNode.setAttributeResolvedValue('__userselection', userSelection);
      }
    }
    attr = pointDataLayerNode.getAttribute('dataSelection');
    if (attr)
      dataLayer['dataSelection'] = attr;

    attr = pointDataLayerNode.getAttribute('emptyText');
    if (attr)
      dataLayer['emptyText'] = attr;

    this.processGeographicMapPointLocationTag(amxNode, dataLayer, pointDataLayerNode);
  };

  GeographicMapRenderer.prototype.processGeographicMapPointLocationTag = function (amxNode, dataLayer, pointDataLayerNode)
  {
    var varName = pointDataLayerNode.getAttribute('var');
    var value = pointDataLayerNode.getAttribute('value');

    if (adf.mf.environment.profile.dtMode && value && value.replace(/\s+/g, '').indexOf('#{') >  - 1)
    {
      return;
    }

    if (value)
    {
      // collection is available so iterate through data and process each pointLocation
      var iter = adf.mf.api.amx.createIterator(value);
      while (iter.hasNext())
      {
        iter.next();
        var children = pointDataLayerNode.getChildren(null, iter.getRowKey());

        // iteration through all child elements
        var iter2 = adf.mf.api.amx.createIterator(children);
        while (iter2.hasNext())
        {
          var pointLocNode = iter2.next();
          var rowKey = iter.getRowKey();
          // process each location node
          this._processGeographicMapPointLocation(amxNode, dataLayer, pointLocNode, rowKey);
        }
      }
    }
    else
    {
      // collection does not exist so iterate only through child tags
      // and resolve them without var context variable
      var tagChildren = pointDataLayerNode.getChildren();
      var childTagIterator = adf.mf.api.amx.createIterator(tagChildren);

      while (childTagIterator.hasNext())
      {
        var tagPointLocNode = childTagIterator.next();
        var tagRowKey = "" + (childTagIterator.getRowKey() + 1);
        // process each location node
        this._processGeographicMapPointLocation(amxNode, dataLayer, tagPointLocNode, tagRowKey);
      }
    }
  };

  GeographicMapRenderer.prototype._processGeographicMapPointLocation = function (amxNode, dataLayer, pointLocNode, rowKey)
  {
    // accept dvtm:pointLocation only
    if (pointLocNode.getTag().getName() !== 'pointLocation')
    {
      return;
    }

    if (pointLocNode.isAttributeDefined('rendered') && adf.mf.api.amx.isValueFalse(pointLocNode.getAttribute('rendered')))
    {
      return;
    }

    if (!dataLayer['data'])
      dataLayer['data'] = {};
    
    var data = dataLayer['data'] [pointLocNode.getId ()];
    if (!data)
    {
      data = {};
      dataLayer['data'] [pointLocNode.getId ()] = data;
    }
    
    if (pointLocNode.isAttributeDefined('type'))
    {
      data['type'] = pointLocNode.getAttribute('type');
    }
    if (pointLocNode.isAttributeDefined('pointX') && pointLocNode.isAttributeDefined('pointY'))
    {
      var x = parseFloat (pointLocNode.getAttribute('pointX'));
      var y = parseFloat (pointLocNode.getAttribute('pointY'));
      if (x !== NaN && y !== NaN)
      {
        data['x'] = x;
        data['y'] = y;
      }
    }
    else if (pointLocNode.isAttributeDefined('address'))
    {
      data['address'] = pointLocNode.getAttribute('address');
    }

    var markerNodes = pointLocNode.getChildren();
    for (var i = 0; i < markerNodes.length; i++)
    {
      var node = markerNodes [i];
      if (node.getTag().getName() === 'marker')
      {
        data['_rowKey'] = rowKey;
        this.processGeographicMapDataItem(amxNode, data, node);
      }
    }
  };

  GeographicMapRenderer.prototype.processGeographicMapDataItem = function (amxNode, data, dataNode)
  {
    // First check if this data item should be rendered at all
    if (dataNode.isAttributeDefined('rendered') && adf.mf.api.amx.isValueFalse(dataNode.getAttribute('rendered')))
    {
      data['renderMarker'] = false;
      return;
    }
    data['renderMarker'] = true;

    if (dataNode.isAttributeDefined('source'))
      ImageProcessor.processImageDataUri(amxNode, dataNode, data, "source");

    if (dataNode.isAttributeDefined('sourceHover'))
      ImageProcessor.processImageDataUri(amxNode, dataNode, data, "sourceHover");
  
    if (dataNode.isAttributeDefined('sourceSelected'))
      ImageProcessor.processImageDataUri(amxNode, dataNode, data, "sourceSelected");
   
    if (dataNode.isAttributeDefined('sourceHoverSelected'))
      ImageProcessor.processImageDataUri(amxNode, dataNode, data, "sourceHoverSelected");

    if (dataNode.isAttributeDefined('shortDesc'))
      data['shortDesc'] = dataNode.getAttribute('shortDesc');

    if (dataNode.getAttribute('labelDisplay') === "on")
    {
      if (dataNode.isAttributeDefined('value'))
        data['label'] = dataNode.getAttribute('value');

      if (dataNode.isAttributeDefined('labelPosition'))
        data['labelPosition'] = dataNode.getAttribute('labelPosition');

      if (dataNode.isAttributeDefined('labelStyle'))
        data['labelStyle'] = dataNode.getAttribute('labelStyle');

      if (dataNode.isAttributeDefined('selectedLabelStyle'))
        data['selectedLabelStyle'] = dataNode.getAttribute('selectedLabelStyle');
    } 
    else 
    {
      data['label'] = null;
    }

    if (dataNode.isAttributeDefined('markerIconDisplay'))
      data['markerIconDisplay'] = dataNode.getAttribute('markerIconDisplay');
    else
      data['markerIconDisplay'] = "auto";

    if (dataNode.isAttributeDefined('width'))
      data['width'] = +dataNode.getAttribute('width');

    if (dataNode.isAttributeDefined('height'))
      data['height'] = +dataNode.getAttribute('height');

    if (dataNode.isAttributeDefined('scaleX'))
      data['scaleX'] = +dataNode.getAttribute('scaleX');

    if (dataNode.isAttributeDefined('scaleY'))
      data['scaleY'] = +dataNode.getAttribute('scaleY');

    if (dataNode.isAttributeDefined('rotation'))
      data['rotation'] = +dataNode.getAttribute('rotation');

    if (dataNode.isAttributeDefined('opacity'))
      data['opacity'] = +dataNode.getAttribute('opacity');

    data['clientId'] = dataNode.getId();

    if (this._hasAction(dataNode))
    {
      data['action'] = data['_rowKey'];
    }
    else
    {
      data['action'] = null;
    }
  };

  GeographicMapRenderer.prototype._hasAction = function (amxNode)
  {
    if (amxNode.isAttributeDefined('action'))
    {
      return true;
    }
    else
    {
      var actionTags;
      // should fire action, if there are any 'setPropertyListener' or 'showPopupBehavior' child tags
      actionTags = amxNode.getTag().findTags(adf.mf.internal.dvt.AMX_NAMESPACE, 'setPropertyListener');
      if (actionTags.length > 0)
        return true;

      actionTags = amxNode.getTag().findTags(adf.mf.internal.dvt.AMX_NAMESPACE, 'showPopupBehavior');
      if (actionTags.length > 0)
        return true;

      actionTags = amxNode.getTag().findTags(adf.mf.internal.dvt.AMX_NAMESPACE, 'closePopupBehavior');
        if (actionTags.length > 0)
          return true;

      actionTags = amxNode.getTag().findTags(adf.mf.internal.dvt.AMX_NAMESPACE, 'actionListener');
      if (actionTags.length > 0)
        return true;

      actionTags = amxNode.getTag().findTags(adf.mf.internal.dvt.AMX_NAMESPACE, 'clientListener');
      if (actionTags.length > 0)
        return true;

      return false;
    }
  };
  
  GeographicMapRenderer.prototype.getAutomation = function(amxNode)
  {
    var automation = new Object();
    automation['_amxNode'] = amxNode;
    automation['getRawOptions'] = function ()
    {
      return this['_amxNode'].getAttribute('_optionsObj');
    };
    return automation;
  };

  adf.mf.api.amx.TypeHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_DVTM, 'geographicMap', GeographicMapRenderer);
})();
/* Copyright (c) 2013, 2017 Oracle and/or its affiliates. All rights reserved. */
/*
 *    geoMap/events/DvtBaseComponentEvent.js
 */
(function()
{
  /**
   * Base class for component level events.
   * @class The base class for component level events.
   * @constructor
   * @export
   */
  var DvtBaseComponentEvent = function()
  { };

  adf.mf.internal.dvt.DvtmObject.createSubclass(DvtBaseComponentEvent, 'adf.mf.internal.dvt.DvtmObject', 'adf.mf.internal.dvt.geomap.events.DvtBaseComponentEvent');

  DvtBaseComponentEvent.CLIENT_ROW_KEY = 'clientRowKey';

  /**
   * @param {string} type The event type for this event.
   * @protected
   */
  DvtBaseComponentEvent.prototype.Init = function(type) {
    this._type = type;
    this['type'] = type;
  };

  /**
   * Returns the event type for this event.
   * @return {string} The event type for this event.
   * @export
   */
  DvtBaseComponentEvent.prototype.getType = function() {
    return this._type;
  };

  /**
   * Return a list of additional parameter keys
   * @return {array} paramKeys additional parameter keys
   */
  DvtBaseComponentEvent.prototype.getParamKeys = function() {
    return this._paramKeys;
  };

  /**
   * Return a list of additional parameter values
   * @return {array} paramValues additional parameter values
   */
  DvtBaseComponentEvent.prototype._getParamValues = function() {
    return this._paramValues;
  };

  /**
   * Add an additional parameter (key, value) to this event (ex clientRowKey)
   * @param {String} paramKey parameter key
   * @param {String} paramValue parameter value
   */
  DvtBaseComponentEvent.prototype.addParam = function(paramKey, paramValue) {
    if (!this._paramKeys) {
      this._paramKeys = [];
      this._paramValues = [];
    }

    this._paramKeys.push(paramKey);
    this._paramValues.push(paramValue);
  };

  /**
   * Get parameter value in this event
   * @param {String} paramKey parameter key
   * @return {String} paramValue parameter value
   * @export
   */
  DvtBaseComponentEvent.prototype.getParamValue = function(paramKey) {
    if (!paramKey || !this._paramKeys || !this._paramValues) {
      return null;
    }

    var index = - 1;
    for (var i = 0; i < this._paramKeys.length; i++) {
      if (this._paramKeys[i] == paramKey) {
        index = i;
        break;
      }
    }

    if (index != - 1) {
      return this._paramValues[index];
    }

    return null;
  };
})();
/* Copyright (c) 2013, 2017 Oracle and/or its affiliates. All rights reserved. */
/*
 *    geoMap/events/DvtGeoMapSelectionEvent.js
 */
(function()
{
  /**
   * A component level selection event.
   * @param {array} selection The array of currently selected ids for the component.
   * @class
   * @constructor
   * @export
   */
  var DvtGeoMapSelectionEvent = function(selection) {
    this.Init(selection);
  };

  adf.mf.internal.dvt.DvtmObject.createSubclass(DvtGeoMapSelectionEvent, 'adf.mf.internal.dvt.geomap.events.DvtBaseComponentEvent', 'adf.mf.internal.dvt.geomap.events.DvtGeoMapSelectionEvent');

  /**
   * @export
   */
  DvtGeoMapSelectionEvent.TYPE = 'selection';

  /**
   * @param {array} selection The array of currently selected ids for the component.
   * @param {string} [type] DvtGeoMapSelectionEvent.TYPE if none specified.
   * @override
   */
  DvtGeoMapSelectionEvent.prototype.Init = function(selection) {
    DvtGeoMapSelectionEvent.superclass.Init.call(this, DvtGeoMapSelectionEvent.TYPE);
    this._selection = selection;
  };

  /**
   * Returns the array of currently selected ids for the component.
   * @return {array} The array of currently selected ids for the component.
   * @export
   */
  DvtGeoMapSelectionEvent.prototype.getSelection = function() {
    return this._selection;
  };
})();
/* Copyright (c) 2013, 2017 Oracle and/or its affiliates. All rights reserved. */
/*
 *    geoMap/events/DvtMapActionEvent.js
 */
(function()
{
  /**
   * Map action event.
   * @param {string} [clientId] The client id associated with this action event.
   * @param {string} [rowKey] The rowKey for the object associated with this event.
   * @param {string} [action] The action name.
   * @class
   * @constructor
   * @export
   */
  var DvtMapActionEvent = function(clientId, rowKey, action) {
    this.Init(DvtMapActionEvent.TYPE);
    this._clientId = clientId;
    this._rowKey = rowKey;
    this._action = action;
  };

  adf.mf.internal.dvt.DvtmObject.createSubclass(DvtMapActionEvent, 'adf.mf.internal.dvt.geomap.events.DvtBaseComponentEvent', 'adf.mf.internal.dvt.geomap.events.DvtMapActionEvent');
  /**
   * @export
   */
  DvtMapActionEvent.TYPE = 'action';

  /**
   * Returns the clientId associated with this event.
   * @return {string} clientId.
   * @export
   */
  DvtMapActionEvent.prototype.getClientId = function() {
    return this._clientId;
  };

  /**
   * Returns the rowKey of the object associated with this event.
   * @return {string} rowKey.
   * @export
   */
  DvtMapActionEvent.prototype.getRowKey = function() {
    return this._rowKey;
  };

  /**
   * Returns the action name.
   * @return {string} action.
   * @export
   */
  DvtMapActionEvent.prototype.getAction = function() {
    return this._action;
  };
})();
/* Copyright (c) 2013, 2017 Oracle and/or its affiliates. All rights reserved. */
/*
 *    geoMap/events/DvtMapBoundsChangeEvent.js
 */
(function()
{
  /**
   * Map bounds change event.
   * @param {number} [minX] minimum x bounds coordinate (longitude).
   * @param {number} [minY] minimum y bounds coordinate (latitude).
   * @param {number} [maxX] maximum x bounds coordinate (longitude).
   * @param {number} [maxY] maximum y bounds coordinate (latitude).
   * @param {number} [centerX] x coordinate (longitude) of map center.
   * @param {number} [centerY] y coordinate (latitude) of map center.
   * @param {number} [zoomLevel] zoom level.
   * @class
   * @constructor
   * @export
   */
  var DvtMapBoundsChangeEvent = function(minX, minY, maxX, maxY, centerX, centerY, zoomLevel) {
    this.Init(DvtMapBoundsChangeEvent.TYPE);
    this._minX = minX;
    this._minY = minY;
    this._maxX = maxX;
    this._maxY = maxY;
    this._centerX = centerX;
    this._centerY = centerY;
    this._zoomLevel = zoomLevel;
  };

  adf.mf.internal.dvt.DvtmObject.createSubclass(DvtMapBoundsChangeEvent, 'adf.mf.internal.dvt.geomap.events.DvtBaseComponentEvent', 'adf.mf.internal.dvt.geomap.events.DvtMapBoundsChangeEvent');

  /**
   * @export
   */
  DvtMapBoundsChangeEvent.TYPE = 'mapboundschange';

  /**
   * Returns minimum x bounds coordinate (longitude).
   * @return {number} minX
   * @export
   */
  DvtMapBoundsChangeEvent.prototype.getMinX = function() {
    return this._minX;
  };

  /**
   * Returns minimum y bounds coordinate (latitude).
   * @return {number} minY
   * @export
   */
  DvtMapBoundsChangeEvent.prototype.getMinY = function() {
    return this._minY;
  };

  /**
   * Returns maximum x bounds coordinate (longitude).
   * @return {number} maxX
   * @export
   */
  DvtMapBoundsChangeEvent.prototype.getMaxX = function() {
    return this._maxX;
  };

  /**
   * Returns maximum y bounds coordinate (latitude).
   * @return {number} maxY
   * @export
   */
  DvtMapBoundsChangeEvent.prototype.getMaxY = function() {
    return this._maxY;
  };

  /**
   * Returns x coordinate (longitude) of map center.
   * @return {number} centerX
   * @export
   */
  DvtMapBoundsChangeEvent.prototype.getCenterX = function() {
    return this._centerX;
  };

  /**
   * Returns y coordinate (latitude) of map center.
   * @return {number} centerY
   * @export
   */
  DvtMapBoundsChangeEvent.prototype.getCenterY = function() {
    return this._centerY;
  };

  /**
   * Returns current zoom level.
   * @return {number} zoomLevel
   * @export
   */
  DvtMapBoundsChangeEvent.prototype.getZoomLevel = function() {
    return this._zoomLevel;
  };
})();
/* Copyright (c) 2013, 2017 Oracle and/or its affiliates. All rights reserved. */
/*
 *    geoMap/events/DvtMapInputEvent.js
 */
(function()
{
  /**
   * Map input event.
   * @param {string} [eventId] input event type id (e.g. mousedown, mouseup, click)
   * @param {number} [pointX] x coordinate (longitude) of the event.
   * @param {number} [pointY] y coordinate (latitude) of the event.
   * @class
   * @constructor
   * @export
   */
  var DvtMapInputEvent = function(eventId, pointX, pointY, screenX, screenY) {
    this.Init(DvtMapInputEvent.TYPE);
    this._eventId = eventId;
    this._pointX = pointX;
    this._pointY = pointY;
    this._screenX = screenX;
    this._screenY = screenY;
  };

  adf.mf.internal.dvt.DvtmObject.createSubclass(DvtMapInputEvent, 'adf.mf.internal.dvt.geomap.events.DvtBaseComponentEvent', 'adf.mf.internal.dvt.geomap.events.DvtMapInputEvent');

  /**
   * @export
   */
  DvtMapInputEvent.TYPE = 'mapinput';

  /**
   * Returns the event type id -- mousedown, mouseup, or click.
   * @return {string} eventId
   * @export
   */
  DvtMapInputEvent.prototype.getEventId = function() {
    return this._eventId;
  };

  /**
   * Returns x coordinate (longitude).
   * @return {number} pointX
   * @export
   */
  DvtMapInputEvent.prototype.getPointX = function() {
    return this._pointX;
  };

  /**
   * Returns y coordinate (latitude).
   * @return {number} pointY
   * @export
   */
  DvtMapInputEvent.prototype.getPointY = function() {
    return this._pointY;
  };

  /**
   * Returns x pointer position.
   * @return {number} pointX
   * @export
   */
  DvtMapInputEvent.prototype.getScreenX = function() {
    return this._pointX;
  };

  /**
   * Returns y pointer position.
   * @return {number} pointY
   * @export
   */
  DvtMapInputEvent.prototype.getScreenY = function() {
    return this._screenY;
  };
})();
/* Copyright (c) 2013, 2017 Oracle and/or its affiliates. All rights reserved. */
/*
 *    geoMap/providers/DvtGoogleMapProvider.js
 */
(function ()
{
  var JSONPath = adf.mf.internal.dvt.util.JSONPath;
  /**
   * Map provider for DvtGeographicMap.
   * @class
   */
  var DvtGoogleMapProvider = function ()
  {
    this._googleApiLoaded = false;
    this._gapiLoading = false;
  };

  adf.mf.internal.dvt.DvtmObject.createSubclass(DvtGoogleMapProvider, 'adf.mf.internal.dvt.DvtmObject', 'DvtGoogleMapProvider', 'PRIVATE');

  DvtGoogleMapProvider.DEFAULT_GOOGLE_MARKER_IMG = 'css/images/geomap/red-circle.png';
  DvtGoogleMapProvider.DEFAULT_GOOGLE_MARKER_HOVER_IMG = 'css/images/geomap/ylw-circle.png';
  DvtGoogleMapProvider.DEFAULT_GOOGLE_MARKER_SELECT_IMG = 'css/images/geomap/blu-circle.png';
  DvtGoogleMapProvider.DEFAULT_EMPTY_MARKER_IMG = "data:image/x-icon;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQEAYAAABPYyMiAAAABmJLR0T///////8JWPfcAAAACXBIWXMAAABIAAAASABGyWs+AAAAF0lEQVRIx2NgGAWjYBSMglEwCkbBSAcACBAAAeaR9cIAAAAASUVORK5CYII=";
  DvtGoogleMapProvider.MOUSE_OVER = 'mouseover';
  DvtGoogleMapProvider.MOUSE_OUT = 'mouseout';
  DvtGoogleMapProvider.CLICK = 'click';
  DvtGoogleMapProvider.TOUCH_START = 'touchstart';
  DvtGoogleMapProvider.SEL_NONE = 'none';
  DvtGoogleMapProvider.SEL_SINGLE = 'single';
  DvtGoogleMapProvider.SEL_MULTIPLE = 'multiple';

  var CALLBACK_NAME = 'adf.mf.internal.dvt.geomap.DvtGoogleMapRenderer._apiCallback';

  DvtGoogleMapProvider.prototype.loadApi = function (config, success, error)
  {
    var renderer = this;

    if (this._gapiLoading === true)
    {
      return;
    }

    if (this._googleApiLoaded === true)
    {
      success.call(renderer);
      return;
    }

    this._gapiLoading = true;

    (new JSONPath(CALLBACK_NAME)).value = function ()
    {
      renderer._googleApiLoaded = true;
      renderer._gapiLoading = false;

      success.call(renderer);
    };

    var errorCallback = function()
    {
      renderer._googleApiLoaded = false;
      renderer._gapiLoading = false;

      error.call(renderer);
    };

    var mapApiBaseUrl = "https://maps.googleapis.com/maps/api/js?v=3&sensor=false&callback=" + CALLBACK_NAME;
    var url;
    var geoMapKey = config['geoMapKey'];
    var geoMapClientId = config['geoMapClientId'];
    if (geoMapKey)
    {
      url = mapApiBaseUrl + "&key=" + geoMapKey;
    }
    else if (geoMapClientId)
    {
      url = mapApiBaseUrl + "&client=" + geoMapClientId;
    }
    else
    {
      url = mapApiBaseUrl;
    }
    // set 30s timeout for the google api callback failure
    window.setTimeout(function()
    {
      if (renderer._googleApiLoaded === false)
      {
        errorCallback();
      }
    }, 30 * 1000);
    // start loading API
    adf.mf.api.resourceFile.loadJsFile(url, true, function ()
    {
      // google provides only async loader so we have nothing to do here
    },
    errorCallback);
  };

  /**
   * Renders the geographic map in the specified area.
   * @param {DvtGeographicMap} map The geographic map being rendered.
   * @param {object} mapCanvas The div to render the map.
   * @param {number} width The width of the component.
   * @param {number} height The height of the component.
   */
  DvtGoogleMapProvider.prototype.render = function (map, mapCanvas, width, height)
  {
    if (this._googleApiLoaded === false)
    {
      throw "Google Map api is not loaded!";
    }

    this.renderGoogleMap(map, mapCanvas, width, height);
  };

  DvtGoogleMapProvider.prototype.destroy = function (map)
  {
    // destroy is not supported by google map api
  };

  DvtGoogleMapProvider.prototype.getIcon = function (params, hover)
  {
    if (params['markerIconDisplay'])
    {
      if (params.selected)
      {
        return hover ? params['sourceHoverSelected'] : params['sourceSelected'];
      }
      else
      {
        return hover ? params['sourceHover'] : params['source'];
      }
    }
    else
    {
      return DvtGoogleMapProvider.DEFAULT_EMPTY_MARKER_IMG;
    }
  };

  /**
   * Renders the geographic map in the specified area.
   * @param {DvtGeographicMap} map The geographic map being rendered.
   * @param {object} mapCanvas The div to render the map.
   * @param {number} width The width of the component.
   * @param {number} height The height of the component.
   * @this
   */
  DvtGoogleMapProvider.prototype.renderGoogleMap = function (map, mapCanvas, width, height)
  {
    var options = map.Options;
    var data = map.Data;

    var mapTypeId = '';

    switch (options.mapOptions.mapType)
    {
      case 'ROADMAP':
        mapTypeId = google.maps.MapTypeId.ROADMAP;
        break;
      case 'SATELLITE':
        mapTypeId = google.maps.MapTypeId.SATELLITE;
        break;
      case 'HYBRID':
        mapTypeId = google.maps.MapTypeId.HYBRID;
        break;
      case 'TERRAIN':
        mapTypeId = google.maps.MapTypeId.TERRAIN;
        break;
      default :
        mapTypeId = google.maps.MapTypeId.ROADMAP;
        break;
    }

    map.initialSelectionApplied = false;
    var initialZooming = true;
    if (!this._mapIncludesData(map))
    {
      initialZooming = false;
    }
    else if (options.mapOptions.initialZooming)
    {
      initialZooming = options.mapOptions.initialZooming == 'none' ? false : true;
    }
    var animationOnDisplay = 'none';
    if (options.mapOptions.animationOnDisplay)
    {
      animationOnDisplay = options.mapOptions.animationOnDisplay;
    }

    var gmap;
    map._firstTime = false;

    if (initialZooming)
    {
      // create empty instance of the google map without information
      // about the map type - this prevents map from rendering immediately
      if (!map['_googlemap'])
      {
        map._firstTime = true;
        // create google map instance on the map component
        map['_googlemap'] = new google.maps.Map(mapCanvas);
      }
      gmap = map['_googlemap'];
    }
    else
    {
      // resolve information required for the map without initial zooming
      var mapCenterLon = parseFloat(options.mapOptions.centerX);
      var mapCenterLat = parseFloat(options.mapOptions.centerY);
      // create standard map which will be displayed imediately
      if (!map['_googlemap'])
      {
        map._firstTime = true;
        // prepare initial options
        var mapOptions = new Object();
        mapOptions.mapTypeId = mapTypeId;
        // create google map instance on the map component
        map['_googlemap'] = new google.maps.Map(mapCanvas, mapOptions);
      }

      gmap = map['_googlemap'];
      gmap.setCenter(new google.maps.LatLng(mapCenterLat, mapCenterLon));
      gmap.setZoom(parseInt(options.mapOptions.zoomLevel));
    }
    // set map type
    gmap.setMapTypeId(mapTypeId);
    // remove all old markers from the google map instance
    if (map._currentMarkers)
    {
      for (var ind = 0;ind < map._currentMarkers.length;ind++)
      {
        if (map._currentMarkers[ind] && map._currentMarkers[ind].setMap)
        {
          map._currentMarkers[ind].setMap(null);
        }
      }
      // clear array of old markers
      map._currentMarkers.length = 0;
    }
    else
    {
      map._currentMarkers = [];
    }

    this.googleMapRenderRoutes(map, gmap, data, initialZooming);
    // set the data layer
    this.setGoogleMapDataLayer(map, gmap, data, initialZooming, animationOnDisplay);
    // when map is initialized in hidden panel, we need to resize and recenter the map
    google.maps.event.addListenerOnce(gmap, 'idle', function ()
    {
      var center = gmap.getCenter();
      google.maps.event.trigger(gmap, 'resize');
      gmap.setCenter(center);
    });
  };

  DvtGoogleMapProvider.prototype.googleMapRenderRoutes = function (map, gmap, data, initialZooming)
  {
    if (!data.routes || data.routes.length === 0)
      return;

    var that = this;
    var routeBounds = null;
    var requests = 0;

    data.routes.forEach(function (routeOptions)
    {
      if (!routeOptions["wayPoints"] || routeOptions["wayPoints"].length < 2)
      {
        return;
      }

      var tMode = null;
      var mode = routeOptions['travelMode'];
      if (mode)
        mode = mode.toLowerCase();
      switch (mode)
      {
        case 'walking':
          tMode = google.maps.TravelMode.WALKING;
          break;
        case 'cycling':
          tMode = google.maps.TravelMode.BICYCLING;
          break;
        default :
          tMode = google.maps.TravelMode.DRIVING;
      }

      var wayPointTranslator = function (point)
      {
        if (point['address'])
        {
          return {location : point['address']};
        }
        return {location : new google.maps.LatLng(point['y'], point['x'])};
      };

      var markerParamTranslator = function (point)
      {
        if (point['displayMarker'] !== true)
        {
          return null;
        }
        return that.getParams(point);
      };

      var wayPoints = routeOptions["wayPoints"].map(wayPointTranslator);
      var params = routeOptions["wayPoints"].map(markerParamTranslator);

      var directionsService = new google.maps.DirectionsService();

      var request =
      {
        origin : wayPoints[0]['location'], destination : wayPoints[wayPoints.length - 1]['location'], travelMode : tMode, provideRouteAlternatives : false, waypoints : wayPoints.slice(1, wayPoints.length - 1)
      };

      var routeStyle = routeOptions['style']['default'];
      var polyOptions =
      {
        strokeColor : routeStyle['color'] || '#1fb5fb', strokeOpacity : routeStyle['opacity'] || 1, strokeWeight : routeStyle['width'] || 8
      };

      var routeAction = routeOptions['action'];
      var routeId = routeOptions['id'];

      requests++;
      directionsService.route(request, function (result, status)
      {
        requests--;
        var createClickHandler = function (clientId, action)
        {
          return function (e)
          {
            var actionEvent = new adf.mf.internal.dvt.geomap.events.DvtMapActionEvent(clientId, null, action);
            var clickPosition = e.latLng;
            var pointXY = fromLatLngToPixel(gmap, clickPosition);
            actionEvent.addParam('pointXY',
            {
              'x' : pointXY.x, 'y' : pointXY.y
            });
            actionEvent.addParam('latLng',
            {
              'lat' : clickPosition.lat(), 'lng' : clickPosition.lng()
            });

            map.dispatchEvent(actionEvent);
          };
        };

        if (status === google.maps.DirectionsStatus.OK)
        {
          result.routes.forEach(function (route, routeIndex)
          {
            if (initialZooming)
            {
              if (!routeBounds)
              {
                routeBounds = route.bounds;
              }
              routeBounds = routeBounds.union(route.bounds);
              if (requests === 0 && routeBounds)
              {
                gmap.fitBounds(routeBounds);
                routeBounds = null;
              }
            }
            route.legs.forEach(function (leg, legIndex)
            {
              if (params[legIndex])
              {
                that.processGoogleMapDataPoint(map, gmap, leg['start_location'], params[legIndex], false, false);
              }
              if (legIndex === route.legs.length - 1 && params[legIndex + 1])
              {
                that.processGoogleMapDataPoint(map, gmap, leg['end_location'], params[legIndex + 1], false, false);
              }

              leg.steps.forEach(function (step, stepIndex)
              {
                var polyline = new google.maps.Polyline(polyOptions);
                polyline.setPath(step.path);

                if (routeAction)
                {
                  google.maps.event.addListener(polyline, DvtGoogleMapProvider.CLICK, createClickHandler(routeId, routeAction));
                }

                polyline.setMap(gmap);
                // need to remove this on the next search
                map._currentMarkers = map._currentMarkers || [];
                map._currentMarkers.push(polyline);
              });
            });
          });
        }
        else
        {
          adf.mf.log.Framework.logp(adf.mf.log.level.WARNING, 'adf.mf.internal.dvt.geomap.DvtGoogleMapProvider', 'googleMapRenderRoutes', 'Can\'t render the route because of the service error.');
          adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtGoogleMapProvider', 'googleMapRenderRoutes', 'Can\'t render the route because of the service error [returned status: \'' + status + '\']');
        }
      });
    });
  };

  var TextOverlay = null;

  var createTextOverlayClass = function()
  {
    if (!TextOverlay)
    {
      /** @constructor */
      TextOverlay = function(renderer, map, gmap) {

        // Now initialize all properties.
        this.instance_ = map;
        this.map_ = gmap;
        this.renderer_ = renderer;

        // Define a property to hold the texts' div. We'll
        // actually create this div upon receipt of the onAdd()
        // method so we'll leave it null for now.
        this.div_ = null;

        // Explicitly call setMap on this overlay
        this.setMap(gmap);
      };

      TextOverlay.prototype = new google.maps.OverlayView();

      /**
       * onAdd is called when the map's panes are ready and the overlay has been
       * added to the map.
       */
      TextOverlay.prototype.onAdd = function() {

        var div = document.createElement('div');
        div.style.border = 'none';
        div.style.borderWidth = '0px';
        div.style.position = 'absolute';
        div.style.left = 0;
        div.style.top = 0;
        div.style.right = 0;
        div.style.down = 0;

        this.div_ = div;

        // Add the element to the "overlayImage" pane.
        var panes = this.getPanes();
        panes.overlayImage.appendChild(this.div_);
      };

      TextOverlay.prototype.paintBubble = function (marker, position) {
        var params = marker.params;
        var root = this.div_;
        var div = document.createElement("div");
        div.setAttribute("style","position: absolute;");
        var bubble = document.createElement("div");
        var bubbleText = document.createElement("span");
        bubbleText.innerHTML = params.label;
        bubble.appendChild(bubbleText);
        div.appendChild(bubble);
        var anchor = document.createElement("div");
        var anchorL = document.createElement("div");
        var anchorLin = document.createElement("div");
        anchorL.appendChild(anchorLin);
        anchor.appendChild(anchorL);
        var anchorR = document.createElement("div");
        var anchorRin = document.createElement("div");
        anchorR.appendChild(anchorRin);
        anchor.appendChild(anchorR);
        div.appendChild(anchor);
        root.appendChild(div);
        if (params['selected'])
        {
          bubble.className = "dvtm-geographicMap-infoBubble-selected";
          bubble.setAttribute("style", params.selectedLabelStyle || "");
          anchor.className = "dvtm-geographicMap-infoBubble-anchor-selected";
          anchorL.className = "dvtm-geographicMap-infoBubble-anchorL-selected";
          anchorLin.className = "dvtm-geographicMap-infoBubble-anchorLin-selected";
          anchorLin.setAttribute("style", params.selectedLabelStyle || "");
          anchorR.className = "dvtm-geographicMap-infoBubble-anchorR-selected";
          anchorRin.className = "dvtm-geographicMap-infoBubble-anchorRin-selected";
          anchorRin.setAttribute("style", params.selectedLabelStyle || "");
        } 
        else
        {
          bubble.className = "dvtm-geographicMap-infoBubble";
          bubble.setAttribute("style", params.labelStyle || "");
          anchor.className = "dvtm-geographicMap-infoBubble-anchor";
          anchorL.className = "dvtm-geographicMap-infoBubble-anchorL";
          anchorLin.className = "dvtm-geographicMap-infoBubble-anchorLin";
          anchorLin.setAttribute("style", params.labelStyle || "");
          anchorR.className = "dvtm-geographicMap-infoBubble-anchorR";
          anchorRin.className = "dvtm-geographicMap-infoBubble-anchorRin";
          anchorRin.setAttribute("style", params.labelStyle || "");
        }
        bubble.style.whiteSpace = "nowrap";
        div.style.left = position.x + 'px';
        div.style.top = position.y  + 'px';
        var ariaLabel = params['tooltip'] + '. ';
        if (params['selected'])
        {
          ariaLabel = ariaLabel + adf.mf.resource.getInfoString("AMXInfoBundle", "dvtm_geographicMap_MARKER_STATE_SELECTED") + '.';
        }
        else
        {
          ariaLabel = ariaLabel + adf.mf.resource.getInfoString("AMXInfoBundle", "dvtm_geographicMap_MARKER_STATE_UNSELECTED") + '.';
        }
        div.setAttribute('aria-label', ariaLabel);
        div.setAttribute('role', 'button');
        var map = this.instance_;
        var renderer = this.renderer_;
        div.addEventListener ("click", function(ev) {
          if (params.action)
          {
            renderer.invokeAction (params.action, params, marker, map, ev.type);
          }
          renderer.updateSelection(map, marker);
          ev.stopPropagation();
        });
      };

      TextOverlay.prototype.paintLabel = function (marker, position) {
        var span = document.createElement("span");
        span.textContent = marker.label;
        if (marker.labelStyle)
        {
          span.setAttribute("style", marker.labelStyle);
        }

        span.style.position = "absolute";
        span.style.whiteSpace = "nowrap";
        span.style.right = "auto";
        span.style.bottom = "auto";
        span.style.width = "auto";
        span.style.height = "auto";

        this.div_.appendChild(span);

        span.style.left = (position.x - span.offsetWidth / 2) + 'px';
        var icon = marker.getIcon();

        switch (marker.labelPosition)
        {
          case "center" :
            span.style.top = (position.y - Math.floor((icon.size.height + span.offsetHeight) / 2 )) + 'px';
            break;
          case "top" :
            span.style.top = (position.y - Math.floor((icon.size.height + span.offsetHeight)) - 1) + 'px';
            break;
          case "bottom" :
          default:
             span.style.top = (position.y + 1) + 'px';
        }
      };
      
      TextOverlay.prototype.draw = function() {

        // We use the south-west and north-east
        // coordinates of the overlay to peg it to the correct position and size.
        // To do this, we need to retrieve the projection from the overlay.
        var overlayProjection = this.getProjection();
        var map = this.getMap();
        var bounds = map.getBounds();
        var div = this.div_;
        div.innerHTML = "";
        var _TextOverlay = this;
        this.instance_._currentMarkers.forEach(function(marker)
        {
          if (marker.label && marker.getVisible())
          {
            var latLng = marker.getPosition();
            if (bounds.contains(latLng))
            {
              // retrieve pixel coordinates for the latlng position of the marker
              var position = overlayProjection.fromLatLngToDivPixel(latLng);

              if (marker.labelPosition == "bubble")
              {
                _TextOverlay.paintBubble(marker, position);
              }
              else
              {
                _TextOverlay.paintLabel(marker, position);
              }
            }
          }
        });
      };

      TextOverlay.prototype.onRemove = function() {
        this.div_.parentNode.removeChild(this.div_);
      };

      // Set the visibility to 'hidden' or 'visible'.
      TextOverlay.prototype.hide = function() {
        if (this.div_) {
          // The visibility property must be a string enclosed in quotes.
          this.div_.style.visibility = 'hidden';
        }
      };

      TextOverlay.prototype.show = function() {
        if (this.div_) {
          this.div_.style.visibility = 'visible';
        }
      };

      TextOverlay.prototype.toggle = function() {
        if (this.div_) {
          if (this.div_.style.visibility === 'hidden') {
            this.show();
          } else {
            this.hide();
          }
        }
      };

      // Detach the map from the DOM via toggleDOM().
      // Note that if we later reattach the map, it will be visible again,
      // because the containing <div> is recreated in the overlay's onAdd() method.
      TextOverlay.prototype.toggleDOM = function() {
        if (this.getMap()) {
          // Note: setMap(null) calls OverlayView.onRemove()
          this.setMap(null);
        } else {
          this.setMap(this.map_);
        }
      };
    }
  };

  /**
   * @param {DvtGeographicMap} gmap Google Map instance
   * @param {object} map instance of the GeographicMap
   * @param {array} points Arraz of data points
   * @this
   */
  DvtGoogleMapProvider.prototype.googleMapRenderEnd = function (gmap, map, points)
  {
    var that = this;
    createTextOverlayClass();
    var geocoderQueue = [];
    // process all resolved marker points and add them to the google map
    for (var i = 0;i < points.length;i++)
    {
      var point = points[i];
      if (point)
      {
        if (point['resolved'] === true)
        {
          this.processGoogleMapDataPoint(map, gmap, point['latLng'], point['params'], point['animation'], point['initialZooming']);
        }
        else
        {
          geocoderQueue.push(point);
        }
      }
    }

    if (geocoderQueue.length > 0)
    {
      var timeStamp = (new Date()).getTime();
      var callback = function (markerParams, aAddress, animation)
      {
        return function (results, status)
        {
          // add map point when result is returned
          if (status === google.maps.GeocoderStatus.OK)
          {
            var addrMarkerLatLng = results[0].geometry.location;
            that._addresscache[aAddress] = addrMarkerLatLng;
            timeStamp = (new Date()).getTime();
            that.processGoogleMapDataPoint(map, gmap, addrMarkerLatLng, markerParams, animation, false);
          }

          if (status === google.maps.GeocoderStatus.OVER_QUERY_LIMIT)
          {
            geocoderQueue.push(
            {
              'resolved' : false, 'address' : aAddress, 'params' : markerParams, 'animation' : animation, 'initialZooming' : false
            });
          }
        }
      };

      var ITEMS_PER_SECOND = 10;

      setTimeout(function (geocoderCallback, renderer, queue)
      {
        var geocoder = new google.maps.Geocoder();
        var consumer = window.setInterval(function ()
        {
          if (queue.length === 0 || (new Date()).getTime() - timeStamp > 3000)
          {
            clearInterval(consumer);
            if ((new Date()).getTime() - timeStamp > 3000)
            {
              throw new Error('ERR_DAILY_QUOTA_EXCEEDED');
            }
            return;
          }

          var geo = queue.shift();
          if (geo)
          {
            var address = geo['address'];
            // create address cache if not exists
            if (renderer._addresscache === undefined)
            {
              renderer._addresscache =
              {
              };
            }
            // try to load information about address location from cache
            var cachedPoint = renderer._addresscache[address];
            if (cachedPoint)
            {
              renderer.processGoogleMapDataPoint(map, gmap, cachedPoint, geo['params'], geo['animation'], false);
            }
            else
            {
              geocoder.geocode(
              {
                'address' : address
              },
              geocoderCallback(geo['params'], address, geo['animation']));
            }
          }
        },
        Math.floor(1000 / ITEMS_PER_SECOND) + 1);
      }, 1000 - Math.floor(1000 / ITEMS_PER_SECOND) + 1, callback, this, geocoderQueue);
    }

    map.initialSelectionApplied = true;// initial selection has been applied by now
    // when bounds are selected zoom to them
    if (map._bounds)
    {
      var zoomLevel = parseInt(map['Options']['mapOptions']['zoomLevel']);
      var ne = map._bounds.getNorthEast();
      var sw = map._bounds.getSouthWest();
      // when northeast and southwest corners of the map bounds are equal
      // then zoom only to one point
      if (ne.equals(sw))
      {
        this.zoomToMarker(gmap, ne, zoomLevel);
      }
      // in case that there is explicit zoom set by developer
      // use initial zoom only to center the map and use
      // custom zoom level as default
      else if (map['Options']['mapOptions']['explicitZoom'])
      {
        var center = map._bounds.getCenter();
        this.zoomToMarker(gmap, center, zoomLevel);
      }
      else
      {
        gmap.fitBounds(map._bounds);
      }

      map._bounds = null;
    }
    else if (!gmap.getZoom())
    {
      var centerLat = parseFloat(map['Options']['mapOptions']['centerY']);
      var centerLng = parseFloat(map['Options']['mapOptions']['centerX']);

      var center = new google.maps.LatLng(centerLat, centerLng);

      this.zoomToMarker(gmap, center, 2);
    }

    // register listeners which handle user interaction with map on the first time map is rendered
    if (map._firstTime)
    {
      map.textOverlay = new TextOverlay(this, map, gmap);
      // this method fires an MapBoundsChangeEvent on map view property changes
      var fireMapBoundsChangeEvent = function ()
      {
        var options = map['Options'];
        if (!options.mapOptions.hasMapBoundsChangeActionListener)
        {
          return;
        }
        var bounds = gmap.getBounds();
        var zoomLevel = gmap.getZoom();
        // bug 17863212: return immediately if map not fully initialized yet
        if (!bounds)
          return;

        var evt = new adf.mf.internal.dvt.geomap.events.DvtMapBoundsChangeEvent(bounds.getSouthWest().lng(), bounds.getSouthWest().lat(), bounds.getNorthEast().lng(), bounds.getNorthEast().lat(), bounds.getCenter().lng(), bounds.getCenter().lat(), zoomLevel);
        map.dispatchEvent(evt);
      };

      // save information about new map center and zoom when user change it by dragging the map
      // user interaction is similar to changing of properties of the map so store it to Options of the map.
      google.maps.event.addListener(gmap, 'dragend', function ()
      {
        // renderer should reset all these options object on component refresh
        var options = map['Options'];
        var center = gmap.getCenter();
        if (center)
        {
          options.mapOptions.centerX = '' + center.lng();
          options.mapOptions.centerY = '' + center.lat();
        }
        var zoom = gmap.getZoom();
        if (zoom)
        {
          options.mapOptions.zoomLevel = '' + zoom;
        }
        if (zoom || center)
        {
          options.mapOptions.initialZooming = 'none';
        }
        // notify clients
        fireMapBoundsChangeEvent();
      });

      // store information about user selected map type
      google.maps.event.addListener(gmap, 'maptypeid_changed', function ()
      {
        var options = map['Options'];
        switch (gmap.getMapTypeId())
        {
          case google.maps.MapTypeId.ROADMAP:
            options.mapOptions.mapType = 'ROADMAP';
            break;
          case google.maps.MapTypeId.SATELLITE:
            options.mapOptions.mapType = 'SATELLITE';
            break;
          case google.maps.MapTypeId.HYBRID:
            options.mapOptions.mapType = 'HYBRID';
            break;
          case google.maps.MapTypeId.TERRAIN:
            options.mapOptions.mapType = 'TERRAIN';
            break;
          default :
            options.mapOptions.mapType = 'ROADMAP';
            break;
        }
      });

      var clickHandler = function (eventId, event)
      {
        var latLng = event.latLng;
        var evt = new adf.mf.internal.dvt.geomap.events.DvtMapInputEvent('click', latLng.lng(), latLng.lat());
        map.dispatchEvent(evt);
      };

      var lastLatLng = null;

      var domEventHandler = function (eventId)
      {
        if (lastLatLng)
        {
          var evt = new adf.mf.internal.dvt.geomap.events.DvtMapInputEvent(eventId, lastLatLng.lng(), lastLatLng.lat());
          map.dispatchEvent(evt);
        }
      };

      var mouseMoveHandler = function (event)
      {
        lastLatLng = event.latLng;
      };

      if (map['Options'].mapOptions.hasMapInputActionListener)
      {
        google.maps.event.addListener(gmap, 'click', function (event)
        {
          clickHandler('click', event);
        });
        google.maps.event.addListener(gmap, 'mousemove', function (event)
        {
          mouseMoveHandler(event)
        });
        google.maps.event.addDomListener(gmap.getDiv(), 'mousedown', function (event)
        {
          domEventHandler('mousedown');
        });
        google.maps.event.addDomListener(gmap.getDiv(), 'mouseup', function (event)
        {
          domEventHandler('mouseup');
        });
      }

      google.maps.event.addListener(gmap, 'zoom_changed', fireMapBoundsChangeEvent);
    }
    else
    {
      // refresh TextOverlay
      map.textOverlay.setMap(null);
      map.textOverlay.setMap(gmap);
    }
    map.dispatchEvent({ 'type': 'ready' });
  };

  /**
   * @param {DvtGeographicMap} map The geographic map being rendered.
   * @param {object} gmap The google map
   * @param {object} markerLatLng
   * @param {params} params The params for the marker
   * @param {string} animation Marker animation
   * @param {boolean} initialZooming Should the map zoom to the data points
   * @this
   */
  DvtGoogleMapProvider.prototype.processGoogleMapDataPoint = function (map, gmap, markerLatLng, params, animation, initialZooming)
  {
    // add marker into the map
    if (params['renderMarker'])
      this.addMarker(map, gmap, markerLatLng, params, animation);
    // when initial zooming is enabled determin proper bounds for all markers
    if (initialZooming)
    {
      if (!map._bounds)
      {
        map._bounds = new google.maps.LatLngBounds(markerLatLng, markerLatLng);
      }
      // function extends current bounds to include new marker
      map._bounds = map._bounds.extend(markerLatLng);
    }
  };

    // --------- Tap Hold --------- //
  var tapHoldPendingIds = {};

  function cancelPendingTapHold()
  {
    tapHoldPendingIds = {};
  }

  var holdThreshold = 800;

  var _addTapHoldEventListener = function(marker, listenerAddCallback, listener, eventData)
  {
    eventData = eventData || {};
    var tapId = null;
    var startListener = function(event)
    {
      tapId = amx.uuid(); // TODO don't use amx.foo!
      tapHoldPendingIds[tapId] = new Date().getTime();

      setTimeout(function()
      {
        // Note: here we double check if the time is greater than the threshold. This is useful since sometime timeout
        //       is not really reliable.
        if (tapHoldPendingIds[tapId] > 0)
        {
          delete tapHoldPendingIds[tapId];
          // Call the listener but make sure our eventData is used:
          var eventDataToRestore = event.data;
          event.data = eventData;
          event.data.type = "tapHold";
          listener.call(marker, event);
          event.data = eventDataToRestore;
        }

      }, holdThreshold);
    };

    var endListener = function(event)
    {
      if (tapHoldPendingIds[tapId])
      {
        delete tapHoldPendingIds[tapId];
      
        var eventDataToRestore = event.data;
        event.data = eventData;
        event.data.type = "click";
        listener.call(marker, event);
        event.data = eventDataToRestore;
      }
    };

    listenerAddCallback.call(this, startListener, endListener, cancelPendingTapHold);
  };
  // --------- /Tap Hold --------- //


  /**
   * Set the data layer on google map
   * @param {DvtGeographicMap} map The geographic map being rendered.
   * @param {object} gmap The google map
   * @param {object} data The geographic map data object
   * @param {boolean} initialZooming Should the map zoom to the data points
   * @param {string} animation Marker animation
   * @this
   */
  DvtGoogleMapProvider.prototype.setGoogleMapDataLayer = function (map, gmap, data, initialZooming, animation)
  {
    map._bounds = null;
    var dataLayers = data['dataLayers'];
    map._jobCount = 0;// number of remaining map points to resolve
    var result = [];
    var index = 0;

    var geocoder = undefined;
    var geocoderRequestCount = 0;
    for (var i in dataLayers)
    {
      var dataLayer = dataLayers[i];
      var points = dataLayer['data'] || [];
      var selectedRowKeys = this._getSelectedRowKeys(map, dataLayer, i);

      map._jobCount += Object.keys (points).length;

      for (var j in points)
      {
        var params = this.getParams(points[j]);
        var selMode = this.getSelMode(dataLayer);

        params['selMode'] = selMode;
        params['dataLayerId'] = dataLayer['id'];

        if (selMode == DvtGoogleMapProvider.SEL_SINGLE || selMode == DvtGoogleMapProvider.SEL_MULTIPLE)
        {
          params['selected'] = (selectedRowKeys.indexOf(points[j]['_rowKey']) !==  - 1) ? true : false;
        }

        if (points[j]['x'] && points[j]['y'])
        {
          var markerLatLng = new google.maps.LatLng(parseFloat(points[j]['y']), parseFloat(points[j]['x']));
          result[index] =
          {
            'resolved' : true, 'latLng' : markerLatLng, 'params' : params, 'animation' : animation, 'initialZooming' : initialZooming
          };
          map._jobCount--;// map point resolved
        }
        else if (points[j]['address'])
        {
          var address = points[j]['address'];
          // create address cache if not exists
          if (this._addresscache === undefined)
          {
            this._addresscache =
            {
            };
          }
          // try to load information about address location from cache
          var cachedPoint = this._addresscache[address];
          if (cachedPoint)
          {
            result[index] =
            {
              'resolved' : true, 'address' : address, 'latLng' : cachedPoint, 'params' : params, 'animation' : animation, 'initialZooming' : initialZooming
            };
            map._jobCount--;// map point resolved
          }
          else
          {
            var that = this;
            // callback object which handles result from geocoder
            var callback = function (map, markerParams, aIndex, aAddress)
            {
              return function (results, status)
              {
                map._jobCount--;
                // add map point when result is returned
                if (status == google.maps.GeocoderStatus.OK)
                {
                  var addrMarkerLatLng = results[0].geometry.location;
                  that._addresscache[aAddress] = addrMarkerLatLng;

                  result[aIndex] =
                  {
                    'resolved' : true, 'address' : aAddress, 'latLng' : addrMarkerLatLng, 'params' : markerParams, 'animation' : animation, 'initialZooming' : initialZooming
                  };
                }

                if (status == google.maps.GeocoderStatus.OVER_QUERY_LIMIT)
                {
                  result[aIndex] =
                  {
                    'resolved' : false, 'address' : aAddress, 'params' : markerParams, 'animation' : animation, 'initialZooming' : initialZooming
                  };
                }

                // endpoint of asynchronous callback
                if (map._jobCount === 0)
                {
                  that.googleMapRenderEnd(gmap, map, result);
                }
              }
            };
            // create geocoder service if it does not exist
            if (geocoder === undefined)
            {
              geocoder = new google.maps.Geocoder();
            }

            if (geocoderRequestCount < 10)
            {
              geocoderRequestCount++;
              geocoder.geocode(
              {
                'address' : address
              },
              callback(map, params, index, address));
            }
            else
            {
              map._jobCount--;
              result[index] =
              {
                'resolved' : false, 'address' : address, 'params' : params, 'animation' : animation, 'initialZooming' : initialZooming
              };
            }
          }
        }
        index++;
      }
    }
    // in case there are no points or all points have been already added call end function
    if (map._jobCount === 0)
    {
      this.googleMapRenderEnd(gmap, map, result);
    }
  };

  DvtGoogleMapProvider.prototype.getGoogleIcon = function (params, hover)
  {
    var image = this.getIcon(params, hover);
    var dim = new google.maps.Size(params['width'] * params['scaleX'], params['height'] * params['scaleY']);
    return {
      url : image,
      size : dim,
      scaledSize : dim
    };
  };

  DvtGoogleMapProvider.prototype.invokeAction = function (action, params, marker, map, type)
  {
    var actionEvent = new adf.mf.internal.dvt.geomap.events.DvtMapActionEvent(params['clientId'], params['rowKey'], action);
    actionEvent.addParam('dataLayerId', params['dataLayerId']);
    actionEvent.addParam('actionType', type);
    var markerPos = marker.getPosition();
    var gmap = map['_googlemap'];
    var pointXY = fromLatLngToPixel(gmap, markerPos);

    actionEvent.addParam('pointXY', 
    {
      'x' : pointXY.x, 'y' : pointXY.y
    });
    actionEvent.addParam('latLng', 
    {
      'lat' : markerPos.lat(), 'lng' : markerPos.lng()
    });
    map.dispatchEvent(actionEvent);
  };
  
  /**
   * Add marker to map
   * @param {DvtGeographicMap} map The geographic map being rendered.
   * @param {object} gmap The google map
   * @param {object} markerLatLng
   * @param {params} params The params for the point foi
   * @param {string} animation Marker animation
   * @this
   */
  DvtGoogleMapProvider.prototype.addMarker = function (map, gmap, markerLatLng, params, animation)
  {
    // create array which holds information about markers on the map
    if (map._currentMarkers === undefined)
    {
      map._currentMarkers = [];
    }
    var selMode = params['selMode'];
    var dataLayerId = params['dataLayerId'];
    var selected = params['selected'];
    var action = params['action'];
    var tooltip = '';
    if (params['tooltip'])
      tooltip = params['tooltip'];

    var sourceImg = this.getGoogleIcon(params);

    // in test mode create real markers and not
    // optimized one
    var testMode = (amx && amx.testmode === true);

    var marker = new google.maps.Marker(
    {
      opacity : params['opacity'],
      position : markerLatLng,
      optimized: !testMode,
      icon : sourceImg,
      title : tooltip
    });

    // selected markers have to be on the top
    marker.setZIndex(selected ? google.maps.Marker.MAX_ZINDEX + 1 : 1);

    marker.label = params['label'];
    marker.labelStyle = params['labelStyle'];
    marker.labelPosition = params['labelPosition'];
    marker.params = params;

    if (animation == 'auto')
      marker.setAnimation(google.maps.Animation.DROP);

    // Add marker to the map
    marker.setMap(gmap);
    // add information that map contains marker
    map._currentMarkers.push(marker);

    // attach selection related event listeners
    if (selMode == DvtGoogleMapProvider.SEL_SINGLE || selMode == DvtGoogleMapProvider.SEL_MULTIPLE)
    {
      if (!amx.hasTouch())
      {
        // bug 18113730: do not register hover listeners on touch devices
        this.attachGMapEventListener(map, marker, DvtGoogleMapProvider.MOUSE_OVER, params);
        this.attachGMapEventListener(map, marker, DvtGoogleMapProvider.MOUSE_OUT, params);
      }
      this.attachGMapEventListener(map, marker, DvtGoogleMapProvider.CLICK, params);

      if (selected)
      {
        var selection = map['selection'][dataLayerId];
        if (selection === undefined)
        {
          selection = map['selection'][dataLayerId] = [];
        }
        marker['selected'] = true;
        marker['rowKey'] = params['rowKey'];
        marker['dataLayerId'] = dataLayerId;
        selection.push(marker);
      }
    }

    if (action)
    {
      var that = this;
      var listener = function (event)
      {
        if (params.labelPosition == "bubble") {
          return;
        }
        that.invokeAction (action, params, marker, map, event.data.type);
      };

      var registrator = function(start, stop, cancel)
      {
        google.maps.event.addListener(marker, "mousedown", start);
        google.maps.event.addListener(marker, "mouseup", stop);

        // in touch mode there is no mouse out event needed
        if (!amx.hasTouch())
        {
          google.maps.event.addListener(marker, "mouseout", cancel);
        }
      };

      _addTapHoldEventListener(marker, registrator, listener);
    }
  };

  var fromLatLngToPixel = function (gmap, position)
  {
    var scale = Math.pow(2, gmap.getZoom());
    var proj = gmap.getProjection();
    var bounds = gmap.getBounds();
    var nw = proj.fromLatLngToPoint(new google.maps.LatLng(bounds.getNorthEast().lat(), bounds.getSouthWest().lng()));
    var point = proj.fromLatLngToPoint(position);

    return new google.maps.Point(Math.floor((point.x - nw.x) * scale), Math.floor((point.y - nw.y) * scale));
  };

  DvtGoogleMapProvider.prototype.updateSelection = function (map, marker)
  {
    var params = marker.params;
    var selMode = params['selMode'];
    if (selMode == DvtGoogleMapProvider.SEL_NONE)
    {
      return;
    }
    var i, id = params['dataLayerId'];
    if (!map.selection[id])
      map.selection[id] = [];
    if (!marker.selected)
    {
      var selection = map.selection[id];
      if (selMode == DvtGoogleMapProvider.SEL_SINGLE)
      {
        if (selection.length != 0)
        {
          for (i = 0;i < selection.length;i++)
          {
            selection[i].selected = false;
            selection[i].params.selected = false;
            selection[i].setIcon(this.getGoogleIcon(selection[i].params));
          }
          map.selection[id] = [];
        }
      }
      marker.selected = true;
      marker.params.selected = true;
      marker.setIcon(this.getGoogleIcon(params));
      marker.rowKey = params['rowKey'];
      marker.dataLayerId = id;
      marker.setZIndex(google.maps.Marker.MAX_ZINDEX + 1);
      map.selection[id].push(marker);
    }
    else
    {
      // deselect
      marker.selected = false;
      marker.params.selected = false;
      marker.setIcon(this.getGoogleIcon(params));
      marker.setZIndex(1);
      // remove from selection
      if (selMode == DvtGoogleMapProvider.SEL_SINGLE)
      {
        map.selection[id] = [];
      }
      else if (selMode == DvtGoogleMapProvider.SEL_MULTIPLE)
      {
        for (i = 0;i < map.selection[id].length;i++)
        {

          if (marker.rowKey == map.selection[id][i].rowKey && marker.dataLayerId == map.selection[id][i].dataLayerId)
          {
            map.selection[id].splice(i, 1);
            break;
          }
        }
      }
    }
    map.textOverlay.setMap(null);
    map.textOverlay.setMap(map['_googlemap']);
  };
  
  /**
   * Attach event listeners
   * @param {DvtGeographicMap} map The geographic map being rendered.
   * @param {object} marker The marker
   * @param {string} eventType The event type
   * @param {object} params The params for the point
   */
  DvtGoogleMapProvider.prototype.attachGMapEventListener = function (map, marker, eventType, params)
  {
    var that = this;
    switch (eventType)
    {
      case DvtGoogleMapProvider.MOUSE_OVER:
        google.maps.event.addListener(marker, DvtGoogleMapProvider.MOUSE_OVER, function ()
        {
          if (!marker.selected)
          {
            marker.setIcon(that.getGoogleIcon(params, true));
          }
          else
          {
            marker.setIcon(that.getGoogleIcon(params, true));
          }
        });
        break;
      case DvtGoogleMapProvider.MOUSE_OUT:
        google.maps.event.addListener(marker, DvtGoogleMapProvider.MOUSE_OUT, function ()
        {
          if (!marker.selected)
          {
            marker.setIcon(that.getGoogleIcon(params));
          }
        });
        break;
      case DvtGoogleMapProvider.CLICK:
        google.maps.event.addListener(marker, DvtGoogleMapProvider.CLICK, function ()
        {
          if (marker.params.labelPosition == "bubble")
          {
            return;
          }
          that.updateSelection(map, marker);
          var id = params['dataLayerId'];
          var evt = new adf.mf.internal.dvt.geomap.events.DvtGeoMapSelectionEvent(map.selection[id]);
          evt.addParam('dataLayerId', id);
          map.dispatchEvent(evt);
        });
        break;
      default :
        break;
    }
  };

  /**
   * Zoom to a single marker
   * @param {object} gmap the Google map
   * @param {object} markerLatLng the LatLng google maps object
   * @param {number} zoomLevel the zoom level (optional)
   */
  DvtGoogleMapProvider.prototype.zoomToMarker = function (gmap, markerLatLng, zoomLevel)
  {
    gmap.setCenter(markerLatLng);
    if (zoomLevel)
      gmap.setZoom(zoomLevel);
  };

  /**
   * Get the params for the point
   *
   * @param {object} point The data object
   * @return {object} params The params for the point
   */
  DvtGoogleMapProvider.prototype.getParams = function (point)
  {
    var tooltip = this.getTooltip(point);
    var source = this.getSource(point);
    var sourceHover = this.getSourceHover(point);
    var sourceSelected = this.getSourceSelected(point);
    var sourceHoverSelected = this.getSourceHoverSelected(point);
    var rowKey = point['_rowKey'];
    var clientId = point['clientId'];
    var params = {};

    params['label'] = point['label'];
    params['labelPosition'] = point['labelPosition'];
    params['labelStyle'] = point['labelStyle'];
    params['selectedLabelStyle'] = point['selectedLabelStyle'];
    params['width'] = point['width'] || (32);
    params['height'] = point['height'] || (32);
    params['scaleX'] = point['scaleX'] || 1;
    params['scaleY'] = point['scaleY'] || 1;
    params['rotation'] = point['rotation'] || 0;
    params['opacity'] = point['opacity'] || 1;
    params['source'] = source;
    params['sourceHover'] = sourceHover;
    params['sourceSelected'] = sourceSelected;
    params['sourceHoverSelected'] = sourceHoverSelected;
    params['tooltip'] = tooltip;
    if (point['action'])
      params['action'] = point['action'];
    params['rowKey'] = rowKey;
    params['clientId'] = clientId;
    params['renderMarker'] = point['renderMarker'];
    params['markerIconDisplay'] = 
      point['markerIconDisplay'] == "on" ? true :
      point['markerIconDisplay'] == "off" ? false :
      !point['label'] ? true :
      params['labelPosition'] != "bubble";
    return params;
  };

  /**
   * Get dataSelection mode
   * @param {object} dataLayer The dataLayer
   * @return {string} The selection mode
   */
  DvtGoogleMapProvider.prototype.getSelMode = function (dataLayer)
  {
    var selMode = DvtGoogleMapProvider.SEL_NONE;
    if (dataLayer['dataSelection'])
      selMode = dataLayer['dataSelection'];

    return selMode;
  };

  /**
   * Get marker tooltip
   * @param {object} point
   * @return {string} The tooltip
   */
  DvtGoogleMapProvider.prototype.getTooltip = function (point)
  {
    var tooltip = null;
    if (point['shortDesc'])
      tooltip = point['shortDesc'];
    
    if (tooltip == null && point['label'])
      tooltip = point['label'];

    return tooltip;
  };

  /**
   * Get marker source URL
   * @param {object} point
   * @return {string} The source URL
   */
  DvtGoogleMapProvider.prototype.getSource = function (point)
  {
    var source;
    if (point['source'])
      source = point['source'];
    else
    {
      source = DvtGoogleMapProvider.DEFAULT_GOOGLE_MARKER_IMG;
    }
    return source;
  };

  /**
   * Get marker sourceSelected URL
   * @param {object} point
   * @return {string} The sourceSelected URL
   */
  DvtGoogleMapProvider.prototype.getSourceSelected = function (point)
  {
    var sourceSelected;
    if (point['sourceSelected'])
      sourceSelected = point['sourceSelected'];
    else
    {
      sourceSelected = DvtGoogleMapProvider.DEFAULT_GOOGLE_MARKER_SELECT_IMG;
    }
    return sourceSelected;
  };

  /**
   * Get marker sourceHover URL
   * @param {object} point
   * @return {string} The sourceHover URL
   */
  DvtGoogleMapProvider.prototype.getSourceHover = function (point)
  {
    var sourceHover;
    if (point['sourceHover'])
      sourceHover = point['sourceHover'];
    else
    {
      sourceHover = DvtGoogleMapProvider.DEFAULT_GOOGLE_MARKER_HOVER_IMG;
    }
    return sourceHover;
  };

  /**
   * Get marker sourceHoverSelected URL
   * @param {object} point
   * @return {string} The sourceHoverSelected URL
   */
  DvtGoogleMapProvider.prototype.getSourceHoverSelected = function (point)
  {
    var sourceHoverSelected;
    if (point['sourceHoverSelected'])
      sourceHoverSelected = point['sourceHoverSelected'];
    else
    {
      sourceHoverSelected = DvtGoogleMapProvider.DEFAULT_GOOGLE_MARKER_SELECT_IMG;
    }
    return sourceHoverSelected;
  };

  /**
   * Get minimum number
   * @param {number} min
   * @param {number} n
   * @return {number} min
   */
  DvtGoogleMapProvider.prototype.getMin = function (min, n)
  {
    if (min == null || min > n)
      min = n;
    return min;
  };

  /**
   * Get maximum number
   * @param {number} max
   * @param {number} n
   * @return {number} max
   */
  DvtGoogleMapProvider.prototype.getMax = function (max, n)
  {
    if (max == null || max < n)
      max = n;
    return max;
  };

  /**
   * If selection is enabled, returns the initial selection status for a data layer.
   * On first render, returns array of row keys found in the 'selectedRowKeys' property.
   * On re-render, returns the previously selected row keys
   * @private
   * @param {object} map
   * @param {object} dataLayer
   * @param {string} id dataLayer id
   * @return {array} array of selected row keys
   */
  DvtGoogleMapProvider.prototype._getSelectedRowKeys = function (map, dataLayer, id)
  {
    var selMode = this.getSelMode(dataLayer);
    var selectedRowKeys = [];

    // if data selection is off, nothing to do
    if (selMode === DvtGoogleMapProvider.SEL_SINGLE || selMode === DvtGoogleMapProvider.SEL_MULTIPLE)
    {
      // first time through, check if there's an initial selection to be set
      if (!map.initialSelectionApplied)
      {
        if (dataLayer['selectedRowKeys'] !== undefined)
        {
          selectedRowKeys = dataLayer['selectedRowKeys'].split(' ');
        }
      }
      else // next time, preserve existing selections
      {
        var selection = map['selection'][id];// selected points for this layer
        if (selection)
        {
          for (var i = 0;i < selection.length;i++)
          {
            selectedRowKeys.push(selection[i]['rowKey']);
          }
          // clear the previous selection as we'll populate a new one
          selection.length = 0;
        }
      }
    }
    return selectedRowKeys;
  };

  /**
   * Checks if the map includes any data layers.
   * @private
   * @param {object} map DvtGeographicMap instance
   * @return {boolean} true if the map includes any data layers, false otherwise
   */
  DvtGoogleMapProvider.prototype._mapIncludesData = function (map)
  {
    var data = map['Data'];

    if (data && data['routes'] && data['routes'].length > 0)
      return true;

    if (!data || !data['dataLayers'] || Object.keys (data['dataLayers']).length == 0)
      return false;

    return true;
  };

  /**
   * Sets a new map center position.
   * 
   * @param {Object} map - map instance
   * @param {string} centerX - new center x position (longitude)
   * @param {string} centerY - new center y position (latitude)
   */
  DvtGoogleMapProvider.prototype.moveCenter = function(map, centerX, centerY)
  {
    var newLong = parseFloat(centerX);
    var newLat = parseFloat(centerY);

    var gmap = map['_googlemap'];
    if (gmap)
    {
      gmap.setCenter(new google.maps.LatLng(newLat, newLong));
    }
  };

  /**
   * Sets new zoom level in an existing map.
   * 
   * @param {Object} map - map instance
   * @param {string} zoomLevel - new zoom level
   */
  DvtGoogleMapProvider.prototype.updateZoomLevel = function(map, zoomLevel)
  {
    var newZoomLevel = parseInt(zoomLevel);

    var gmap = map['_googlemap'];
    if (gmap)
    {
      gmap.setZoom(newZoomLevel);
    }
  };

  adf.mf.internal.dvt.geomap.DvtGeographicMap.registerMapProvider("googlemaps", DvtGoogleMapProvider);
})();
/* Copyright (c) 2013, 2017 Oracle and/or its affiliates. All rights reserved. */
/*
 *    geoMap/providers/DvtOracleMapProvider.js
 */
(function ()
{
  /**
   * Map provider for DvtGeographicMap.
   * @class
   */
  var DvtOracleMapProvider = function ()
  {
    this._oracleMVApiLoaded = false;
    this._omvapiLoading = false;
  };

  adf.mf.internal.dvt.DvtmObject.createSubclass(DvtOracleMapProvider, 'adf.mf.internal.dvt.DvtmObject', 'DvtOracleMapProvider', 'PRIVATE');

  DvtOracleMapProvider.MAP_VIEWER_URL = 'https://elocation.oracle.com/mapviewer';
  DvtOracleMapProvider.ELOCATION_BASE_URL = 'https://elocation.oracle.com/elocation';
  DvtOracleMapProvider.BASE_MAP = 'ELOCATION_MERCATOR.WORLD_MAP';

  DvtOracleMapProvider.SUPPORTED_VERSIONS = ['v2.2', 'v2.1', 'v2'];

  DvtOracleMapProvider.DEFAULT_ORACLE_MARKER_IMG = 'css/images/geomap/ball_ena.png';
  DvtOracleMapProvider.DEFAULT_ORACLE_MARKER_HOVER_IMG = 'css/images/geomap/ball_ovr.png';
  DvtOracleMapProvider.DEFAULT_ORACLE_MARKER_SELECT_IMG = 'css/images/geomap/ball_sel.png';
  DvtOracleMapProvider.DEFAULT_EMPTY_MARKER_IMG = "data:image/x-icon;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQEAYAAABPYyMiAAAABmJLR0T///////8JWPfcAAAACXBIWXMAAABIAAAASABGyWs+AAAAF0lEQVRIx2NgGAWjYBSMglEwCkbBSAcACBAAAeaR9cIAAAAASUVORK5CYII=";
  
  DvtOracleMapProvider.MOUSE_DOWN = 'mousedown';
  DvtOracleMapProvider.MOUSE_UP = 'mouseup';
  DvtOracleMapProvider.MOUSE_OVER = 'mouseover';
  DvtOracleMapProvider.MOUSE_OUT = 'mouseout';
  DvtOracleMapProvider.MOUSE_CLICK = 'click';

  DvtOracleMapProvider.TOUCH_START = 'touchstart';
  DvtOracleMapProvider.TOUCH_END = 'touchend';
  DvtOracleMapProvider.TOUCH_CANCEL = 'touchcancel';

  DvtOracleMapProvider.SEL_NONE = 'none';
  DvtOracleMapProvider.SEL_SINGLE = 'single';
  DvtOracleMapProvider.SEL_MULTIPLE = 'multiple';

  DvtOracleMapProvider.prototype.loadApi = function (config, success, error)
  {
    var that = this;
    if (this._omvapiLoading === true)
    {
      return;
    }

    if (this._oracleMVApiLoaded === true)
    {
      success.call(that);
      return;
    }

    this._omvapiLoading = true;

    var mapViewerUrl = config['mapViewerUrl'] || DvtOracleMapProvider.MAP_VIEWER_URL;;

    var elocationUrl = config['eLocationUrl'] || DvtOracleMapProvider.ELOCATION_BASE_URL;

    var proxyUrl = config['proxyUrl'] || null;

    var errorCallback = function()
    {
      that._oracleMVApiLoaded = false;
      that._omvapiLoading = false;
      error.call(that);
    };
    // 30 seconds timeout for the file evaluation
    var counter = 30 * 1000 / 100;
    // all available versions of OM api 
    // it is not certain which version will be available on target
    // mapviewer server so we need to try every version in descending
    // order
    var versions = [].concat(DvtOracleMapProvider.SUPPORTED_VERSIONS);

    if (config['apiVersion'])
    {
      // if api version is defined try to load this version first
      versions.unshift(config['apiVersion']);
    }

    var version = versions.shift();
    // we have to set timeout to find out when the Oracle Maps(OM) api is fully loaded
    var timer = setInterval(function()
    {
      // verify existence of the OM.version property
      if (window.OM !== undefined && OM.version)
      {
        // set jquery if any to prevent any colisions
        if ($)
        {
          OM.setJQuery($);
        }

        clearInterval(timer);

        // initial environment configuration
        if (proxyUrl)
        {
          OM.gv.setProxyPath(proxyUrl);
        }

        OM.gv.setResourcePath(mapViewerUrl + '/jslib/' + version + '/');
        OM.gv.setBaseMapViewerURL(mapViewerUrl);
        OM.gv.setSecureHttp(true);

        adf.mf.api.resourceFile.loadJsFile(elocationUrl + '/jslib/oracleelocationv3.js', true, function()
        {
          setTimeout(function()
          {
            // notify about success out of the current stack
            that._oracleMVApiLoaded = true;
            that._omvapiLoading = false;
            success.call(that);
          }, 50);
        }, errorCallback);
      }
      else if (counter === 0)
      {
        clearInterval(timer);
        errorCallback();
      }

      counter--;
    }, 100);

    // in case that it is impossible to load current api version try to load older api version
    var loadFail = function()
    {
      // fire error in case that it is impossible to load any mv api version
      if (versions.length === 0)
      {
        errorCallback();
        return;
      }

      // reset counter since we will try to load api again
      counter = 30 * 1000 / 100;
      // get next older version
      version = versions.shift();
      // load url according version
      adf.mf.api.resourceFile.loadJsFile(mapViewerUrl + '/jslib/' + version + '/oraclemapsv2.js', true,
      function ()
      {
        /* do nothing here and let timeout check to verify that api is successfuly loaded. */
      },
      loadFail);
    };

    // start loading the latest api version
    adf.mf.api.resourceFile.loadJsFile(mapViewerUrl + '/jslib/' + version + '/oraclemapsv2.js', true,
    function ()
    {
      /* do nothing here and let timeout check to verify that api is successfuly loaded. */
    },
    loadFail);
  };

  /**
   * Renders the geographic map in the specified area.
   * @param {DvtGeographicMap} map The geographic map being rendered.
   * @param {object} mapCanvas The div to render the map.
   * @param {number} width The width of the component.
   * @param {number} height The height of the component.
   */
  DvtOracleMapProvider.prototype.render = function (map, mapCanvas, width, height)
  {
    if (this._oracleMVApiLoaded === false)
    {
      throw "OM api is not loaded!";
    }
    this.renderOracleMap(map, mapCanvas, width, height);
  };

  DvtOracleMapProvider.prototype.destroy = function(map)
  {
    if (map['_inputEvents'])
    {
      map['_inputEvents'].forEach(function(t)
      {
        window.clearTimeout(t);
      });
      map['_inputEvents'].length = 0;
    }

    if (map['_mapEvents'])
    {
      map['_mapEvents'].forEach(function(t)
      {
        window.clearTimeout(t);
      });
      map['_mapEvents'].length = 0;
    }

    if (map['_instance'])
    {
      map['_instance'].destroyMap();
      delete map['_instance'];
    }
  };
  
  /**
   * Renders the geographic map in the specified area.
   * @param {DvtGeographicMap} map The geographic map being rendered.
   * @param {object} mapCanvas The div to render the map.
   * @param {number} width The width of the component.
   * @param {number} height The height of the component.
   * @this
   */
  DvtOracleMapProvider.prototype.renderOracleMap = function (map, mapCanvas, width, height)
  {
    var options = map.Options;
    var data = map.Data;
    var baseURL = map.getMapViewerUrl();
    var baseMap = map.getBaseMap();
    var mapCenterLon = options.mapOptions.centerX;
    var mapCenterLat = options.mapOptions.centerY;
    var mapZoom = options.mapOptions.zoomLevel;
    var doubleClickAction = 'recenter';
    var initialZooming = true;

    if (!this._mapIncludesData(map))
    {
      initialZooming = false;
    }
    else if (options.mapOptions.initialZooming)
    {
      initialZooming = options.mapOptions.initialZooming == 'none' ? false : true;
    }

    var mpoint;
    if (!map['center'])
    {
      mpoint = new OM.geometry.Point(parseFloat(mapCenterLon), parseFloat(mapCenterLat), 8307);
    }
    else
    {
      mpoint = map['center'];
    }
    
    var lastZoom;
    if (!map['lastZoom']) 
    {
      lastZoom = mapZoom;
    }
    else
    {
      lastZoom = map['lastZoom'];
    }


    if (map['_inputEvents'])
    {
      map['_inputEvents'].forEach(function(t)
      {
        window.clearTimeout(t);
      });
      map['_inputEvents'].length = 0;
    }

    if (map['_mapEvents'])
    {
      map['_mapEvents'].forEach(function(t)
      {
        window.clearTimeout(t);
      });
      map['_mapEvents'].length = 0;
    }

    map['_firstTime'] = false;
    if (!map['_instance'] || map['_lastKey'] !== (baseURL + '/' + baseMap))
    {
      map['_lastKey'] = baseURL + '/' + baseMap;
      map['_instance'] = new OM.Map(mapCanvas, { mapviewerURL : baseURL });
      map['_instance'].enableZoomAnimation(true);
      map['_firstTime'] = true;
      map['_inputEvents'] = [];
      map['_mapEvents'] = [];
      baseMap = baseMap.split('.');

      var tileLayer = map['_instance'].getLayerByName('_tilelayer');
      if (!tileLayer)
      {
        tileLayer = new OM.layer.TileLayer('_tilelayer',
        {
          dataSource: baseMap[0],
          tileServerURL: baseURL + '/mcserver',
          tileLayer: baseMap[1]
        });
        map['_instance'].addLayer(tileLayer);
      }

      var fireMapBoundsChangeEvent = function ()
      {
        if (!options.mapOptions.hasMapBoundsChangeActionListener)
        {
          return;
        }

        var bbox = map['_instance'].getMapWindowBoundingBox();
        // return immediately if properties not initialized
        if (!bbox)
          return;

        var zoomLevel = map['_instance'].getMapZoomLevel();

        var callback = function (geom)
        {
          var centerGeom = geom.getCenter();

          var evt = new adf.mf.internal.dvt.geomap.events.DvtMapBoundsChangeEvent(geom.getMinX(), geom.getMinY(), geom.getMaxX(), geom.getMaxY(), centerGeom.getX(), centerGeom.getY(), zoomLevel);
          var t = setTimeout(function(e)
          {
            map.dispatchEvent(e);
          }, 0, evt);
          map['_mapEvents'].push(t);
        };
        // convert to the 8307 coords system
        bbox.transform(8307, callback);
      };

      var recenter = function ()
      {
        options.mapOptions.initialZooming = 'none';
        map['center'] = map['_instance'].getMapCenter();
        fireMapBoundsChangeEvent();
      };

      var zoom = function (beforeLevel, afterLevel)
      {
        options.mapOptions.initialZooming = 'none';
        options.mapOptions.zoomLevel = '' + map['_instance'].getMapZoomLevel();
        map['lastZoom'] = options.mapOptions.zoomLevel;
        fireMapBoundsChangeEvent();
      };

      var clickHandler = function (eventId)
      {
        if (!options.mapOptions.hasMapInputActionListener)
        {
          return;
        }
        // convert to the 8307 coords system
        var callback = function (geom)
        {
          var t = setTimeout(function(g, id)
          {
            var evt = new adf.mf.internal.dvt.geomap.events.DvtMapInputEvent(id, g.getX(), g.getY());
            map.dispatchEvent(evt);
          }, 100, geom, eventId);
          map['_inputEvents'].push(t);
        };

        var location = map['_instance'].getCursorLocation();
        location.transform(8307, callback);
      };

      map['_instance'].addListener(OM.event.MapEvent.MAP_RECENTERED, recenter);
      map['_instance'].addListener(OM.event.MapEvent.MAP_RESIZED, recenter);
      map['_instance'].addListener(OM.event.MapEvent.MAP_AFTER_ZOOM, zoom);

      map['_instance'].addListener(OM.event.MouseEvent.MOUSE_CLICK, function ()
      {
        clickHandler(DvtOracleMapProvider.MOUSE_CLICK)
      });

      map['_instance'].addListener(OM.event.MouseEvent.MOUSE_DOWN, function ()
      {
        clickHandler(DvtOracleMapProvider.MOUSE_DOWN)
      });

      map['_instance'].addListener(OM.event.MouseEvent.MOUSE_UP, function ()
      {
        clickHandler(DvtOracleMapProvider.MOUSE_UP)
      });
    }

    map.initialSelectionApplied = false;
    var mapview = map['_instance'];

    if (map['_firstTime'] === true)
    {
      if (!initialZooming)
      {
        mapview.setMapCenter(mpoint);
      }

      // filter all empty values
      if (mapZoom)
      {
        mapview.setMapZoomLevel(parseInt(mapZoom));
      }
    } 
    else if (!initialZooming)
    {
      mapview.setMapCenter(mpoint, true);
      if (mapZoom)
      {
        var newZoom = parseInt(lastZoom);
        if (newZoom !== mapview.getMapZoomLevel())
        {
          mapview.setMapZoomLevel(newZoom, true);
        }
      }
    }

    var initedLayers = {};
    // render routes
    this.renderOracleRoutes(map, mapview, data, initedLayers, initialZooming);
    // set the data layer
    this.setOracleMapDataLayer(map, mapview, data, initedLayers, initialZooming);

    if (!map['_jobs'])
    {
      this.renderOracleMapEnd(map, mapview, initedLayers);
    }
  };

  DvtOracleMapProvider.prototype.renderOracleMapEnd = function (map, mapview, initedLayers)
  {
    if (map['_firstTime'] === true)
    {
      mapview.init();
    }

    // remove unused layers and bring selected features to top
    // if layer supports selection
    this.postProcessLayers(map, mapview, initedLayers);

    map.dispatchEvent({ 'type': 'ready' });
  };

  DvtOracleMapProvider.prototype.postProcessLayers = function(map, mapview, initedLayers)
  {
    var layers = mapview.getFeatureLayers().slice();

    layers.forEach(function(layer)
    {
      if (layer.isInternalUtilLayer())
      {
        // do nothing for internal layers
        return;
      }

      var rendered = initedLayers[layer.getName()];
      if (!rendered)
      {
        mapview.removeLayer(layer);
      }
      else
      {
        var features = layer.getAllFeatures().slice();
        features.forEach(function(feature)
        {
          if (!feature['_params'])
          {
            return;
          }
          if (rendered.indexOf(feature['_params']['clientId']) == -1)
          {
            if (feature['_related'])
            {
              layer.removeFeature(feature['_related']);
            }
            layer.removeFeature(feature);
          }
          else 
          {
            if (feature['_params']['selected'])
            {
              layer.sendFeatureToBottom(feature);
              feature.bringToTop();
            }
          }
        });
      }
    });
  };

  DvtOracleMapProvider.prototype.renderOracleRoutes = function(map, mapview, data, initedLayers, initialZooming)
  {
    if (!data.routes || data.routes.length === 0)
      return;

    var eloc = this._eloc || (this._eloc = new OracleELocation(map.getELocationUrl()));

    var that = this;
    var createClickHandler = function (clientId, action)
    {
      return function ()
      {
        var geom = mapview.getCursorLocation();
        that.dispatchActionEvent(map, mapview, geom, { 'action': action, 'clientId': clientId }, 'click');
      };
    };

    var wayPointTranslator = function (point)
    {
      if (point['address'])
      {
        return point['address'];
      }
      return { lat : point['y'], lon : point['x']};
    };

    var that = this;
    var markerParamTranslator = function (point)
    {
      if (point['displayMarker'] !== true)
      {
        return null;
      }
      return that.getParams(point);
    };

    var destinations = data.routes.map(function(route)
    {
      return route["wayPoints"].map(wayPointTranslator);
    });

    var routeStyles = [];
    data.routes.forEach(function(routeOptions)
    {
      initedLayers[routeOptions['id']] = [];
      var routeStyle = routeOptions['style']['default'];
      var opacity = routeStyle['opacity'];
      if (opacity == null)
      {
        opacity = 1;
      }
      opacity = Math.round(opacity * 255);
      routeStyles.push({
        'render_style':
        {
          'color' : routeStyle['color'] || '#1fb5fb',
          'opacity' : opacity,
          'width' : routeStyle['width'] || 8
        },
        'label': "route"
      });
    });
    var foiCount = 50000;
    eloc.getDirections(destinations,
      function(geocode, routes)
      {
        (routes || []).forEach(function(route, i)
        {
          var routeOptions = data.routes[i];
          var params = routeOptions["wayPoints"].map(markerParamTranslator);

          var routeAction = routeOptions['action'];
          var routeId = routeOptions['id'];
          var vectorLayer = mapview.getLayerByName(routeId);
          if (!vectorLayer)
          {
            vectorLayer = new OM.layer.VectorLayer(routeId, { def: {type: OM.layer.VectorLayer.TYPE_LOCAL}});
            vectorLayer.enableInfoWindow(false);
            mapview.addLayer(vectorLayer);

            var actionListener = function(context)
            {
              var feature = context.feature;
              var params = feature['_params'];

              feature.bringToTop();

              if (params['action'])
              {
                var actionType = context.data ? context.data.type : 'click';
                var at = setTimeout(function(g, p, t)
                {
                  map['_inputEvents'].forEach(function(e){
                    window.clearTimeout(e);
                  });
                  map['_inputEvents'].length = 0;

                  that.dispatchActionEvent(map, mapview, g, p, t);
                }, 20, feature.getGeometry(), params,  actionType);
                map['_mapEvents'].push(at);
              }
            }

            var wrapWithNoPropagation = function (fn)
            {
              return function (context)
              {
                context.evt.preventDefault();
                context.evt.stopImmediatePropagation();
                context.evt.stopPropagation();
                fn.call(this, context);
                return false;
              }
            };

            if (amx.hasTouch())
            {
              vectorLayer.addListener(OM.event.MouseEvent.TOUCH_TAP, wrapWithNoPropagation(function(context)
              {
                context.data = { 'type' : "click"};
                actionListener.call(this, context);
                delete context.data;
              }));
              vectorLayer.addListener(OM.event.MouseEvent.TOUCH_LONG_PRESS, wrapWithNoPropagation(function(context)
              {
                context.data = { 'type' : "tapHold"};
                actionListener.call(this, context);
                delete context.data;
              }));
            }
            else
            {
              // function that registers 
              var registrator = function(start, stop, cancel)
              {
                vectorLayer.addListener(OM.event.MouseEvent.MOUSE_DOWN, wrapWithNoPropagation(start));
                vectorLayer.addListener(OM.event.MouseEvent.MOUSE_UP, wrapWithNoPropagation(stop));
                vectorLayer.addListener(OM.event.MouseEvent.MOUSE_OUT, wrapWithNoPropagation(cancel));
              };
              vectorLayer.addListener(OM.event.MouseEvent.MOUSE_CLICK, wrapWithNoPropagation(function() { }));
              _addTapHoldEventListener(vectorLayer, registrator, actionListener);
            }
          }
          else
          {
            vectorLayer.removeAllFeatures();
          }

          if (!route.subroutes)
          {
            eloc.attachEventListenerToRoute(route.routeId, OM.event.MouseEvent.MOUSE_CLICK, createClickHandler(routeId, routeAction));
            eloc.attachEventListenerToRoute(route.routeId, OM.event.MouseEvent.TOUCH_TAP, createClickHandler(routeId, routeAction));
          }
          else
          {
            route.subroutes.forEach(function(subroute, si)
            {
              eloc.attachEventListenerToRoute(subroute.routeId, OM.event.MouseEvent.MOUSE_CLICK, createClickHandler(routeId, routeAction));
              eloc.attachEventListenerToRoute(subroute.routeId, OM.event.MouseEvent.TOUCH_TAP, createClickHandler(routeId, routeAction));
            });
          }
          var points = (geocode || [])[i];
          (points || []).forEach(function(point, i)
          {
            if (params[i])
            {
              params[i]['vectorLayer'] = vectorLayer;
              that.addFeature(map, mapview, point['x'], point['y'], params[i]);
            }
          });
        });
      },
      function()
      {
        adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', "renderOracleRoutes", 'Failed to geocode route!');
      },
      {
        ignoreGeocodeErrorsForBatchRequests: true
      },
      {
        'mapview' : mapview,
        'zoomToFit' : initialZooming,
        'removePreviousRoutes': true,
        'disableLoadingIcon': true,
        'drawMarkers': false,
        'routeStyles': routeStyles  
      });
  };

  var _oracleHasMatch = function(addressResult, address)
  {
    if (addressResult)
    {
      switch (addressResult.matchCode)
      {
        case 1: adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', address, 'Exact match. All fields in the input geocode operation matched values in the geocoding data set.');
          return true;
        case 2: adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', address, 'All of the input fields of the geocoding operation match the geocoding data except the street type, prefix, or suffix.');
          return true;
        case 3: adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', address, 'All of the input fields of the geocoding operation match except the house or building number. Also the street type, prefix, or suffix may not match as well.');
          return true;
        case 4: adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', address, 'The address does not match, but the city name and postal code do match.');
          return true;
        case 10: adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', address, 'The postal code does not match the input geocoding request, but the city name does match.');
          return true;
        case 11: adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', address, 'The postal code matches the data used for geocoding, but the city name does not match.');
          return true;
        case 12: adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', address, 'The region is matched, but the postal code and city name are not matched.');
          return true;
        default:
      }

      if (addressResult.errorMessage)
      {
        adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', address, 'Geocoder error:' + addressResult.errorMessage);
      }
      else
      {
        adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', address, 'No matching address found!');
      }
    }
    else
    {
      adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', address, 'No matching address found!');
    }
    return false;
  };

  DvtOracleMapProvider.prototype._createVectorLayer = function(map, mapview, id)
  {
    var vectorLayer = new OM.layer.VectorLayer(id, { def: {type: OM.layer.VectorLayer.TYPE_LOCAL}});
    vectorLayer.enableInfoWindow(false);
    mapview.addLayer(vectorLayer);
 
    // real listener implementation that handles click and tapHold on the FOI point
    var that = this;
    var actionListener = function (context)
    {
      var actionType = context.data ? context.data.type : 'click';
      var feature = context.feature;
      feature.bringToTop();

      var params = feature['_params'];

      if (actionType == 'click' && (params['selMode'] === DvtOracleMapProvider.SEL_SINGLE || params['selMode'] == DvtOracleMapProvider.SEL_MULTIPLE))
      {
        that.dispatchSelectionEvent(map, mapview, params);
      }
      
      if (params['action'])
      {
        var at = setTimeout(function(g, p, t)
        {
          map['_inputEvents'].forEach(function(e){
            window.clearTimeout(e);
          });
          map['_inputEvents'].length = 0;

          that.dispatchActionEvent(map, mapview, g, p, t);
        }, 20, feature.getGeometry(), params,  actionType);
        map['_mapEvents'].push(at);
      }
    };

    var wrapWithNoPropagation = function (fn)
    {
      return function (context)
      {
        context.evt.preventDefault();
        context.evt.stopImmediatePropagation();
        context.evt.stopPropagation();
        fn.call(this, context);
        return false;
      }
    };

    if (amx.hasTouch())
    {
      vectorLayer.addListener(OM.event.MouseEvent.TOUCH_TAP, wrapWithNoPropagation(function(context)
      {
        context.data = { 'type' : "click"};
        actionListener.call(this, context);
        delete context.data;
      }));
      vectorLayer.addListener(OM.event.MouseEvent.TOUCH_LONG_PRESS, wrapWithNoPropagation(function(context)
      {
        context.data = { 'type' : "tapHold"};
        actionListener.call(this, context);
        delete context.data;
      }));
    }
    else
    {
      var createHoverFunction = function(over)
      {
        return function(context)
        {
          var feature = context.feature;
          var params = feature['_params'];
          
          var action = params['action'];
          var selection = (params['selMode'] == DvtOracleMapProvider.SEL_SINGLE || params['selMode'] == DvtOracleMapProvider.SEL_MULTIPLE);

          if (action || selection)
          {
            var sourceImg = that.getIcon(params, over);

            var name = "dvt_geomap_marker";
            if (params['selected'])
            {
              name = name + "_selected";
            }
            name = name + "_hover";

            var markerStyle = new OM.style.Marker({ styleName: name, src: sourceImg,  height: params['height'], width: params['width'] });
            feature.setRenderingStyle(markerStyle);
          }
        }
      };

      vectorLayer.addListener(OM.event.MouseEvent.MOUSE_OVER, createHoverFunction(true));
      vectorLayer.addListener(OM.event.MouseEvent.MOUSE_OUT, createHoverFunction(false));

      // function that registers 
      var registrator = function(start, stop, cancel)
      {
        vectorLayer.addListener(OM.event.MouseEvent.MOUSE_DOWN, wrapWithNoPropagation(start));
        vectorLayer.addListener(OM.event.MouseEvent.MOUSE_UP, wrapWithNoPropagation(stop));
        vectorLayer.addListener(OM.event.MouseEvent.MOUSE_OUT, wrapWithNoPropagation(cancel));
      };
      vectorLayer.addListener(OM.event.MouseEvent.MOUSE_CLICK, wrapWithNoPropagation(function() { }));
      _addTapHoldEventListener(vectorLayer, registrator, actionListener);
    }

    return vectorLayer;
  };

  /**
   * Set the data layer on oracle map
   * @param {DvtGeographicMap} map The geographic map being rendered.
   * @param {object} mapview The OM.Map
   * @param {object} data The geographic map data object
   * @param {boolean} initialZooming Should the map zoom to the data points
   */
  DvtOracleMapProvider.prototype.setOracleMapDataLayer = function(map, mapview, data, initedLayers, initialZooming)
  {
    var that = this;
    var dataLayers = data['dataLayers'];
    var minX = null;
    var maxX = null;
    var minY = null;
    var maxY = null;

    var dlkeys = Object.keys(dataLayers);

    for (var i = 0, ilength = dlkeys.length; i < ilength; i++)
    {
      var ikey = dlkeys[i];
      var dataLayer = dataLayers[ikey];
      var selMode = this.getSelMode(dataLayer);

      var vectorLayer = mapview.getLayerByName(dataLayer['id']);
      if (!vectorLayer)
      {
        var vectorLayer = this._createVectorLayer(map, mapview, dataLayer['id']);
      }

      initedLayers[dataLayer['id']] = [];

      var points = dataLayer['data'] || [];
      var selectedRowKeys = this._getSelectedRowKeys(map, dataLayer, ikey);

      var pkeys = Object.keys(points);

      for (var j = 0, jlength = pkeys.length; j < jlength; j++)
      {
        var pkey = pkeys[j];
        var params = this.getParams(points[pkey]);

        params['selMode'] = selMode;
        params['dataLayerId'] = dataLayer['id'];
        params['vectorLayer'] = vectorLayer;
        params['selected'] = selectedRowKeys.indexOf(points[pkey]['_rowKey']) !== -1 ? true : false;
        
        initedLayers[dataLayer['id']].push(params['clientId']);

        if (points[pkey]['x'] && points[pkey]['y'])
        {
          if (points[pkey]['renderMarker'])
          {
            this.addFeature(map, mapview, points[pkey]['x'], points[pkey]['y'], params);
            minX = this.getMin(minX, parseFloat(points[pkey]['x']));
            maxX = this.getMax(maxX, parseFloat(points[pkey]['x']));
            minY = this.getMin(minY, parseFloat(points[pkey]['y']));
            maxY = this.getMax(maxY, parseFloat(points[pkey]['y']));
            if (initialZooming && (i == ilength - 1 && j == jlength - 1))
            {
              if (map['Options']['mapOptions']['explicitZoom'])
              {
                var mpoint = new OM.geometry.Point((minX + maxX) / 2, (minY + maxY) / 2, 8307);
                mapview.setMapCenter(mpoint, true);
              }
              else
              {
                mapview.zoomToExtent(new OM.geometry.Rectangle(minX, minY, maxX, maxY, 8307));
              }
            }
          }
        }
        else if (points[pkey]['address'])
        {
          var addr = points[pkey]['address'];
          var that = this;
          var callback = function (mapParams, address)
          {
            map['_jobs'] = map['_jobs'] ? map['_jobs'] + 1 : 1;
            return function(gcResult)
            {
              map['_jobs'] = map['_jobs'] - 1;
              // one or more matching address is found
              // we get the first one
              var addrObj = gcResult[0];
              if (_oracleHasMatch(addrObj, address))
              {
                that.addFeature(map, mapview, addrObj['x'], addrObj['y'], mapParams);
                // This cannot be simply moved outside the loop because the callback may not be finished after the loop ends
                minX = that.getMin(minX, parseFloat(addrObj['x']));
                maxX = that.getMax(maxX, parseFloat(addrObj['x']));
                minY = that.getMin(minY, parseFloat(addrObj['y']));
                maxY = that.getMax(maxY, parseFloat(addrObj['y']));
              }

              if (map['_jobs'] === 0)
              {
                if (initialZooming)
                {
                  if (minX && maxX && minY && maxY)
                  {
                    if (map['Options']['mapOptions']['explicitZoom'])
                    {
                      var mpoint = new OM.geometry.Point((minX + maxX) / 2, (minY + maxY) / 2, 8307);
                      mapview.setMapCenter(mpoint, true);
                    }
                    else
                    {
                      mapview.zoomToExtent(new OM.geometry.Rectangle(minX, minY, maxX, maxY, 8307));
                    }
                  }
                }

                delete map['_jobs'];
                that.renderOracleMapEnd(map, mapview, initedLayers);
              }
            }
          };

          var eloc = this._eloc || (this._eloc = new OracleELocation(map.getELocationUrl()));
          eloc.geocode(
            addr,
            callback(params, addr),
            function(error, content, a)
              {
                adf.mf.log.Framework.logp(adf.mf.log.level.SEVERE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', a, error);
                adf.mf.log.Framework.logp(adf.mf.log.level.FINE, 'adf.mf.internal.dvt.geomap.DvtOracleMapProvider', a, content);

                map['_jobs'] = map['_jobs'] - 1;

                if (map['_jobs'] === 0)
                {
                  if (initialZooming)
                  {
                    if (minX && maxX && minY && maxY)
                    {
                      if (map['Options']['mapOptions']['explicitZoom'])
                      {
                        var mpoint = new OM.geometry.Point((minX + maxX) / 2, (minY + maxY) / 2, 8307);
                        mapview.setMapCenter(mpoint, true);
                      }
                      else
                      {
                        mapview.zoomToExtent(new OM.geometry.Rectangle(minX, minY, maxX, maxY, 8307));
                      }
                    }
                  }

                  delete map['_jobs'];
                  that.renderOracleMapEnd(map, mapview, initedLayers);
                }
              }
          );
        }
      }
    }
    map.initialSelectionApplied = true;// initial selection has been applied by now
  };

  /**
   * Create bubble html
   * @param {params} params The params for the point foi
   */
  DvtOracleMapProvider.prototype.createInfoBubble = function (params)
  {
    var selected = params['selected'] ? "-selected" : "";

    var labelStyle = (params['selected'] ? params.selectedLabelStyle : params.labelStyle) || "";
    var ariaLabel = params['tooltip'] + '. ';
    if (params['selected'])
    {
      ariaLabel = ariaLabel + adf.mf.resource.getInfoString("AMXInfoBundle", "dvtm_geographicMap_MARKER_STATE_SELECTED") + '.';
    }
    else
    {
      ariaLabel = ariaLabel + adf.mf.resource.getInfoString("AMXInfoBundle", "dvtm_geographicMap_MARKER_STATE_UNSELECTED") + '.';
    }

    var html = 
      "<div style=\"position:absolute\" role=\"button\" aria-label=\"" + ariaLabel + "\">" +
        "<div class=\"dvtm-geographicMap-infoBubble" + selected + "\" " + 
          "style=\"" + labelStyle + "\">" +
          "<span style=\"white-space:nowrap;\">" + params.label + "</span>" +
        "</div>" +
        "<div class=\"dvtm-geographicMap-infoBubble-anchor" + selected + "\">" +
          "<div class=\"dvtm-geographicMap-infoBubble-anchorL" + selected + "\">" +
            "<div class=\"dvtm-geographicMap-infoBubble-anchorLin" + selected + 
            "\" style=\"" + labelStyle + "\">" +
            "</div>" + 
          "</div>" + 
          "<div class=\"dvtm-geographicMap-infoBubble-anchorR" + selected + "\">" +
            "<div class=\"dvtm-geographicMap-infoBubble-anchorRin" + selected + 
            "\" style=\"" + labelStyle + "\">" +
            "</div>" + 
          "</div>" + 
        "</div>" +
      "</div>";
    return html;
  };

  DvtOracleMapProvider.prototype.createInfoLabel = function (params)
  {
    var top = -1;
    var translateY = 0;
    var translateX = -50;

    if (document.documentElement.dir == "rtl")
    {
       translateX *= -1;
    }

    switch (params['labelPosition'])
    {
      case "center" :
        translateY = -50;
        break;
      case "top" :
        top += (-1) * Math.floor(params["height"] / 2);
        translateY = -100;
        break;
      case "bottom" :
      default:
        top += Math.floor(params["height"] / 2);
    }

    var labelStyle = (params['selected'] ? params.selectedLabelStyle : params.labelStyle) || "";
    var ariaLabel = params['tooltip'] + '. ';
    if (params['selected'])
    {
      ariaLabel = ariaLabel + adf.mf.resource.getInfoString("AMXInfoBundle", "dvtm_geographicMap_MARKER_STATE_SELECTED") + '.';
    }
    else
    {
      ariaLabel = ariaLabel + adf.mf.resource.getInfoString("AMXInfoBundle", "dvtm_geographicMap_MARKER_STATE_UNSELECTED") + '.';
    }

    var selected = params['selected'] ? " selected" : "";

    var html = "<span " +
      "class=\"dvtm-geographicMap-infoLabel" + selected + "\" " +
      "style=\"" + labelStyle + ";" +
        "position: absolute;" +
        "top: " + top + "px;" +
        "-webkit-transform: translate(" + translateX + "%, " + translateY + "%);" +
        "transform: translate(" + translateX + "%, " + translateY + "%);" +
        "white-space: nowrap;" +
      "\" " +
      "role=\"button\" " +
      "aria-label=\"" + ariaLabel + "\">" +
    params['label'] +
    "</span>";

    return html;
  };
    
  DvtOracleMapProvider.prototype.getIcon = function (params, hover)
  {
    if (params['markerIconDisplay'])
    {
      var paramName = 'source';
      if (hover)
      {
        paramName = paramName + 'Hover';
      }

      if (params['selected'])
      {
        paramName = paramName + 'Selected';
      }
      return params[paramName];
  }
    else
    {
      return DvtOracleMapProvider.DEFAULT_EMPTY_MARKER_IMG;
    }
  };

  DvtOracleMapProvider.prototype.getCustomRenderer = function(fn, map, mapview)
  {
    var that = this;
    var wrapEventWithNoPropagation = function(eventListener)
    {
      return function(event)
      {
        event.preventDefault();
        event.stopImmediatePropagation();
        event.stopPropagation();
        return eventListener.call(this, event);
      }
    };

    var listener = function(event)
    {
      var actionType = event.data ? event.data.type : 'click';
      var params = this['_params'];
      if (actionType == 'click' && (params['selMode'] === DvtOracleMapProvider.SEL_SINGLE || params['selMode'] == DvtOracleMapProvider.SEL_MULTIPLE))
      {
        that.dispatchSelectionEvent(map, mapview, params);
      }

      if (params['action'])
      {
        var geom = feature.getGeometry();
        that.dispatchActionEvent(map, mapview, geom, params, event.data ? event.data.type : 'click');
      }
    };

    return function(rootLabelDiv, feature)
    {
      rootLabelDiv.style.overflow = 'visible';

      rootLabelDiv.innerHTML = fn.call(that, feature['_params']) || '';

      var registrator;

      if (amx.hasTouch())
      {
        registrator = function(start, stop, cancel)
        {
          rootLabelDiv.addEventListener(DvtOracleMapProvider.TOUCH_START, wrapEventWithNoPropagation(start));
          rootLabelDiv.addEventListener(DvtOracleMapProvider.TOUCH_END, wrapEventWithNoPropagation(stop));
          rootLabelDiv.addEventListener(DvtOracleMapProvider.TOUCH_CANCEL, wrapEventWithNoPropagation(cancel));
        };
      }
      else
      {
        registrator = function(start, stop, cancel)
        {
          rootLabelDiv.addEventListener(DvtOracleMapProvider.MOUSE_DOWN, wrapEventWithNoPropagation(start));
          rootLabelDiv.addEventListener(DvtOracleMapProvider.MOUSE_UP, wrapEventWithNoPropagation(stop));
          rootLabelDiv.addEventListener(DvtOracleMapProvider.MOUSE_OUT, wrapEventWithNoPropagation(cancel));
        };
      }
      _addTapHoldEventListener(feature, registrator, listener);
    };
  };

  /**
   * Add point FOI to map
   * @param {DvtGeographicMap} map The geographic map being rendered.
   * @param {object} mapview The map view
   * @param {object} point The point
   * @param {string} pointId The point ID
   * @param {params} params The params for the point foi
   */
  DvtOracleMapProvider.prototype.addFeature = function (map, mapview, x, y, params)
  {
    var action = params['action'];
    var selMode = params['selMode'];
    var selection = (selMode == DvtOracleMapProvider.SEL_SINGLE || selMode == DvtOracleMapProvider.SEL_MULTIPLE);
    var dataLayerId = params['dataLayerId'];
    var selected = selection && (params['selected'] || false);
    var vectorLayer = params['vectorLayer'];

    var sourceImg = this.getIcon(params);
    var name = "dvt_geomap_marker";
    if (selected)
    {
      name = name + "_selected";
    }
    var markerStyle = new OM.style.Marker({ styleName: name, src: sourceImg,  height: params['height'], width: params['width'] });
    var geoPoint = new OM.geometry.Point(parseFloat(x), parseFloat(y), 8307);

    var feature = vectorLayer.getFeature(params['clientId']);
    if (!feature)
    {
      var markerOptions = {
        renderingStyle: markerStyle,
        label: params['label'] || params['tooltip']
      };

      feature = new OM.Feature(params['clientId'], geoPoint, markerOptions);
      feature['_params'] = params;

      vectorLayer.addFeature(feature);
    }
    else
    {
      feature['_params'] = params;
      feature.setGeometry(geoPoint);
      feature.setLabel(params['label'] || params['tooltip']);
      feature.setRenderingStyle(markerStyle);
    }

    var relatedFeature = feature['_related'];
    if (relatedFeature)
    {
      vectorLayer.removeFeature(relatedFeature);
    }

    var relatedFeatureRenderingStyle = null;

    if (params['label'])
    {
      var fn = null;
      if (params['labelPosition'] == "bubble")
      {
        fn = this.createInfoBubble;
      }
      else
      {
        fn = this.createInfoLabel;
      }

      relatedFeatureRenderingStyle = new OM.style.Div(
        {
          width: 1,
          height: 1,
          customRenderer : this.getCustomRenderer(fn, map, mapview)
        });
    }

    if (relatedFeatureRenderingStyle)
    {
      var relatedFeature = new OM.Feature(params['clientId'] + "_related", geoPoint, { "renderingStyle": relatedFeatureRenderingStyle });
      feature['_related'] = relatedFeature;
      relatedFeature['_params'] = params;
      relatedFeature['_ignore'] = true;

      vectorLayer.addFeature(relatedFeature);
    }

    if (selected)
    {
      map['_selectedFeature'] = feature;
    }
  };

  DvtOracleMapProvider.prototype.dispatchSelectionEvent = function(map, mapview, params)
  {
    var vectorLayer = params['vectorLayer'];
    var feature = vectorLayer.getFeature(params['clientId']);
    params['selected'] = !params['selected'];

    if (params['selMode'] === DvtOracleMapProvider.SEL_SINGLE)
    {
      var prevMarker = map['_selectedFeature'];
      if (prevMarker && prevMarker != feature)
      {
        prevMarker['_params']['selected'] = false;
        var sourceImg = this.getIcon(prevMarker['_params']);         
        var name = "dvt_geomap_marker";
        var prevMarkerStyle = new OM.style.Marker({ styleName: name, src: sourceImg,  height: params['height'], width: params['width'] });
        
        prevMarker.setRenderingStyle(prevMarkerStyle);
        var prevRelated = prevMarker['_related'];
        if (prevRelated)
        {
          vectorLayer.redrawFeature(prevRelated);
        }
      }
      map['_selectedFeature'] = feature;
    }

    var sourceImg = this.getIcon(feature['_params']);
    var name = "dvt_geomap_marker";
    if (params['selected'])
    {
      name = name + "_selected";
    }
    var markerStyle = new OM.style.Marker({ styleName: name, src: sourceImg,  height: params['height'], width: params['width'] });
    var related = feature['_related'];

    feature.setRenderingStyle(markerStyle);
    if (related)
    {
      vectorLayer.redrawFeature(related);
    }

    var st = setTimeout(function(keys, id)
    {
      map['_inputEvents'].forEach(function(t)
      {
        window.clearTimeout(t);
      });
      map['_inputEvents'].length = 0;

      var evt = new adf.mf.internal.dvt.geomap.events.DvtGeoMapSelectionEvent(keys);
      evt.addParam('dataLayerId', id);
      map.dispatchEvent(evt);
    },
    10,
    vectorLayer.getAllFeatures()
    .filter(function(feature)
      {
        return !feature['_ignore'] && feature['_params'] && feature['_params']['selected'];
      })
    .map(function(feature)
      {
        return feature['_params'];
      }),
    vectorLayer.getName());
    
    map['_mapEvents'].push(st);
  };

  DvtOracleMapProvider.prototype.dispatchActionEvent = function(map, mapview, geom, params, actionType)
  {
    var actionEvent = new adf.mf.internal.dvt.geomap.events.DvtMapActionEvent(params['clientId'], params['rowKey'], params['action']);
    actionEvent.addParam('dataLayerId', params['dataLayerId']);
    actionEvent.addParam('actionType', actionType || 'click');

    var pixel = mapview.getScreenLocation(geom);

    if (pixel && geom)
    {
      actionEvent.addParam('pointXY',
      {
        'x' : pixel.x, 'y' : pixel.y
      });
      // report lat/long in 8307 coordinate system
      var callback = function (transGeom)
      {
        actionEvent.addParam('latLng',
        {
          'lat' : transGeom.getY(), 'lng' : transGeom.getX()
        });
        map.dispatchEvent(actionEvent);
      };
      geom = geom.transform(8307, callback);
    }
  };

  // --------- Tap Hold --------- //
  var tapHoldPendingIds = {};

  function cancelPendingTapHold()
  {
    tapHoldPendingIds = {};
  }

  var holdThreshold = 800;

  var _addTapHoldEventListener = function(marker, listenerAddCallback, listener, eventData)
  {
    eventData = eventData || {};
    var tapId = null;
    var startListener = function(event)
    {
      tapId = amx.uuid(); // TODO don't use amx.foo!
      tapHoldPendingIds[tapId] = new Date().getTime();

      setTimeout(function()
      {
        // Note: here we double check if the time is greater than the threshold. This is useful since sometime timeout
        //       is not really reliable.
        if (tapHoldPendingIds[tapId] > 0)
        {
          delete tapHoldPendingIds[tapId];
          // Call the listener but make sure our eventData is used:
          var eventDataToRestore = event.data;
          event.data = eventData;
          event.data.type = "tapHold";
          listener.call(marker, event);
          event.data = eventDataToRestore;
        }

      }, holdThreshold);
    };

    var endListener = function(event)
    {
      if (tapHoldPendingIds[tapId])
      {
        delete tapHoldPendingIds[tapId];
      
        var eventDataToRestore = event.data;
        event.data = eventData;
        event.data.type = "click";
        listener.call(marker, event);
        event.data = eventDataToRestore;
      }
    };

    listenerAddCallback.call(this, startListener, endListener, cancelPendingTapHold);
  };
  // --------- /Tap Hold --------- //

  /**
   * Get the params for the point
   *
   * @param {object} point The data object
   * @return {object} params The params for the point
   */
  DvtOracleMapProvider.prototype.getParams = function (point)
  {
    var tooltip = this.getTooltip(point);
    var source = this.getSource(point);
    var sourceHover = this.getSourceHover(point);
    var sourceSelected = this.getSourceSelected(point);
    var sourceHoverSelected = this.getSourceHoverSelected(point);
    var rowKey = point['_rowKey'];
    var clientId = point['clientId'];
    var params = {};

    params['label'] = point['label'];
    params['labelPosition'] = point['labelPosition'] || 'bottom';
    params['labelStyle'] = point['labelStyle'];
    params['selectedLabelStyle'] = point['selectedLabelStyle'];
    params['width'] = point['width'] || 21;
    params['height'] = point['height'] || 22;
    params['scaleX'] = point['scaleX'] || 1;
    params['scaleY'] = point['scaleY'] || 1;
    params['rotation'] = point['rotation'] || 0;
    params['opacity'] = point['opacity'] || 1;
    params['source'] = source;
    params['sourceHover'] = sourceHover;
    params['sourceSelected'] = sourceSelected;
    params['sourceHoverSelected'] = sourceHoverSelected;
    params['tooltip'] = tooltip;
    if (point['action'])
    {
      params['action'] = point['action'];
    }
    params['rowKey'] = rowKey;
    params['clientId'] = clientId;
    params['renderMarker'] = point['renderMarker'];
    params['markerIconDisplay'] = point['markerIconDisplay'] != "off";

    return params;
  };

  /**
   * Get dataSelection mode
   * @param {object} dataLayer The dataLayer
   * @return {string} The selection mode
   */
  DvtOracleMapProvider.prototype.getSelMode = function (dataLayer)
  {
    if (dataLayer['dataSelection'])
    {
      return dataLayer['dataSelection'];
    }
    return DvtOracleMapProvider.SEL_NONE;
  };

  /**
   * Get marker tooltip
   * @param {object} point
   * @return {string} The tooltip
   */
  DvtOracleMapProvider.prototype.getTooltip = function (point)
  {
    var tooltip = null;
    if (point['shortDesc'])
      tooltip = point['shortDesc'];
    
    if (tooltip == null && point['label'])
      tooltip = point['label'];

    return tooltip;
  };

  /**
   * Get marker source URL
   * @param {object} point
   * @return {string} The source URL
   */
  DvtOracleMapProvider.prototype.getSource = function (point)
  {
    var source;
    if (point['source'])
      source = point['source'];
    else
    {
      source = DvtOracleMapProvider.DEFAULT_ORACLE_MARKER_IMG;
    }
    return source;
  };

  /**
   * Get marker sourceSelected URL
   * @param {object} point
   * @return {string} The sourceSelected URL
   */
  DvtOracleMapProvider.prototype.getSourceSelected = function (point)
  {
    var sourceSelected;
    if (point['sourceSelected'])
      sourceSelected = point['sourceSelected'];
    else
    {
      sourceSelected = DvtOracleMapProvider.DEFAULT_ORACLE_MARKER_SELECT_IMG;
    }
    return sourceSelected;
  };

  /**
   * Get marker sourceHover URL
   * @param {object} point
   * @return {string} The sourceHover URL
   */
  DvtOracleMapProvider.prototype.getSourceHover = function (point)
  {
    var sourceHover;
    if (point['sourceHover'])
      sourceHover = point['sourceHover'];
    else
    {
      sourceHover = DvtOracleMapProvider.DEFAULT_ORACLE_MARKER_HOVER_IMG;
    }
    return sourceHover;
  };

  /**
   * Get marker sourceHoverSelected URL
   * @param {object} point
   * @return {string} The sourceHoverSelected URL
   */
  DvtOracleMapProvider.prototype.getSourceHoverSelected = function (point)
  {
    var sourceHoverSelected;
    if (point['sourceHoverSelected'])
      sourceHoverSelected = point['sourceHoverSelected'];
    else
    {
      sourceHoverSelected = DvtOracleMapProvider.DEFAULT_ORACLE_MARKER_SELECT_IMG;
    }
    return sourceHoverSelected;
  };

  /**
   * Get minimum number
   * @param {number} min
   * @param {number} n
   * @return {number} min
   */
  DvtOracleMapProvider.prototype.getMin = function (min, n)
  {
    if (min == null || min > n)
      min = n;
    return min;
  };

  /**
   * Get maximum number
   * @param {number} max
   * @param {number} n
   * @return {number} max
   */
  DvtOracleMapProvider.prototype.getMax = function (max, n)
  {
    if (max == null || max < n)
      max = n;
    return max;
  };

  /**
   * If selection is enabled, returns the initial selection status for a data layer.
   * On first render, returns array of row keys found in the 'selectedRowKeys' property.
   * On re-render, returns the previously selected row keys
   * @private
   * @param {object} map
   * @param {object} dataLayer
   * @param {string} id dataLayer id
   * @return {array} array of selected row keys
   */
  DvtOracleMapProvider.prototype._getSelectedRowKeys = function (map, dataLayer, id)
  {
    var selMode = this.getSelMode(dataLayer);
    var selectedRowKeys = [];

    // if data selection is off, nothing to do
    if (selMode === DvtOracleMapProvider.SEL_SINGLE || selMode === DvtOracleMapProvider.SEL_MULTIPLE)
    {
      // first time through, check if there's an initial selection to be set
      if (!map.initialSelectionApplied)
      {
        if (dataLayer['selectedRowKeys'] !== undefined)
        {
          selectedRowKeys = dataLayer['selectedRowKeys'].split(' ');
        }
      }
      else // next time, preserve existing selections
      {
        var selection = map['selection'][id];// selected points for this layer
        if (selection)
        {
          for (var i = 0;i < selection.length;i++)
          {
            selectedRowKeys.push(selection[i]['rowKey']);
          }
          // clear the previous selection as we'll populate a new one
          selection.length = 0;
        }
      }
    }
    return selectedRowKeys;
  };

  /**
   * Checks if the map includes any data layers.
   * @private
   * @param {object} map DvtGeographicMap instance
   * @return {boolean} true if the map includes any data layers, false otherwise
   */
  DvtOracleMapProvider.prototype._mapIncludesData = function (map)
  {
    var data = map['Data'];

    if (data && data['routes'] && data['routes'].length > 0)
      return true;

    if (!data || !data['dataLayers'] || Object.keys (data['dataLayers']).length == 0)
      return false;

    return true;
  };

  /**
   * Sets a new map center position.
   * 
   * @param {Object} map - map instance
   * @param {string} centerX - new center x position (longitude)
   * @param {string} centerY - new center y position (latitude)
   */
  DvtOracleMapProvider.prototype.moveCenter = function(map, centerX, centerY)
  {
    var newLong = parseFloat(centerX);
    var newLat = parseFloat(centerY);

    var mapview = map['_instance'];
    if (mapview)
    {
      var mpoint = new OM.geometry.Point(newLong, newLat, 8307);
      delete map['center'];
      mapview.setMapCenter(mpoint, true);
    }
  };

  /**
   * Sets new zoom level in an existing map.
   * 
   * @param {Object} map - map instance
   * @param {string} zoomLevel - new zoom level
   */
  DvtOracleMapProvider.prototype.updateZoomLevel = function(map, zoomLevel)
  {
    var newZoomLevel = parseInt(zoomLevel);

    var mapview = map['_instance'];
    if (mapview)
    {
      delete map['lastZoom'];
      mapview.setMapZoomLevel(newZoomLevel);
    }
  };

  adf.mf.internal.dvt.geomap.DvtGeographicMap.registerMapProvider("oraclemaps", DvtOracleMapProvider);
})();
