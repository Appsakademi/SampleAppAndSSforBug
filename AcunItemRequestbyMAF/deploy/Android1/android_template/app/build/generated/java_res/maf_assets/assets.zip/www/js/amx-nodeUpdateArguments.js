/* Copyright (c) 2011, 2017, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ------------ amx-nodeUpdateArguments.js -------------- */
/* ------------------------------------------------------ */

(function()
{
  /**
   * Internal object for the arguments to the markNodeForUpdate function
   * @constructor adf.mf.api.amx.AmxNodeUpdateArguments
   * @augments adf.mf.api.AdfObject
   */
  function AmxNodeUpdateArguments()
  {
    this.Init();
  }

  /**
   * @deprecated
   */
  adf.mf.internal.amx.AmxNodeUpdateArguments = AmxNodeUpdateArguments;

  /*
   * Object for the arguments passed into the adf.mf.api.amx.markNodeForUpdate function.
   */
  adf.mf.api.amx.AmxNodeUpdateArguments = AmxNodeUpdateArguments;

  adf.mf.api.AdfObject.createSubclass(
    adf.mf.api.amx.AmxNodeUpdateArguments,
    adf.mf.api.AdfObject,
    "adf.mf.api.amx.AmxNodeUpdateArguments");

  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.Init = function()
  {
    AmxNodeUpdateArguments.superclass.Init.call(this);
    this._amxNodes = [];
    this._nodeChanges = {};
    this._affectedAttributes = {};
    this._affectedTagInstances = {};
    this._tagInstanceChanges = {};
    this._canceled = false;
    this._tagInstanceAttributeValues = {};
    this._affectedAmxNodeIds = {};
  };

  /**
   * Check if the update has been canceled
   * @return {boolean} true if canceled
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.isCanceled = function()
  {
    return this._canceled;
  };

  /**
   * Request that the update be canceled. If the update has been queued, calling this function
   * will prevent the update from being executed. This may be used if an asynchronous event has
   * occurred while the update has been queued that makes the update undesirable. If the update
   * has already run or is in progress this function will not have an effect.
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.cancel = function()
  {
    this._canceled = true;
  };

  /**
   * Get an array of affected AmxNodes
   * @return {Array.<adf.mf.api.amx.AmxNode>} array of nodes
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.getAffectedNodes = function()
  {
    return this._amxNodes;
  };

  /**
   * Get an object representing the affected attributes for a given AmxNode ID.
   *
   * @param {string} amxNodeId the AmxNode ID
   * @return {Object<string, boolean>} an object with the changed
   *         attributes as keys and "true" as the value.
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.getAffectedAttributes = function(amxNodeId)
  {
    var affected = this._affectedAttributes[amxNodeId];

    return affected == null ? {} : affected;
  };

  /**
   * Currently an internal method to get the node changes for a given node. This API may be changed in the future and
   * therefore is currently marked as internal.
   *
   * @param {string} amxNodeId the AMX node ID
   * @return {adf.mf.internal.amx.AmxNodeChanges|null} the changes for the node or null if there aren't any
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.__getNodeChanges = function(amxNodeId)
  {
    return this._nodeChanges[amxNodeId];
  };

  /**
   * Get the collection changes for a given AmxNode and property
   * @param {string} amxNodeId the AmxNode ID
   * @param {string|null} attributeName the name of the attribute of which to get the changes . Defaults to "value" if
   *        not provided
   * @return {(Object<string, adf.mf.api.amx.AmxCollectionChange>|undefined)} an object with the
   *         attributes as keys and the collection change objects for the values. May
   *         be undefined if there are no changes for a given AmxNode
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.getCollectionChanges = function(
    amxNodeId,
    attributeName)
  {
    var nodeChanges = this._nodeChanges[amxNodeId];

    return nodeChanges == null ? undefined : nodeChanges.getCollectionChanges(attributeName || "value");
  };

  /**
   * Mark an attribute of an AmxNode as affected
   * @param {adf.mf.api.amx.AmxNode} amxNode the affected AmxNode
   * @param {string} attributeName the name of the affected attribute
   * @param {Object} attributeValue the new value of the attribute. Note this is only used if
   *        the embedded side is being used to maintain the node hierarchy
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.setAffectedAttribute = function(
    amxNode,
    attributeName,
    attributeValue)
  {
    var amxNodeId = amxNode.getId();
    var affected = this._affectedAttributes[amxNodeId];
    var nodeChanges = this._getOrCreateNodeChanges(amxNode);

    if (affected == null)
    {
      affected = {};
      this._affectedAttributes[amxNodeId] = affected;
    }

    if (arguments.length == 2)
    {
      // Use the existing value if the attribute value was not provided on the method call (legacy support)
      attributeValue = amxNode.getAttribute(attributeName);
    }

    nodeChanges.setChangedAttribute(attributeName, attributeValue);
    affected[attributeName] = true;
  };

  /**
   * Set the collection changes for a given AmxNode's attribute
   * @param {adf.mf.api.amx.AmxNode} amxNode the AMX node (deprecated usage is to pass the node ID as a string. This
   *        will be supported for a limited time
   * @param {string} attributeName the name of the attribute that the collection had changes
   * @param {adf.mf.api.amx.AmxCollectionChange} collectionChanges the changes for the collection
   * @deprecated Please use addCollectionChanges instead
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.setCollectionChanges = function(
    amxNode,
    attributeName,
    collectionChanges)
  {
    if (!(amxNode instanceof adf.mf.api.amx.AmxNode))
    {
      // TODO: log deprecation warning
      // Try to find the node by its ID, forcing the attribute to a string
      amxNode = adf.mf.api.amx.AmxNode.getAmxNodeById("" + amxNode);
    }

    if (amxNode != null)
    {
      var amxNodeId = amxNode.getId();
      var nodeChanges = this._getOrCreateNodeChanges(amxNode);

      nodeChanges.setCollectionModelChanges(attributeName, collectionChanges);
    }
  };

  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.__getChanges = function(
    amxNode)
  {
    return this._nodeChanges[amxNode.getId()];
  };

  /**
   * Adds an AMX node to be added to the hierarchy as a result of an embedded change
   *
   * @param {adf.mf.api.amx.AmxNode} parentAmxNode the parent AMX node to add to
   * @param {string|null} beforeAmxNodeId the ID to insert this node before or null to append
   * @param {adf.mf.api.amx.AmxNode} amxNode the node to add
   * @param {string|null} facet the facet to add the node to or null to add as a child
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.__addAmxNode = function(
    parentAmxNode,
    beforeAmxNodeId,
    amxNode,
    facet)
  {
    var parentAmxNodeId = parentAmxNode.getId();
    var nodeChanges = this._getOrCreateNodeChanges(parentAmxNode);

    nodeChanges.childToAdd(beforeAmxNodeId, amxNode, facet);
  };

  /**
   * Adds an AMX node to be removed from the hierarchy as a result of an embedded change
   *
   * @param {adf.mf.api.amx.AmxNode} amxNode the node to remove
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.__removeAmxNode = function(
    amxNode)
  {
    var parentAmxNode = amxNode.getParent();

    if (parentAmxNode != null)
    {
      var nodeChanges = this._getOrCreateNodeChanges(parentAmxNode);

      nodeChanges.childToRemove(amxNode);
    }
  };

  /**
   * Internal function to get a list of affected tag instance IDs for a given AMX node.
   *
   * @param {string} amxNodeId the AMX node ID
   * @return {Array.<string>} IDs of the affected tag instances. Will return an empty array if
   *         there are not IDs.
   * @ignore
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.__getAffectedTagInstanceIds = function(
    amxNodeId)
  {
    var affected = this._affectedTagInstances[amxNodeId];

    return affected == null ? [] : affected;
  };

  /**
   * Internal function to get the affected attribute names for an AMX node and its tag instance ID
   *
   * @param {string} amxTagInstanceId the unique ID of the affected tag instance
   * @return {adf.mf.internal.amx.AmxTagInstanceChanges} the tag instance changes
   * @ignore
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.__getTagInstanceChanges = function(
    amxTagInstanceId)
  {
    return this._tagInstanceChanges[amxTagInstanceId];
  };

  /**
   * Internal function to mark a tag's attribute as dirty
   *
   * @param {adf.mf.internal.amx.AmxTagInstance} tagInstance the affected tag instance
   * @param {string} attributeName the name of the affected attribute
   * @param {Object} attributeValue the new value of the attribute. Note this is only used if
   *        the embedded side is being used to maintain the node hierarchy
   * @ignore
   */
  adf.mf.api.amx.AmxNodeUpdateArguments.prototype.__setAffectedAttributeForTagInstance = function(
    tagInstance,
    attributeName,
    attributeValue)
  {
    var amxNode = tagInstance.getParentAmxNode();
    var id = tagInstance.getId();
    var changes = this._tagInstanceChanges[id];

    // Mark the instance dirty
    if (changes == null)
    {
      changes = new AmxTagInstanceChanges(tagInstance);
      this._tagInstanceChanges[id] = changes;

      // Mark the node dirty if it has not already
      this._markNodeAsAffected(amxNode);
    }

    changes.setChangedAttribute(attributeName, attributeValue);

    var amxNodeId = amxNode.getId();
    var affected = this._affectedTagInstances[amxNodeId];

    if (affected == null)
    {
      affected = [ id ];
      this._affectedTagInstances[amxNodeId] = affected;
    }
    else if (affected.indexOf(id) == -1)
    {
      affected.push(id);
    }
  };

  adf.mf.api.amx.AmxNodeUpdateArguments.prototype._markNodeAsAffected = function(amxNode)
  {
    var amxNodeId = amxNode.getId();

    // Mark the node dirty if it hasn't been already
    if (!this._affectedAmxNodeIds[amxNodeId])
    {
      this._amxNodes.push(amxNode);
      this._affectedAmxNodeIds[amxNodeId] = true;
    }
  };

  adf.mf.api.amx.AmxNodeUpdateArguments.prototype._getOrCreateNodeChanges = function(amxNode)
  {
    var amxNodeId = amxNode.getId();
    var nodeChanges = this._nodeChanges[amxNodeId];

    if (nodeChanges == null)
    {
      this._markNodeAsAffected(amxNode);
      nodeChanges = new AmxNodeChanges(amxNode);
      this._nodeChanges[amxNodeId] = nodeChanges;
    }

    return nodeChanges;
  };

  /**
   * Internal object used to hold changes to the node hierarchy. Used by the AmxNodeUpdateArguments and specifically
   * used for embedded side change management.
   */
  function AmxNodeChanges(amxNode)
  {
    this._amxNode = amxNode;
    this._attributeValues = {};
    this._collectionChanges = {};
    this._childrenToAdd = [];
    this._addBeforeIds = {};
    this._facets = {};
    this._childrenToRemove = [];
    this._changedAttributes = [];
    this._attributesWithCollectionChanges = [];
  }

  adf.mf.internal.amx.AmxNodeChanges = AmxNodeChanges;

  /**
   * An array of changed attributes
   *
   * @return {Array.<string>} names of the attributes
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.getChangedAttributes = function()
  {
    return this._changedAttributes;
  };

  /**
   * Get the new attribute value for an attribute
   *
   * @param {string} attributeName the name of the attribute
   * @return {Object} the value
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.getNewAttributeValue = function(attributeName)
  {
    return this._attributeValues[attributeName];
  };

  /**
   * An array of attributes with collection changes
   *
   * @return {Array.<string>} names of the attributes that have collection changes
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.getAttributesWithCollectionChanges = function()
  {
    return this._attributesWithCollectionChanges;
  };

  /**
   * Get the collection changes
   *
   * @return {(Object<string, adf.mf.api.amx.AmxCollectionChange>|undefined)} an object with the
   *         attributes as keys and the collection change objects for the values. May
   *         be undefined if there are no changes for a given AmxNode
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.getCollectionChanges = function()
  {
    return this._collectionChanges;
  };

  /**
   * Get the nodes that were created to be added as children
   *
   * @return {Array.<adf.mf.api.amx.AmxNode>} the nodes to add as children
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.getNodesToAdd = function()
  {
    return this._childrenToAdd;
  };

  /**
   * Get the nodes that were created to be added as children
   *
   * @param {adf.mf.api.amx.AmxNode} amxNodeChild the child to find out to get the node to insert in front of
   * @return {string|null} the ID to insert before or null if appending
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.getNodeIdToInsertBefore = function(amxNodeChild)
  {
    return this._addBeforeIds[amxNodeChild.getId()];
  };

  /**
   * Get the facet to use for inserting the given child
   *
   * @param {adf.mf.api.amx.AmxNode} amxNodeChild the child
   * @return {string|null} the facet or null if it should be added as a child
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.getNodeFacet = function(amxNodeChild)
  {
    return this._facets[amxNodeChild.getId()];
  };

  /**
   * Get the nodes that were created to be removed as children
   *
   * @return {Array.<adf.mf.api.amx.AmxNode>} the children nodes to remove
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.getNodesToRemove = function()
  {
    return this._childrenToRemove;
  };

  /**
   * Set an attribute as changed with its new value
   *
   * @param {string} attributeName the name of the attribute
   * @param {Object} attributeValue the new value of the attribute
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.setChangedAttribute = function(
    attributeName,
    attributeValue)
  {
    if (this._changedAttributes.indexOf(attributeName) == -1)
    {
      this._changedAttributes.push(attributeName);
    }

    this._attributeValues[attributeName] = attributeValue;
  };

  /**
   * Set the collection changes for an attribute
   *
   * @param {string} attributeName the name of the attribute
   * @param {adf.mf.api.amx.AmxCollectionChange} collectionChanges the changes
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.setCollectionModelChanges = function(
    attributeName,
    collectionChanges)
  {
    var replacing = this._collectionChanges[attributeName] != null;

    this._collectionChanges[attributeName] = collectionChanges;

    if (!replacing)
    {
      this._attributesWithCollectionChanges.push(attributeName);
    }
  };

  /**
   * Marks a child to be added
   *
   * @param {string|null} beforeAmxNodeId the node to insert the new child before or null if appending
   * @param {adf.mf.api.amx.AmxNode} amxNode the node to add as a child
   * @param {string|null} facet the name of the facet to use or null to add as a child
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.childToAdd = function(
    beforeAmxNodeId,
    amxNode,
    facet)
  {
    var amxNodeId = amxNode.getId();

    this._childrenToAdd.push(amxNode);
    this._addBeforeIds[amxNodeId] = beforeAmxNodeId;
    this._facets[amxNodeId] = facet;
  };

  /**
   * Marks a child to be removed
   *
   * @param {adf.mf.api.amx.AmxNode} amxNode the child node to remove
   */
  adf.mf.internal.amx.AmxNodeChanges.prototype.childToRemove = function(
    amxNode)
  {
    this._childrenToRemove.push(amxNode);
  };


  /**
   * Internal object used to hold changes to the tag instances. Used by the AmxNodeUpdateArguments and specifically
   * used for embedded side change management.
   * @ignore
   */
  function AmxTagInstanceChanges(tagInstance)
  {
    // Note that tag instances cannot be added or removed after node creation at this time, so weonly need to support
    // attribute changes
    this._tagInstance = tagInstance;
    this._attributeValues = {};
    this._changedAttributes = [];
  }

  /**
   * @ignore
   */
  adf.mf.internal.amx.AmxTagInstanceChanges = AmxTagInstanceChanges;

  /**
   * An array of changed attributes
   *
   * @return {Array.<string>} names of the attributes
   * @ignore
   */
  adf.mf.internal.amx.AmxTagInstanceChanges.prototype.getChangedAttributes = function()
  {
    return this._changedAttributes;
  };

  /**
   * Get the new attribute value for an attribute
   *
   * @param {string} attributeName the name of the attribute
   * @return {Object} the value
   * @ignore
   */
  adf.mf.internal.amx.AmxTagInstanceChanges.prototype.getNewAttributeValue = function(attributeName)
  {
    return this._attributeValues[attributeName];
  };

  /**
   * Set an attribute as changed with its new value
   *
   * @param {string} attributeName the name of the attribute
   * @param {Object} attributeValue the new value of the attribute
   * @ignore
   */
  adf.mf.internal.amx.AmxTagInstanceChanges.prototype.setChangedAttribute = function(
    attributeName,
    attributeValue)
  {
    if (this._changedAttributes.indexOf(attributeName) == -1)
    {
      this._changedAttributes.push(attributeName);
    }

    this._attributeValues[attributeName] = attributeValue;
  };
})();
