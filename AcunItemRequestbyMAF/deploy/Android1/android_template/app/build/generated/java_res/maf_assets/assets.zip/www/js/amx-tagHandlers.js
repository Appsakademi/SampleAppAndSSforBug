/* Copyright (c) 2013, 2017, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ---------------- amx-tagHandlers.js ------------------ */
/* ------------------------------------------------------ */

(function()
{
  // This file houses the built in tag (non-UI) handlers. The tag handlers are currently mostly
  // place holders until a full tag API can be designed.

  var AmxTagHandler = adf.mf.internal.amx.AmxTagHandler;

  function getEventTypeFromTagInstance(tagInstance)
  {
    var type = tagInstance.getAttribute("type");

    if (type != null)
    {
      type = adf.mf.internal._getEventTypeResolvedForBidi(type);
    }
    else // use default type
    {
      type = "action";
    }

    return type;
  }

  // --------- Temporary handlers --------- //
  // Register tag handlers for tags that have no behavior in this file (other tags
  // handle the logic)
  AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX, "attributeList",
    AmxTagHandler);
  AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX, "attributeSet",
    AmxTagHandler);
  AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX, "facet", AmxTagHandler);
  AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX, "transition", AmxTagHandler);
  AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX, "loadingIndicatorBehavior",
    AmxTagHandler);
  AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX, "validationBehavior",
    AmxTagHandler);

  // Note that the tag handlers for amx:convertNumber and amx:convertDateTime are in amx-converter.js
  // --------- /Temporary handlers --------- //

  // --------- attribute --------- //
  // Tag handler for AMX fragment attributes. Prevent the fetching of the value attribute by default
  // in case the EL points to a method and not a value expression.
  var attributeTagHandler = AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX, "attribute",
    AmxTagHandler);
  attributeTagHandler.prototype.shouldPrefetchAttribute = function(name)
  {
    return name != "value";
  };
  // --------- /attribute --------- //

  // --------- actionListener --------- //
  // Use a custom tag handler for the actionListener tag to prevent the EL evaluation of the binding
  // attribute during tag instance construction
  var actionListenerTagHandler = AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX,
    "actionListener");

  actionListenerTagHandler.prototype.shouldPrefetchAttribute = function(name)
  {
    return name != "binding";
  };

  actionListenerTagHandler.prototype.getHandledEventTypes = function(tagInstance)
  {
    return [ getEventTypeFromTagInstance(tagInstance) ];
  };

  actionListenerTagHandler.prototype.handleAmxEvent = function(
    tagInstance,
    amxNode,
    amxEventType,
    amxEvent,
    mode,
    beforeEmbeddedCall)
  {
    if (beforeEmbeddedCall && mode != adf.mf.internal.amx.AmxEventHandlingMode["EMBEDDED"])
    {
      // Create the arrays of paramaters and and paramater types
      var params     = [];
      var paramTypes = [];

      if (amxEvent)
      {
        params.push(amxEvent);
        paramTypes.push(amxEvent[".type"]);
      }

      // Invoke the action event. This returns a promise.
      var expr = tagInstance.getAttributeExpression("binding");
      var promise = adf.mf.api.amx.invokeEl(
        expr,
        params,
        null,
        paramTypes);

      if (mode == adf.mf.internal.amx.AmxEventHandlingMode["SERIAL"])
      {
        // Only return the promise for serial execution
        return promise;
      }
    }
  };
  // --------- /actionListener --------- //

  // --------- clientListener --------- //
  var clientListenerTagHandler = AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX,
    "clientListener");

  clientListenerTagHandler._NON_DOM_EVENT_TYPES = {
    "move": true,
    "rangeChange": true,
    "selection": true,
    "valueChange": true
  };

  clientListenerTagHandler.prototype.initializeTagInstance = function(tagInstance)
  {
    // Get the attribute type. If none is specified assume an action attribute.
    var attrType = getEventTypeFromTagInstance(tagInstance);

    tagInstance.setAttribute("_type", attrType);

    // Only add types that are DOM events (non-DOM events are already handled):
    if (!clientListenerTagHandler._NON_DOM_EVENT_TYPES[attrType])
    {
      // The parent AMX node will have a list without duplication (map with dummy keys) that indicate
      // which clientListener events the app developer wants the TypeHandler to support.
      var parentAmxNode = tagInstance.getParentAmxNode();
      var clientListenerTypesKey = "data-clientListenerTypes";
      var clientListenerTypes = parentAmxNode.getAttribute(clientListenerTypesKey);
      if (clientListenerTypes == null)
      {
        clientListenerTypes = {};
        parentAmxNode.setAttributeResolvedValue(clientListenerTypesKey, clientListenerTypes);
      }

      clientListenerTypes[attrType] = true;
    }
  };

  clientListenerTagHandler.prototype.getHandledEventTypes = function(tagInstance)
  {
    return [ tagInstance.getAttribute("_type") ];
  };

  clientListenerTagHandler.prototype.handleAmxEvent = function(
    tagInstance,
    amxNode,
    amxEventType,
    amxEvent,
    mode,
    beforeEmbeddedCall)
  {
    if (beforeEmbeddedCall)
    {
      adf.mf.internal._processClientListener(amxEventType, amxEvent, amxNode, tagInstance);
    }
  };
  // --------- /clientListener --------- //

  // --------- navigationDragBehavior --------- //
  // Use a custom tag handler for the navigationDragBehavior tag to prevent the EL evaluation of the action
  // attribute during tag instance construction
  var navigationDragBehaviorTagHandler = AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX,
    "navigationDragBehavior");

  navigationDragBehaviorTagHandler.prototype.shouldPrefetchAttribute = function(name)
  {
    return name != "action";
  };
  // --------- /navigationDragBehavior --------- //

  // --------- setPropertyListener --------- //
  // Use a custom tag handler for the setPropertyListener tag to prevent the EL evaluation of the
  // attributes during tag instance construction
  var setPropertyListenerTagHandler = AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX,
    "setPropertyListener");

  setPropertyListenerTagHandler.prototype.shouldPrefetchAttribute = function(name)
  {
    return false;
  };

  setPropertyListenerTagHandler.prototype.getHandledEventTypes = function(tagInstance)
  {
    return [ getEventTypeFromTagInstance(tagInstance) ];
  };

  setPropertyListenerTagHandler.prototype.handleAmxEvent = function(
    tagInstance,
    amxNode,
    amxEventType,
    amxEvent,
    mode,
    beforeEmbeddedCall)
  {
    if (beforeEmbeddedCall)
    {
      switch (mode)
      {
        case adf.mf.internal.amx.AmxEventHandlingMode["BATCH"]:
          return this._handleAmxEventBatch(tagInstance, amxNode, amxEventType, amxEvent);

        case adf.mf.internal.amx.AmxEventHandlingMode["SERIAL"]:
          return this._handleAmxEventSerial(tagInstance, amxNode, amxEventType, amxEvent);
      }
    }
  }

  setPropertyListenerTagHandler.prototype._handleAmxEventBatch = function(
    tagInstance,
    amxNode,
    amxEventType,
    amxEvent)
  {
    var from = tagInstance.getAttributeExpression("from");
    var isEl = false;
    if (from)
    {
      from = from.toContextFreeExpression().getExpression();
      isEl = true;
    }
    else
    {
      from = tagInstance.getAttribute("from", false);
    }

    if (from != null)
    {
      // Get a context free EL expression for the "to" so that we do not need to
      // perform another visit to set the value
      var toEl = tagInstance.getAttributeExpression("to").toContextFreeExpression();

      // Set the value without trying to resolve the "from" value.
      var setObject =
      {
        "name": toEl.getExpression(),
        "expression": toEl,
        "value": from
      };

      if (isEl)
      {
        // "from" is just a reference alias
        setObject[adf.mf.internal.api.constants["VALUE_REF_PROPERTY"]] = true;
      }

      // Do not return a promise as this is in a batch call
      amx.setElValue(setObject);
    }
  };

  setPropertyListenerTagHandler.prototype._handleAmxEventSerial = function(
    tagInstance,
    amxNode,
    amxEventType,
    amxEvent)
  {
    // Get the from expression
    var fromEL = tagInstance.getAttributeExpression("from");

    if (fromEL)
    {
      // Get a context free EL expression for the "to" so that we do not
      // need to perform another visit to set the value.
      var toEl = tagInstance.getAttributeExpression("to")
        .toContextFreeExpression();

      // Get the value and when it has been retieved the always function
      // will be invoked and this is where we will set the value we just
      // retrieved.
      return new adf.mf.internal.BasePromise(
        function(resolve, reject)
        {
          var getAlways =
            function(requestAndResponse)
            {
              var response = requestAndResponse[1];

              // Have the new value now set it based on the EL binding for
              // the element
              amx.setElValue(
                {
                  "name": toEl.getExpression(),
                  "expression": toEl,
                  "value": response[0].value
                }).then(resolve, reject);
            };

          amx.getElValue(fromEL).then(getAlways, getAlways);
        });
    }
    else
    {
      var from = tagInstance.getAttribute("from", false);
      // Get a context free EL expression for the "to" so that we do not
      // need to perform another visit to set the value.
      var toEl = tagInstance.getAttributeExpression("to")
        .toContextFreeExpression();

      return amx.setElValue(
        {
          "name": toEl.getExpression(),
          "expression": toEl,
          "value": from
        });
    }
  };
  // --------- /setPropertyListener --------- //

  // --------- loadBundle --------- //
  // Use a custom tag handler for the loadBundle tag to prevent the EL evaluation of the
  // basename attribute during tag instance construction
  var loadBundleTagHandler = AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX,
    "loadBundle");

  loadBundleTagHandler.prototype.shouldPrefetchAttribute = function(name)
  {
    return name != "basename";
  };
  // --------- /loadBundle --------- //

  // --------- systemActionBehavior --------- //
  // Use a custom tag handler for the systemActionBehavior tag to prevent the EL evaluation of the actionListener
  // and action attributes during tag instance construction
  var systemActionBehaviorTagHandler = AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX,
    "systemActionBehavior");

  systemActionBehaviorTagHandler.prototype.shouldPrefetchAttribute = function(name)
  {
    return (name != "actionListener" && name != "action");
  };
  // --------- /systemActionBehavior --------- //

  // --------- showPopupBehaviorTagHandler --------- //
  var showPopupBehaviorTagHandler = AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX, "showPopupBehavior");

  showPopupBehaviorTagHandler.prototype.getHandledEventTypes = function(tagInstance)
  {
    return [ getEventTypeFromTagInstance(tagInstance) ];
  };

  showPopupBehaviorTagHandler.prototype.handleAmxEvent = function(
    tagInstance,
    amxNode,
    amxEventType,
    amxEvent,
    mode,
    beforeEmbeddedCall)
  {
    if (!beforeEmbeddedCall)
    {
      amx.processShowPopupBehavior(amxNode, tagInstance);
    }
  };
  // --------- /showPopupBehaviorTagHandler --------- //

  // --------- closePopupBehaviorTagHandler --------- //
  var closePopupBehaviorTagHandler = AmxTagHandler.register(adf.mf.api.amx.AmxTag.NAMESPACE_AMX, "closePopupBehavior");

  closePopupBehaviorTagHandler.prototype.getHandledEventTypes = function(tagInstance)
  {
    return [ getEventTypeFromTagInstance(tagInstance) ];
  };

  closePopupBehaviorTagHandler.prototype.handleAmxEvent = function(
    tagInstance,
    amxNode,
    amxEventType,
    amxEvent,
    mode,
    beforeEmbeddedCall)
  {
    if (!beforeEmbeddedCall)
    {
      amx.processClosePopupBehavior(amxNode, tagInstance);
    }
  };
  // --------- /closePopupBehaviorTagHandler --------- //
})();
