/* Copyright (c) 2011, 2018, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ------------------- amx-inputDate.js ----------------- */
/* ------------------------------------------------------ */
(function()
{
  var inputDate = adf.mf.api.amx.TypeHandler.register(
    adf.mf.api.amx.AmxTag.NAMESPACE_AMX, "inputDate");

  inputDate.prototype.getInputValueAttribute = function()
  {
    return "value";
  };

  inputDate.prototype.render = function(amxNode, id)
  {
    inputDate._oneTimeSetup();

    // MDO - converters support is deprecated; remove any converters added by old apps
    amxNode.setConverter(null);

    var forId = id + "_trigger";
    var field = amx.createField(amxNode, forId); // generate the fieldRoot/fieldLabel/fieldValue structure
    field.fieldLabel.setAttribute("id", id + "__fieldLabel");
    var rootDomNode = field.fieldRoot;

    // Initialize the value for this instance:
    var dateObject = null;
    var value = amxNode.getAttribute("value");
    if (value == null)
    {
      dateObject = {};
      dateObject[".null"] = true;
      value = "";
    }
    else
    {
      // call our date parser that attempts both native and ISO-8601 parsing
      var dateParse = adf.mf.internal.converters.dateParser.parse(value);

      if (!isNaN(dateParse))
      {
        dateObject = new Date(dateParse);
      }
    }

    if (dateObject == null && !adf.mf.environment.profile.dtMode)
    {
      dateObject = {};
      dateObject[".null"] = true;
      value = "";
    }

    // Check to Extract the date, time, and datetime values only when DT Mode is false
    var inputType = amxNode.getAttribute("inputType");
    if (adf.mf.environment.profile.dtMode == false)
    {
      if (inputType === "time")
      {
        // only extract the time if the value is not null
        if (amxNode.getAttribute("value") != null)
        {
          if (dateObject.getHours != null)
          {
            value = adf.mf.internal.amx.extractTimeFromDateObject(dateObject);
          }
        }
      }
      else if (inputType === "datetime")
      {
        value = amxNode.getAttribute("value");
      }
      else
      {
        inputType = "date";
        // only extract the date if the value is not null
        if (amxNode.getAttribute("value") != null)
        {
          if (dateObject.getFullYear != null)
          {
            value = adf.mf.internal.amx.extractDateFromDateObject(dateObject);
          }
        }
      }
    }
    else // for DT mode, set the inputType to text
    {
      inputType = "text";
    }

    // since readOnly is not required and it defaults to false if unspecified,
    // then we must use the adf.mf.api.amx.isValueTrue() helper method. This will return
    // false unless the attribute is explicitly set to true
    var readOnly = adf.mf.api.amx.isValueTrue(amxNode.getAttribute("readOnly"));

    // We may not yet have formatting information yet (it comes asynchronously
    // from Cordova) so we need to use a placeholder until we get the format
    // information. (It is used for read-only display and for the non-HTML5
    // version of the component.)
    var completed = false;
    inputDate._loadDateTimePatterns().then(
      function() // It is safe to finish rendering this component:
      {
        if (!completed)
        {
          completed = true;

          // if readOnly is set to true
          if (readOnly == true)
          {
            // Create the read-only inputDate:
            var dateLabel = document.createElement("span");
            dateLabel.setAttribute("id", id + "_triggerText");
            field.fieldValue.appendChild(dateLabel);
            var rawValue = inputDate._getRawValueFromDateObject(dateObject);
            dateLabel.textContent = inputDate._getTriggerText(inputType, rawValue);
            dateLabel.setAttribute("readOnly", readOnly);
            // Adding WAI-ARIA Attribute for the readonly state
            dateLabel.setAttribute("aria-readonly", readOnly);
            adf.mf.internal.amx._setNonPrimitiveElementData(dateLabel, "value", dateObject);
          }
          // create the date/time/date-time control using native HTML5 input types
          else
          {
            inputDate._createHtml5InputDate(amxNode, field, value, inputType, dateObject);
          }
        }
      },
      function(problem)
      {
        // should never get here
        console.log("inputDate promise-then problem: " + problem); // TODO add log message
      })["catch"](
        function(error)
        {
          console.log("inputDate promise-catch error: " + error); // TODO add log message
        });

    // calls applyRequiredMarker in amx-core.js to determine and implement required/showRequired style
    adf.mf.api.amx.applyRequiredMarker(amxNode, field);

    return rootDomNode;
  };

  inputDate.prototype.destroy = function(rootElement, amxNode)
  {
    // Clean up any elements that aren't inside the rootElement:
    var id = amxNode.getId();
    var dateTimePicker = document.getElementById(id + "_picker");
    var overlayElement = document.getElementById(id + "_overlay");
    adf.mf.api.amx.removeDomNode(dateTimePicker);
    adf.mf.api.amx.removeDomNode(overlayElement);
  };

  inputDate.prototype.__getTestJavaScriptURI = function(amxTag)
  {
    return "js/testing/amx-inputDate.js";
  };

  inputDate._getTriggerText = function(inputType, rawValue)
  {
    // The inputType value is undefined for the case where inputType is not
    // declared in the amx page, thus default type is "date".
    if (inputType == "time")
      return inputDate._getLocalizedTimeTextFromRawValue(rawValue);
    else if (inputType == "datetime")
      return inputDate._getLocalizedDateTimeTextFromRawValue(rawValue);
    else // "date" or not specified
      return inputDate._getLocalizedDateTextFromRawValue(rawValue);
  };

  inputDate._oneTimeSetup = function()
  {
    if (inputDate._LOCALIZED_MONTH_ARRAY == null)
    {
      // If we are presenting a month name to a user, we cannot show the parsable month,
      // instead we have to show a name from the user's selected resource bundle:
      var LOCALIZED_MONTH_ARRAY = new Array(12);
      if (adf.mf.environment.profile.dtMode == false)
      {
        LOCALIZED_MONTH_ARRAY[0] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_JANUARY_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[1] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_FEBRUARY_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[2] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_MARCH_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[3] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_APRIL_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[4] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_MAY_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[5] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_JUNE_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[6] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_JULY_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[7] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_AUGUST_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[8] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_SEPTEMBER_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[9] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_OCTOBER_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[10] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_NOVEMBER_ABBREVIATION");
        LOCALIZED_MONTH_ARRAY[11] = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_DECEMBER_ABBREVIATION");
        inputDate._LOCALIZED_TIME_AM = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_TIME_AM_ABBREVIATION");
        inputDate._LOCALIZED_TIME_PM = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_TIME_PM_ABBREVIATION");
        inputDate._LOCALIZED_BUDDHIST_ERA = adf.mf.resource.getInfoString("AMXInfoBundle", "amx_inputDate_LABEL_DATE_BUDDHIST_ERA_ABBREVIATION");
      }
      else
      {
        LOCALIZED_MONTH_ARRAY[0] = "JAN";
        LOCALIZED_MONTH_ARRAY[1] = "FEB";
        LOCALIZED_MONTH_ARRAY[2] = "MAR";
        LOCALIZED_MONTH_ARRAY[3] = "APR";
        LOCALIZED_MONTH_ARRAY[4] = "MAY";
        LOCALIZED_MONTH_ARRAY[5] = "JUN";
        LOCALIZED_MONTH_ARRAY[6] = "JUL";
        LOCALIZED_MONTH_ARRAY[7] = "AUG";
        LOCALIZED_MONTH_ARRAY[8] = "SEP";
        LOCALIZED_MONTH_ARRAY[9] = "OCT";
        LOCALIZED_MONTH_ARRAY[10] = "NOV";
        LOCALIZED_MONTH_ARRAY[11] = "DEC";
        inputDate._LOCALIZED_TIME_AM = "AM";
        inputDate._LOCALIZED_TIME_PM = "PM";
        inputDate._LOCALIZED_BUDDHIST_ERA = "BE";
      }
      inputDate._LOCALIZED_MONTH_ARRAY = LOCALIZED_MONTH_ARRAY;

      inputDate._tapEvents = amx.hasTouch() ? { start: "touchstart", end: "touchend" } : { start: "mousedown", end: "mouseup" };
    }
  };

  inputDate._capitalizeFirstLetter = function(monthText)
  {
    return monthText.slice(0,1).toUpperCase() + monthText.slice(1).toLowerCase();
  };

  /**
   * Creates a raw value object from a JavaScript date object.
   * @param {Date} dateObject a JavaScript date object
   * @return {Object} the raw value object based on the given date
   */
  inputDate._getRawValueFromDateObject = function(dateObject)
  {
    var rawValue = {
      "year":       null,
      "monthIndex": null,
      "dayNumber":  null,
      "hour1to12":  null,
      "min":        null,
      "isPm":       null
    };

    if (dateObject == null || dateObject.getFullYear == null)
      return rawValue;

    var milHour = dateObject.getHours(); // In 24 hours time (number 0 through 23)
    var hour = milHour;
    var isPm = false;
    if (hour == 0)
    {
      hour = 12;
    }
    else if (hour == 12)
    {
      isPm = true; // noon is 12 PM
    }
    else if (hour > 12)
    {
      isPm = true;
      hour = hour - 12;
    }

    rawValue["year"]       = dateObject.getFullYear()
    rawValue["monthIndex"] = dateObject.getMonth();
    rawValue["dayNumber"]  = dateObject.getDate();
    rawValue["hour1to12"]  = hour;
    rawValue["min"]        = dateObject.getMinutes();
    rawValue["isPm"]       = isPm;
    return rawValue;
  };

  inputDate._getLocalizedDateTimeTextFromRawValue = function(rawValue)
  {
    if (rawValue["monthIndex"] == null)
      return "";
    var result =
      inputDate._getLocalizedDateTextFromRawValue(rawValue) +
      " " +
      inputDate._getLocalizedTimeTextFromRawValue(rawValue);
    return result;
  };

  /**
   * Load the date and time patterns. This might require an asynchronous call so
   * instead of immediately using those patterns after calling this function,
   * you need to instead use them in the returned promise's "then" function.
   * @return {adf.mf.internal.BasePromise} the promise object whose then
   *   function is where the patterns can safely be used.
   */
  inputDate._loadDateTimePatterns = function()
  {
    // Callee should use the then function on the returned promise to perform
    // any actions that depend on the patters being loaded.
    var basePromise = new adf.mf.internal.BasePromise(
      function(resolveCallback, rejectCallback)
      {
        if (inputDate._datePatternFetched && inputDate._timePatternFetched)
        {
          resolveCallback(); // invoke the callback, no need to wait
        }
        else // at least one thing hasn't been loaded yet
        {
          // Only look up once per WebView.
          // Since this Cordova API uses a callback, we can't code synchronously.

          // If the Cordova globalization plugin is installed, try to get the date and time pattern
          // See details at http://plugins.cordova.io/#/package/org.apache.cordova.globalization
          if (navigator.globalization && navigator.globalization.getDatePattern)
          {
            navigator.globalization.getDatePattern(
              function(dateDetail)
              {
                // Make sure we got a date and not a time or datetime:
                var datePattern = dateDetail.pattern;
                var noLiteralPattern = inputDate._removePatternLiterals(datePattern);
                if (noLiteralPattern != null &&
                    noLiteralPattern.indexOf("y") != -1 && // year
                    noLiteralPattern.indexOf("m") == -1)   // minute
                {
                  inputDate._datePattern = datePattern;
                  inputDate._datePatternFetched = true;

                  // reset things so they will be recomputed
                  inputDate._dateFormatOrder = null;

                  if (inputDate._timePatternFetched)
                    resolveCallback(); // invoke the callback since we are ready
                }
              },
              function(error)
              {
                console.log("inputDate date pattern fetch error: " + error); // TODO add log message
              },
              {
                "formatLength": "short",
                "selector": "date"
              });

            navigator.globalization.getDatePattern(
              function(timeDetail)
              {
                // Make sure we got a time and not a date or datetime:
                var timePattern = timeDetail.pattern;
                var noLiteralPattern = inputDate._removePatternLiterals(timePattern);
                if (noLiteralPattern != null &&
                    noLiteralPattern.indexOf("y") == -1 && // year
                    noLiteralPattern.indexOf("m") != -1)   // minute
                {
                  inputDate._timePattern = timePattern;

                  // reset things so they will be recomputed
                  inputDate._timePatternFetched = true;

                  if (inputDate._datePatternFetched)
                    resolveCallback(); // invoke the callback since we are ready
                }
              },
              function(error)
              {
                console.log("inputDate time pattern fetch error: " + error); // TODO add log message
              },
              {
                "formatLength": "short",
                "selector": "time"
              });
          }
          else // the globalization plugin is not installed or available
          {
            // Stick with the US English patterns because the Cordova plug-in either
            // wasn't installed by the app developer or it isn't available.
            // Examples of other patterns:
            //  - yyyy/MM/dd (year, 2-digit month, 2-digit day)
            //  - HH:mm (24-hour clock)
            inputDate._datePattern = "MMM d, yyyy"; // use US English as a default
            inputDate._timePattern = "h:mm a"; // use US English as a default
            inputDate._datePatternFetched = true;
            inputDate._timePatternFetched = true;
            resolveCallback(); // invoke the callback since we are ready
          }
        }
      });
    return basePromise;
  };

  /**
   * Sort comparator for the date format components.
   * @param {Array.<Object>} x the first entry whose 1st member is the name, and the 2nd member is the pattern index
   * @param {Array.<Object>} y the second entry whose 1st member is the name, and the 2nd member is the pattern index
   * @return {Number} 1 if x is before y, -1 if x is after y, 0 if they are equal
   */
  inputDate._formatComparator = function(x, y)
  {
    /* use the cell index being sorted upon */
    var patternIndexA = x[1];
    var patternIndexB = y[1];

    if (patternIndexA > patternIndexB)
    {
      return 1; /* x is before y */
    }
    if (patternIndexA < patternIndexB)
    {
      return -1; /* x is after y */
    }

    return 0; /* they are equal */
  };

  /**
   * Get a 3-member array whose members are the name of the date data, sorted per the date format.
   * Entry names include: "year", "month", "day".
   * This is for the spinner positioning.
   * @return {Array.<String>} an array of names of date data, sorted per the date format
   */
  inputDate._getDateFormatOrderObject = function()
  {
    if (inputDate._dateFormatOrder == null)
    {
      var datePattern = inputDate._removePatternLiterals(inputDate._datePattern);
      var yearIndex = datePattern.indexOf("y");
      var monthIndex = datePattern.indexOf("M");
      var dayIndex = datePattern.indexOf("d");
      var orderObject =
        [
          [ "month", monthIndex ],
          [ "day", dayIndex ],
          [ "year", yearIndex ]
        ];

      // When dealing with number values in RTL mode, the spinners should appear
      // using big-endian ordering instead:
      if (document.documentElement.dir == "rtl")
      {
        // Make the order big-endian (reversed due to cell swapping):
        orderObject[0][1] = 1;
        orderObject[1][1] = 0;
        orderObject[2][1] = 2;
      }

      orderObject = orderObject.sort(inputDate._formatComparator);

      // Extract out just the names of the data to a simpler list:
      inputDate._dateFormatOrder = [ orderObject[0][0], orderObject[1][0], orderObject[2][0] ];
    }
    return inputDate._dateFormatOrder;
  };

  inputDate._getLocalizedDateTextFromRawValue = function(rawValue)
  {
    if (rawValue["monthIndex"] == null)
      return "";

    var year = inputDate._getLocalizedYearFromRawValue(rawValue);
    var locale = adf.mf.locale.getUserLocale();
    var localeSymbols = getLocaleSymbols(locale);
    var calendarType;
    var era;
    if (localeSymbols)
    {
      calendarType = localeSymbols.getCalendarTypeString();
      if ("buddhist" == calendarType)
      {
        year += 543;
        era = inputDate._LOCALIZED_BUDDHIST_ERA;
      }
      else if ("gregory" == calendarType)
      {
        era = localeSymbols.getEras()[1];
      }
    }
    else
    {
      // Fallbacks for mock mode:
      calendarType = "gregory";
      era = "AD";
    }
    var monthAbbr = inputDate._capitalizeFirstLetter(inputDate._getLocalizedMonthFromRawValue(rawValue));
    var dayOfMonth = inputDate._getLocalizedDayFromRawValue(rawValue);
    var datePattern = inputDate._datePattern;
    var noLiteralPattern = inputDate._removePatternLiterals(datePattern);
    var yearIndex = noLiteralPattern.indexOf("y");
    var monthIndex = noLiteralPattern.indexOf("M");
    var dayIndex = noLiteralPattern.indexOf("d");

    var result;
    if (yearIndex == -1 || monthIndex == -1 || dayIndex == -1)
    {
      result = monthAbbr + " " + dayOfMonth + ", " + year; // the given date format was unusable
    }
    else
    {
      // insert pieces into the given date format
      var dayOfMonthPadded = dayOfMonth < 10 ? "0"+dayOfMonth : dayOfMonth;
      var monthNumber = 1 + rawValue["monthIndex"];
      var monthNumberPadded = monthNumber < 10 ? "0"+monthNumber : monthNumber;

      result = inputDate._applyReplacementsToUnquotedParts(
        datePattern,
        function(patternPart)
        {
          // See http://unicode.org/reports/tr35/tr35-4.html#Date_Format_Patterns
          patternPart = patternPart.replace(/[A-FH-LN-Za-ce-xz]/g, "?"); // unsupported letters = ?; we support Mdy & non-alpha chars
          patternPart = patternPart.replace(/y+/g, year); // TODO y is regular number, yy, yyy, yyyyy, etc. represent truncation/padding
          patternPart = patternPart.replace(/d{2,2}/g, dayOfMonthPadded); // "dd" means use a padded day
          patternPart = patternPart.replace(/d{1,1}/g, dayOfMonth); // "d" mean use an unpadded day
          patternPart = patternPart.replace(/G{1,5}/g, "oooo"); // Use "ooo" as a temporary placeholder since we can't put in a name yet
          patternPart = patternPart.replace(/M{5,5}/g, "ooo"); // Use "ooo" as a temporary placeholder since we can't put in a name yet
          patternPart = patternPart.replace(/M{4,}/g, "oo"); // Use "oo" as a temporary placeholder since we can't put in a name yet
          patternPart = patternPart.replace(/M{3,3}/g, "o"); // Use "o" as a temporary placeholder since we can't put in a name yet
          patternPart = patternPart.replace(/M{2,2}/g, monthNumberPadded); // "MM" means use a padded month number, not text
          patternPart = patternPart.replace(/M{1,1}/g, monthNumber); // "M" means use an unpadded month number, not text
          patternPart = inputDate._replacePartsConcurrently(
            patternPart,
            [
              ["oooo", era], // "G" trough "GGGGG" represents the era e.g. "AD" in Gregorian or "BE" in Buddhist
              ["ooo", monthAbbr.charAt(0)], // "MMMMM" means use the first letter of the month name
              ["oo", monthAbbr],            // "MMMM" means use the full month name; we only have abbreviations
              ["o", monthAbbr]              // "MMM" means use an abbreviated month name
            ]);
          return patternPart;
        });
    }

    return result;
  };

  /**
   * Get a 3-member array whose members are the name of the time data, sorted per the time format.
   * Entry names include: "year", "month", "day".
   * This is for the spinner positioning.
   * @return {Array.<String>} an array of names of time data, sorted per the time format
   */
  inputDate._getTimeFormatOrderObject = function()
  {
    if (inputDate._timeFormatOrder == null)
    {
      var timePattern = inputDate._removePatternLiterals(inputDate._timePattern);
      var littleHIndex = timePattern.indexOf("h");
      var bigHIndex = timePattern.indexOf("H");
      var littleKIndex = timePattern.indexOf("k");
      var bigKIndex = timePattern.indexOf("K");
      var hoursIndex = littleHIndex;
      if (hoursIndex == -1)
        hoursIndex = bigHIndex;
      if (hoursIndex == -1)
        hoursIndex = littleKIndex;
      if (hoursIndex == -1)
        hoursIndex = bigKIndex;

      var minIndex = timePattern.indexOf("m");
      var amPmIndex = timePattern.indexOf("a");
      if (amPmIndex == -1)
      {
        // Microsoft uses a non-Unicode specification for AM/PM ("t" or "tt"):
        // https://msdn.microsoft.com/en-us/library/8kb3ddd4(v=vs.110).aspx#ttSpecifier
        amPmIndex = timePattern.indexOf("t");
      }

      var orderObject =
        [
          [ "hours", hoursIndex ],
          [ "min", minIndex ],
          [ "amPm", amPmIndex == -1 ? Number.MAX_VALUE : amPmIndex ]
        ];

      // When dealing with number values in RTL mode, the spinners should appear
      // using big-endian ordering instead:
      if (document.documentElement.dir == "rtl")
      {
        // Make the order big-endian (reversed due to cell swapping):
        orderObject[0][1] = 1;
        orderObject[1][1] = 0;
        orderObject[2][1] = amPmIndex == -1 ? Number.MAX_VALUE : 2;
      }

      orderObject = orderObject.sort(inputDate._formatComparator);

      // Extract out just the names of the data to a simpler list:
      inputDate._timeFormatOrder = [ orderObject[0][0], orderObject[1][0], orderObject[2][0] ];
    }
    return inputDate._timeFormatOrder;
  };

  inputDate._getLocalizedTimeTextFromRawValue = function(rawValue)
  {
    if (rawValue["hour1to12"] == null)
      return "";

    var hours = parseInt(inputDate._getLocalizedHourFromRawValue(rawValue), 10);
    var minText = inputDate._getLocalizedMinutesFromRawValue(rawValue);
    var amPmText = inputDate._getLocalizedAmPmFromRawValue(rawValue);
    var isPm = rawValue["isPm"];
    var timePattern = inputDate._timePattern;
    var noLiteralPattern = inputDate._removePatternLiterals(timePattern);
    var littleHIndex = noLiteralPattern.indexOf("h");
    var bigHIndex = noLiteralPattern.indexOf("H");
    var littleKIndex = noLiteralPattern.indexOf("k");
    var bigKIndex = noLiteralPattern.indexOf("K");
    var hoursIndex = littleHIndex;
    if (hoursIndex == -1)
      hoursIndex = bigHIndex;
    if (hoursIndex == -1)
      hoursIndex = littleKIndex;
    if (hoursIndex == -1)
      hoursIndex = bigKIndex;
    var minIndex = noLiteralPattern.indexOf("m");
    var amPmIndex = noLiteralPattern.indexOf("a");
    if (amPmIndex == -1)
    {
      // Microsoft uses a non-Unicode specification for AM/PM ("t" or "tt"):
      // https://msdn.microsoft.com/en-us/library/8kb3ddd4(v=vs.110).aspx#ttSpecifier
      amPmIndex = noLiteralPattern.indexOf("t");
    }

    var result;
    if (hoursIndex == -1 || minIndex == -1)
    {
      // the given date format was unusable
      result =
        hours +
        ":" +
        minText +
        " " +
        amPmText;
    }
    else
    {
      // insert pieces into the given time format
      var adjustedHours;
      var paddedAdjustedHours;

      result = inputDate._applyReplacementsToUnquotedParts(
        timePattern,
        function(patternPart)
        {
          // See http://unicode.org/reports/tr35/tr35-4.html#Date_Format_Patterns
          patternPart = patternPart.replace(/[A-GIJL-Zb-gijln-su-z]/g, "?"); // unsupported letters = ?; we support HKahkmt & non-alpha chars

          if (littleHIndex != -1) // 1-12 hours (midnight = 12)
          {
            paddedAdjustedHours = hours;
            if (paddedAdjustedHours < 10)
              paddedAdjustedHours = "0" + paddedAdjustedHours; // pad with a zero

            patternPart = patternPart.replace(/h{2,2}/g, paddedAdjustedHours);
            patternPart = patternPart.replace(/h{1,1}/g, hours);
          }

          if (bigHIndex != -1) // 0-23 hours (midnight = 0)
          {
            adjustedHours = hours;
            if (isPm)
            {
              if (adjustedHours != 12) // PM but not 12 PM
                adjustedHours += 12;
            }
            else // is AM
            {
              if (hours == 12) // 12 AM
                adjustedHours = 0;
            }

            paddedAdjustedHours = adjustedHours;
            if (paddedAdjustedHours < 10)
              paddedAdjustedHours = "0" + paddedAdjustedHours; // pad with a zero

            patternPart = patternPart.replace(/H{2,2}/g, paddedAdjustedHours);
            patternPart = patternPart.replace(/H{1,1}/g, adjustedHours);
          }

          if (littleKIndex != -1) // 1-24 hours (midnight = 24)
          {
            adjustedHours = hours;
            if (isPm)
            {
              adjustedHours += 12;
            }
            else if (hours == 12)
            {
              adjustedHours = 24;
            }

            paddedAdjustedHours = adjustedHours;
            if (paddedAdjustedHours < 10)
              paddedAdjustedHours = "0" + paddedAdjustedHours; // pad with a zero

            patternPart = patternPart.replace(/k{2,2}/g, paddedAdjustedHours);
            patternPart = patternPart.replace(/k{1,1}/g, adjustedHours);
          }

          if (bigKIndex != -1) // 0-11 hours (midnight = 0)
          {
            adjustedHours = hours;
            if (hours == 12) // 12 AM or 12 PM
              adjustedHours = 0;

            paddedAdjustedHours = adjustedHours;
            if (paddedAdjustedHours < 10)
              paddedAdjustedHours = "0" + paddedAdjustedHours; // pad with a zero

            patternPart = patternPart.replace(/K{2,2}/g, paddedAdjustedHours);
            patternPart = patternPart.replace(/K{1,1}/g, adjustedHours);
          }

          patternPart = patternPart.replace(/m{2,}/g, minText);
          patternPart = patternPart.replace(/m{1,1}/g, parseInt(minText, 10));
          patternPart = patternPart.replace(/[at]+/g, amPmText);
          return patternPart;
        });
    }

    return result;
  };

  /**
   * Replace parts of the given string without applying further replacements
   * on the previously-replaced portions.
   * @param {string} rawValue the raw string to do replacements on
   * @param {Array.<Array.<string>>} replacements array of tokens and replacement text
   * @param {number} r the replacement index currently examining
   * @return {string} the result with replacements applied
   */
  inputDate._replacePartsConcurrently = function(rawValue, replacements, r)
  {
    if (r == undefined)
      r = -1;
    else if (r == replacements.length - 1)
      return rawValue;
    ++r;

    if (rawValue == null || rawValue.length == 0)
      return inputDate._replacePartsConcurrently(part, replacements, r);

    var token = replacements[r][0];
    var replacement = replacements[r][1];
    var splits = rawValue.split(token);

    for (var s=0, splitCount = splits.length; s<splitCount; ++s)
    {
      var part = splits[s];
      splits[s] = inputDate._replacePartsConcurrently(part, replacements, r);
    }

    return splits.join(replacement);
  };

  /**
   * Replace parts of the given string without applying further replacements
   * on the previously-replaced portions.
   * @param {string} rawValue the raw string to do replacements on
   * @param {Function} replacer the function responsible for applying replacements to the unquoted parts and returning its results
   * @return {string} the fully replaced result
   */
  inputDate._applyReplacementsToUnquotedParts = function(rawValue, replacer)
  {
    var result = rawValue;
    if (result != null)
    {
      // Leave in apostrophe-surrounded strings and convert double apostrophe to single apostrophe
      result = result.replace(/''/g, "$_*!"); // Use "ooo" as a temporary placeholder
      var splits = result.split("'");
      var parts = [];
      for (var i=0, count=splits.length; i<count; ++i)
      {
        var split = splits[i];
        split = split.replace(/\$_\*\!/g, "'"); // Insert the apostrophes
        if (i % 2 == 0) // i was even meaning this split needs replacements
          parts.push(replacer(split));
        else // i was odd meaning this split only has literal text
          parts.push(split);
      }
      result = parts.join(""); // assemble the parts back together
    }
    return result;
  };

  /**
   * If all we care about is token order, we need to remove all string literals
   * from the pattern and look at order within that result instead.
   * This function removes the alphabetical literal text from the pattern (the
   * apostrophe-surrounded parts).
   * @param {string} rawValue the raw pattern
   * @return {string} the pattern with alphabetical literal text removed
   */
  inputDate._removePatternLiterals = function(rawValue)
  {
    var result = rawValue;
    if (result != null)
    {
      // First get rid of the apostrophe characters
      result = result.replace(/''/g, ""); // '' means a ' character

      // Then strip out the blocks of text that are surrounded by ' chars:
      var splits = result.split("'");
      var keep = [];
      for (var i=0, count=splits.length; i<count; i=i+2)
      {
        keep.push(splits[i]);
      }
      result = keep.join("");
    }
    return result;
  };

  inputDate._getLocalizedMonthFromRawValue = function(rawValue)
  {
    if (rawValue["monthIndex"] == null)
      return "";
    return inputDate._LOCALIZED_MONTH_ARRAY[rawValue["monthIndex"]];
  };

  inputDate._getLocalizedDayFromRawValue = function(rawValue)
  {
    if (rawValue["dayNumber"] == null)
      return "";
    return rawValue["dayNumber"];
  };

  inputDate._getLocalizedYearFromRawValue = function(rawValue)
  {
    if (rawValue["year"] == null)
      return "";
    return rawValue["year"];
  };

  inputDate._getLocalizedHourFromRawValue = function(rawValue)
  {
    if (rawValue["hour1to12"] == null)
      return "";
    return rawValue["hour1to12"];
  };

  inputDate._getLocalizedMinutesFromRawValue = function(rawValue)
  {
    if (rawValue["min"] == null)
      return "";

    var displayMinutes = rawValue["min"];
    if (displayMinutes < 10)
    {
      displayMinutes = "0" + displayMinutes;
    }
    return displayMinutes;
  };

  inputDate._getLocalizedAmPmFromRawValue = function(rawValue)
  {
    if (rawValue["isPm"] == null)
      return "";
    return (rawValue["isPm"] ? inputDate._LOCALIZED_TIME_PM : inputDate._LOCALIZED_TIME_AM);
  };

  // Verify that this object is a valid date.  We check for presence of the toISOString function and verify that the time
  // in milliseconds in not NaN
  inputDate._isValidDate = function(date)
  {
    return (typeof date.toISOString === "function") && !isNaN(date.getTime());
  };

  // When the seconds and milliseconds on a date are both 0, the native control will remove them from the value attribute
  // and dateLabel.value returns "YYYY-MM-DDTHH:MMZ".  However, Date.parse() chokes on this even though it is a valid
  // ISO 8601 format.  To avoid this failure, we add the seconds and milliseconds so the value looks like "YYYY-MM-DDTHH:MM:00.000Z"
  inputDate._fillDateText = function(dateString)
  {
    var i = dateString.indexOf("T");
    if (i > -1 && (i + 1) < dateString.length)
    {
      var time = dateString.substring(i + 1);
      if (time.length == 6)
      {
        // this string looks like "HH:MMZ".  It is missing the optional seconds and milliseconds so we add them as zeroes
        time = time.substring(0, 5) + ":00.000Z";
      }
      else if (time.length == 9)
      {
        // this string looks like "HH:MM:SSZ".  It is missing the optional milliseconds so we add them as zeroes
        time = time.substring(0, 8) + ".000Z";
      }
      dateString = dateString.substring(0, i + 1) + time;
    }
    return dateString;
  };

  // Browser based HTML5 Date/Time Picker creation for iOS, Android and UWP
  inputDate._createHtml5InputDate = function(amxNode, field, value, inputType, dateObject)
  {
    var dateLabel = document.createElement("input");
    dateLabel.setAttribute("id", amxNode.getId() + "_trigger");
    dateLabel.setAttribute("class", "amx-inputDate-content");
    dateLabel.setAttribute("type", inputType);
    field.fieldValue.appendChild(dateLabel);
    if (inputType == "datetime")
    {
      // iOS 7 dropped type="datetime" so we have to use type="datetime-local"
      // and convert the actual value between those types.
      // Since we are giving the browser a value, it wants a datetime-local
      // value and we need to convert it from a datetime value since that's our
      // tag's API:
      dateLabel.setAttribute("type", "datetime-local");
      dateLabel.setAttribute("data-datetime-value", value);
      dateLabel.value = inputDate._toDateTimeLocalString(value);
    }
    else // use the value directly
    {
      dateLabel.value = value;
    }
    adf.mf.internal.amx._setNonPrimitiveElementData(dateLabel, "value", dateObject);
    adf.mf.internal.amx.registerFocus(dateLabel);

    // Workaround an android bug where the value selected does not stick to the input field
    var eventType = adf.mf.internal.amx.agent["type"] === "Android" ? "change" : "blur";

    adf.mf.api.amx.addBubbleEventListener(dateLabel, eventType,
      function(event)
      {
        var oldDate = adf.mf.internal.amx._getNonPrimitiveElementData(dateLabel, "value");
        var newDate;
        if (dateLabel.value === "")
        {
          // The value is set to "" when the user clicks "Clear" on the picker.  When that happens we simply want to set the new value to null
          newDate = {};
          newDate[".null"] = true;
        }
        else // The value is an actual date/time so we create a Date object
        {
          if (inputType === "time")
          {
            if (inputDate._isValidDate(oldDate))
            {
              newDate = new Date(oldDate.getTime());
            }
            else
            {
              newDate = new Date();
            }
            adf.mf.internal.amx.updateTime(newDate, dateLabel.value);
          }
          else if (inputType === "date")
          {
            if (inputDate._isValidDate(oldDate))
            {
              newDate = new Date(oldDate.getTime());
            }
            else
            {
              newDate = new Date();
            }
            adf.mf.internal.amx.updateDate(newDate, dateLabel.value);
          }
          else // datetime
          {
            // iOS 7 dropped type="datetime" so we have to use type="datetime-local"
            // and convert the actual value between those types.
            // Since we are asking the browser for a value, it is now giving us
            // a datetime-local value and we need to convert it to a datetime
            // value since that's our tag's API:
            var dateTimeValue = dateLabel.value;
            dateLabel.setAttribute("data-datetime-value", dateTimeValue);
            dateTimeValue =
              inputDate._toDateTimeIsoString(inputDate._fillDateText(dateTimeValue));

            newDate = new Date(dateTimeValue);
            if (inputDate._isValidDate(oldDate))
            {
              newDate.setMilliseconds(oldDate.getMilliseconds());
            }
          }
        }

        // if old and new date are null or if they represent the same time, we don't fire an event
        if ((newDate[".null"] == true && oldDate[".null"] == true) ||
          (inputDate._isValidDate(newDate) && inputDate._isValidDate(oldDate) && newDate.getTime() == oldDate.getTime()))
        {
          // do nothing
        }
        else
        {
          // old and new date are different so fire the event
          var newValue;
          if (inputDate._isValidDate(newDate))
          {
            newValue = newDate.toISOString(); // a predictable 24-character ISO value
            newValue = newValue.replace(/:\d\d.\d\d\d/, ":00.000"); // zero out seconds and millis
          }
          else
          {
            newValue = newDate;
          }

          var oldValue;
          if (inputDate._isValidDate(oldDate))
          {
            oldValue = oldDate.toISOString();
          }
          else
          {
            oldValue = oldDate;
          }

          var vce = new amx.ValueChangeEvent(oldValue, newValue);
          adf.mf.api.amx.processAmxEvent(amxNode, "valueChange", "value", newValue, vce);
        }

        adf.mf.internal.amx._setNonPrimitiveElementData(dateLabel, "value", newDate);
      });
      
    adf.mf.api.amx.addBubbleEventListener(dateLabel, "tap", function(event)
    {
      // Stop propagation of the event to parent components
      event.stopPropagation();
    });

    // if disabled is set to true for iOS
    var disabled = amxNode.getAttribute("disabled");
    if (disabled == true)
    {
      dateLabel.setAttribute("disabled", disabled);
      // Adding WAI-ARIA Attribute for the disabled state
      dateLabel.setAttribute("aria-disabled", disabled);
    }

    // Set wai-aria required attribute to true if required/showRequired is set to true
    var isRequired = (adf.mf.api.amx.isValueTrue(amxNode.getAttribute("showRequired")) ||
                   adf.mf.api.amx.isValueTrue(amxNode.getAttribute("required")));
    if (isRequired)
      dateLabel.setAttribute("aria-required", "true");
  };

  inputDate.setUnitTestFormat = function(datePattern, timePattern)
  {
    if (document.querySelector(".amx-automation") == null &&
      !adf.mf.environment.profile.mockData)
      return;

    if (inputDate._defaultDatePattern == null)
      inputDate._defaultDatePattern = inputDate._datePattern; // set up the default
    if ((datePattern == null || datePattern == "") && inputDate._defaultDatePattern != null)
      datePattern = inputDate._defaultDatePattern; // reset to default

    if (inputDate._defaultTimePattern == null)
      inputDate._defaultTimePattern = inputDate._timePattern; // set up the default
    if ((timePattern == null || timePattern == "") && inputDate._defaultTimePattern != null)
      timePattern = inputDate._defaultTimePattern; // reset to default

    if (datePattern != null)
    {
      if (inputDate._defaultDatePattern == null)
        inputDate._defaultDatePattern = inputDate._datePattern;
      inputDate._datePattern = datePattern;
      inputDate._datePatternFetched = true;

      // reset things so they will be recomputed
      inputDate._dateFormatOrder = null;
    }

    if (timePattern != null)
    {
      if (inputDate._defaultTimePattern == null)
        inputDate._defaultTimePattern = inputDate._timePattern;
      inputDate._timePattern = timePattern;
      inputDate._timePatternFetched = true;

      // reset things so they will be recomputed
      inputDate._timeFormatOrder = null;
    }

    // Re-render the view:
    adf.mf.api.amx.AmxNode.getAmxNodeForElement(document.querySelector(".amx-view")).rerender();
  };

  /*
   * Examples of datetime:
   * - 2013-10-15T20:40:20.000Z
   * - 2013-10-15T14:40:20Z
   *
   * Examples of datetime-local:
   * - 2013-10-15T14:40:20.000
   * - 2013-10-15T14:40:20.000+00:00
   * - 2013-10-15T14:40:20.000-00:00
   * - 2013-10-15T14:40:20
   * - 2013-10-15T14:40:20+00:00
   * - 2013-10-15T14:40:20-00:00
   */

  /**
   * Converts an HTML5 input type="datetime" value to a type="datetime-local" value.
   * @param {String} dateTimeIsoString an HTML5 input type="datetime" value
   * @return {String} blank or an HTML5 input type="datetime-local" value
   */
  inputDate._toDateTimeLocalString = function(dateTimeIsoString)
  {
    try
    {
      if (dateTimeIsoString == null || dateTimeIsoString == "")
        return "";

      // Use the current local timezone offset to do the conversion:
      var dateObj = new Date(dateTimeIsoString);
      var timezoneOffset = dateObj.getTimezoneOffset();
      dateObj.setMinutes(dateObj.getMinutes() - timezoneOffset);
      var dateTimeLocalString = dateObj.toISOString().replace("Z", "");
      return inputDate._fillDateText(dateTimeLocalString);
    }
    catch (e)
    {
      return "";
    }
  };

  /**
   * Converts an HTML5 input type="datetime-local" value to a type="datetime" value.
   * @param {String} dateTimeLocalString an HTML5 input type="datetime-local" value
   * @return {String} blank or an HTML5 input type="datetime" value
   */
  inputDate._toDateTimeIsoString = function(dateTimeLocalString)
  {
    try
    {
      if (dateTimeLocalString == null || dateTimeLocalString == "")
        return "";

      // Format the local string for better browser support (e.g. Firefox 21):
      var tIndex = dateTimeLocalString.indexOf("T");
      var timePortion = dateTimeLocalString.substring(tIndex);
      if (timePortion.indexOf("-") == -1 && timePortion.indexOf("+") == -1)
      {
        // Then there was no timezone offset given so let's add it:
        dateTimeLocalString += "+00:00";
      }

      // Use the current local timezone offset to do the conversion:
      var dateObj = new Date(dateTimeLocalString);
      var timezoneOffset = dateObj.getTimezoneOffset();
      dateObj.setMinutes(dateObj.getMinutes() + timezoneOffset);
      var dateTimeIsoString = dateObj.toISOString();
      return inputDate._fillDateText(dateTimeIsoString);
    }
    catch (e)
    {
      return "";
    }
  };

})();