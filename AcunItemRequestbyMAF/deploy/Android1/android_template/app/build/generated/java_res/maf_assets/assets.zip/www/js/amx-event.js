/* Copyright (c) 2011, 2018, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* --------------------- amx-event.js ------------------- */
/* ------------------------------------------------------ */

(function()
{
  var _currentFocusDomNode = null;
  var _focusBlurEventData = {}; // allows these focus/blur events to be unique from other focus/blur events

  /**
   * Internal method to bind to the focus method and be notified when another control gains focus
   */
  adf.mf.internal.amx.registerFocus = function(domNode, callback)
  {
    adf.mf.api.amx.addBubbleEventListener(
      domNode,
      "focus",
      function(event)
      {
        // register this node in order to receive events when another control is tapped
        _currentFocusDomNode = domNode;
        if (callback)
        {
          callback(event);
        }
      },
      _focusBlurEventData);
  };

  /**
   * Internal method to bind to the blur method and be notified when another control gains focus
   */
  adf.mf.internal.amx.registerBlur = function(domNode, callback)
  {
    adf.mf.api.amx.addBubbleEventListener(
      domNode,
      "blur",
      function(event)
      {
        // unregister this node - no more need to receive events when another control is tapped
        if (_currentFocusDomNode == domNode)
        {
          _currentFocusDomNode = null;
        }
        if (callback)
        {
          callback(event);
        }
      },
      _focusBlurEventData);
  };

  /**
   * Internal method used to trigger focus event or call focus on an element
   * @param {type} element
   * @param {type} triggerEvent whether to tigger event of call focus method
   * 
   */
  function triggerFocusOnNode(element, triggerEvent)
  {
    if (element.tagName === "SELECT" || element.tagName === "INPUT")
    {
      var amxNode = adf.mf.api.amx.AmxNode.getAmxNodeForElement(element);

      // set an attribute on the amx node that the focus event is triggered to to "tap" handler.
      // This is currently used by the amxInput to prevent multiple validation errors on blur
      if (amxNode)
      {
        amxNode.setAttributeResolvedValue("_focusOnTap", true);
      }

      try
      {
        triggerEvent ? adf.mf.api.amx.triggerBubbleEventListener(element, "focus") :
                       element.focus();
      }
      finally 
      {
        if (amxNode)
        {
          amxNode.setAttributeResolvedValue("_focusOnTap", undefined);
        }
      }
    }
  }
  
  // this method calls blur on the currentFocus node
  // in order to give it a chance to saved its internal changes
  // first we will blur the node in order to trigger value change events etc
  // then we restore focus back so that we don't accidently cause the user to get the
  // wrong focus - due to keyboard hiding/showing in other words, so that the touchstart &
  // touchend events occur on the same element
  function blurCurrentNode()
  {
    var oldCurrentNode = _currentFocusDomNode;
    var oldActiveElement = document.activeElement;

    if (_currentFocusDomNode != null)
      adf.mf.api.amx.triggerBubbleEventListener(_currentFocusDomNode, "blur");

    if (document.activeElement != null && document.activeElement.blur != null)
      document.activeElement.blur();

    if (oldCurrentNode != null)
    {
      triggerFocusOnNode(oldCurrentNode, true);
    }

    if (oldActiveElement != null && oldActiveElement.focus != null)
    {
      triggerFocusOnNode(oldActiveElement, false);
    }
  }

  function triggerEvent(eventTarget, eventName, triggerExtra)
  {
    if (eventName == "tap")
    {
      // "tap" is not a real event so we need to trigger the real events for it
      var tapEvents = _getTapEvents();
      triggerEvent(eventTarget, tapEvents.start, triggerExtra);
      triggerEvent(eventTarget, tapEvents.end, triggerExtra);
    }
    else if (eventName == "taphold")
    {
      // "taphold" is not a real event so we need to trigger the real events for
      // it (the 2nd event needs to take place after the underlying 1st event's
      // timeout occurs hence the addition of 1 to the threshold).
      var tapHoldEvents = _getTapEvents();
      triggerEvent(eventTarget, tapHoldEvents.start, triggerExtra);
      setTimeout(
        function()
        {
          triggerEvent(eventTarget, tapHoldEvents.end, triggerExtra);
        },
        1+holdThreshold);
    }
    else
    {
      adf.mf.internal.triggerEvent(
        eventTarget,
        "HTMLEvents",
        eventName,
        true,
        true,
        triggerExtra);
    }
  }

  function _isSimpleObject(o)
  {
    return Object.prototype.toString.call(o) == "[object Object]";
  }

  /**
   * Utility to merge an arbitrary list of simple objects onto the given base object.
   * If any of the given objects is determined to not be a simple object, the merging
   * will cease and false is returned.
   * @param {Object} baseObject the simple object that the remaining objects will be added to (in order)
   * @return {Boolean} whether the full set of objects was merged
   */
  function _mergeSimpleObjects(baseObject)
  {
    if (!_isSimpleObject(baseObject))
      return false;

    // Loop through the rest of the arguments to merge their properties into the base object
    var args = Array.prototype.slice.call(arguments);

    for (var i = 1, count = args.length; i < count; ++i)
    {
      var objectToMerge = args[i];

      if (!_isSimpleObject(objectToMerge))
        return false;

      for (var key in objectToMerge)
        baseObject[key] = objectToMerge[key];
    }

    return true;
  }

  var tapPendingIds = {};

  function cancelPendingTap()
  {
    tapPendingIds = {};
  }

  var _tapEvents = null;
  var _getTapEvents = function()
  {
    if (_tapEvents == null)
      _tapEvents = amx.hasTouch() ? { start: "touchstart", end: "touchend", cancel: "touchcancel" } : { start: "mousedown", end: "mouseup", cancel: "" };
    return _tapEvents;
  };

  var _addSpecialTapBubbleEventListener = function(domNode, eventType, listener, eventData)
  {
    var tapEvents = _getTapEvents();
    var tapId = null;
    var originalPosition = null;
    var startListener = function(event)
    {
      // if there is a node that registered its focus, then
      // the first thing to do is blur that focus here
      var newFocusedTagName = domNode.tagName;

      // Do the focus processing only at the target for this event. This is so that if the event is
      // bubbled up from an input/select component we do not want the blur happening on it.
      // For e.g. SOC component will close the dropdown on blur
      if ((!tapId || !tapPendingIds[tapId]) &&
          newFocusedTagName != "INPUT" && newFocusedTagName != "SELECT") // virtual keyboard elements
      {
        blurCurrentNode();

        // The blur could have put a loading indicator to process "valuechange".
        // This would bring up a processing indicator (PI). In WebKit (iOS and Android)
        // touch up (after down) will be fired irrespective of the laoding indicator being up.
        // In UWP the mouseup event is swallowed by the processing indicator div.
        // So hide the PI div. The action event will be queued for processing and it will
        // again bring up PI so we will still block subsequent user interactions.
        if (adf.mf.internal.amx.agent["type"] === "UWP")
        {
          adf.mf.api.amx.hideLoadingIndicator();
        }
      }
      tapId = amx.uuid(); // TODO don't use amx.foo!
      tapPendingIds[tapId] = true;
      originalPosition = _getEventPagePosition(event);
    };
    var endListener = function(event)
    {
      if (tapPendingIds[tapId])
      {
        // Ignore taps if the finger moves too much between start and end.
        // The points might be null in automated testing mode so allow the tap
        // if points cannot be determined.
        var newPosition = _getEventPagePosition(event);
        var pointsCloseEnough =
          Math.abs(originalPosition["pageX"] - newPosition["pageX"]) < 25 &&
          Math.abs(originalPosition["pageY"] - newPosition["pageY"]) < 25;
        if (pointsCloseEnough ||
           originalPosition["pageX"] == null ||
           originalPosition["pageY"] == null ||
           newPosition["pageX"] == null ||
           newPosition["pageY"] == null)
        {
          adf.mf.api.amx.showLoadingIndicator();
          listener.call(this, event);
          adf.mf.api.amx.hideLoadingIndicator();
        }
        originalPosition = null;
        delete tapPendingIds[tapId];
        cancelPendingDrag(true, false);
      }
    };
    var cancelListener = function(event)
    {
      // Starting in Android 4.4, sometimes the browser will trigger a cancel
      // event before you lift your finger. In such cases, we can't reliably
      // honor the gesture as a tap because the 2 points are inaccurate.
      if (tapPendingIds[tapId])
      {
        originalPosition = null;
        delete tapPendingIds[tapId];
        cancelPendingDrag(true, false);
      }
    };
    // We used to ignore tap cancel but this is no longer valid with the new Chrome WebView in 4.4. Like native Chrome,
    // this will generate the cancel event if the preventDefault is not registered within 250ms. Since we get a touchStart
    // we need to figure out what the intent of the touch is (tap and hold or just tap or drag and drop). The issue
    // is the 250ms is a system time (outside the WebView) and when the WebView is busy (over long runs in Selenium), or
    // lots of open features then we start to slow down where some of the clicks are not addressed in time and we get a
    // touch cancel. What we do instead is treat the cancel like a touch end.
    if (tapEvents.cancel != "")
    {
      _addSpecialBubbleEventListener(
        domNode,
        eventType,
        listener,
        eventData,
        [
          [ tapEvents.start,  startListener ],
          [ tapEvents.end,    endListener ],
          [ tapEvents.cancel, cancelListener ]
        ]);
    }
    else
    {
      _addSpecialBubbleEventListener(
        domNode,
        eventType,
        listener,
        eventData,
        [
          [ tapEvents.start, startListener ],
          [ tapEvents.end,   endListener ]
        ]);
    }
  };
  // --------- /Tap Event --------- //

  // --------- Tap Hold --------- //
  var tapHoldPendingIds = {};

  function cancelPendingTapHold()
  {
    tapHoldPendingIds = {};
  }

  var holdThreshold = 800;

  var _addSpecialTapHoldBubbleEventListener = function(domNode, eventType, listener, eventData)
  {
    var tapEvents = _getTapEvents();
    var tapId = null;
    var startListener = function(event)
    {
      tapId = amx.uuid(); // TODO don't use amx.foo!
      tapHoldPendingIds[tapId] = new Date().getTime();

      // Since we are using a timer, we need to fetch our eventData now for reapplication in the timer
      var eventData = event.data;

      setTimeout(function()
      {
        // Note: here we double check if the time is greater than the threshold. This is useful since sometime timeout
        //       is not really reliable.
        if (tapHoldPendingIds[tapId] > 0)
        {
          var timeOffset = new Date().getTime() - tapHoldPendingIds[tapId];
          if (timeOffset >= holdThreshold)
          {
            // Call the listener but make sure our eventData is used:
            var eventDataToRestore = event.data;
            event.data = eventData;
            var result = listener.call(domNode, event);
            event.data = eventDataToRestore;

            // if the handler consumes the tapHold, remove it from the tapPendingIds so that it does not count like a tap
            if (result === "consumeTapHold")
            {
              // Android requires that we preventDefault, otherwise native select/edit text mode can be triggered
              // This code does also fixes softKeyboard show/hide bug and let's user select/edit text for inputText component
              var agent = adf.mf.internal.amx.agent;
              if (agent["type"] == "Android")
              {
                event.preventDefault();
              }
              cancelPendingTap();
              cancelPendingTapHold();
              cancelPendingDrag(false, false);
            }
          }
          delete tapHoldPendingIds[tapId];
        }

      }, holdThreshold);
    };
    var endListener = function(event)
    {
      if (tapHoldPendingIds[tapId])
      {
        delete tapHoldPendingIds[tapId];
      }
    };
    _addSpecialBubbleEventListener(
      domNode,
      eventType,
      listener,
      eventData,
      [
        [ tapEvents.start, startListener ],
        [ tapEvents.end, endListener ]
      ]);
  };
  // --------- /Tap Hold --------- //

  // --------- Drag Event --------- //
  var dragPendingIds = {};
  var dragEvents = null;
  var dragTargetElements = [];

  function cancelPendingDrag(releaseLocks, triggerCancelOrEndBeforeRemove)
  {
    if (!triggerCancelOrEndBeforeRemove)
      dragPendingIds = {};

    if (releaseLocks)
    {
      if (!dragEvents)
        dragEvents = amx.hasTouch() ? touchDragEvents : mouseDragEvents;

      if (triggerCancelOrEndBeforeRemove)
      {
        // If a container is listening to drag events but a descendant gets removed, we need to
        // trigger the cancel/end listeners or else that container could get in a corrupt state:
        if (dragEvents.cancel != "")
          adf.mf.api.amx.triggerBubbleEventListener(document.documentElement, dragEvents.cancel);
        else
          adf.mf.api.amx.triggerBubbleEventListener(document.documentElement, dragEvents.end);
      }

      adf.mf.api.amx.removeBubbleEventListener(document.documentElement, dragEvents.drag, documentDragDrag);
      adf.mf.api.amx.removeBubbleEventListener(document.documentElement, dragEvents.end, documentDragEnd);
      if (dragEvents.cancel != "")
        adf.mf.api.amx.removeBubbleEventListener(document.documentElement, dragEvents.cancel, documentDragCancel);

      // For any drag listeners added to the target elements, remove the listeners
      for (var i = 0, size = dragTargetElements.length; i < size; i += 3)
      {
        var targetElement = dragTargetElements[i];
        var eventType = dragTargetElements[i + 1];
        var method = dragTargetElements[i + 2];

        targetElement.removeEventListener(eventType, method);
      }

      // Clear the list of additional target elements:
      dragTargetElements = [];

      releaseDragLock();

      // delete the dragContext since it no longer applies
      adf.mf.internal.amx._setNonPrimitiveElementData(document.documentElement, "dragCtx", null);
    }
  }

  var DRAGSTART = "amxdragstart";
  var DRAGDRAG = "amxdragdrag";
  var DRAGEND = "amxdragend";

  /**
   * Options optional method implementation:
   */
  var mouseDragEvents =
  {
    start: "mousedown",
    drag: "mousemove",
    end: "mouseup",
    cancel: ""
  };

  var touchDragEvents =
  {
    start: "touchstart",
    drag: "touchmove",
    end: "touchend",
    cancel: "touchcancel"
  };

  // Handler for the event DRAGSTART event.
  function handleDragEvent(e, options)
  {
    var domNode = this;
    var id = "_" + amx.uuid(); // TODO don't use amx.foo!

    dragPendingIds[id] = true;

    var startEvent = e;
    var startPagePos = _getEventPagePosition(startEvent);

    // so far, we prevent the default, otherwise, we see some text select which can be of a distracting
    // since we create "meta events" we consume this one
    // e.preventDefault();
    // e.stopPropagation();

    var documentDragData = {
      "options": options,
      "domNode": domNode,
      "id": id,
      "startEvent": startEvent,
      "startPagePos": startPagePos,
      "dragStarted": false
    };

    if (!dragEvents)
      dragEvents = amx.hasTouch() ? touchDragEvents : mouseDragEvents;

    // Check to see if the domNode is the event target. If it isn't, there is a chance that the target element
    // will be removed during the drag. In order to prevent this, listen for the drag and end events on the target
    // as well as the domNode. If the target is removed from the DOM, the subsequent events will still be
    // delivered to the target node
    var target = e.target;

    // We use the documentElement for the following 2 events so that the dragging doesn't stop when leaving the domNode.
    // In order to uniquely identify these listeners for removal the documentDragData will be passed in so that other
    // events of the same names on the document don't get lost.
    var needsDisconnectedListener = domNode !== target;

    // drag
    adf.mf.api.amx.addBubbleEventListener(document.documentElement, dragEvents.drag, documentDragDrag, documentDragData);

    // drag end
    adf.mf.api.amx.addBubbleEventListener(document.documentElement, dragEvents.end, documentDragEnd, documentDragData);

    if (needsDisconnectedListener)
    {
      bindDisconnectedDragListener(target, domNode, dragEvents.drag, documentDragDrag, documentDragData);
      bindDisconnectedDragListener(target, domNode, dragEvents.end, documentDragEnd, documentDragData);
    }

    // drag cancel
    if (dragEvents.cancel != "")
    {
      adf.mf.api.amx.addBubbleEventListener(document.documentElement, dragEvents.cancel, documentDragCancel, documentDragData);

      if (needsDisconnectedListener)
      {
        bindDisconnectedDragListener(target, domNode, dragEvents.cancel, documentDragCancel, documentDragData);
      }
    }
  }

  /**
   * Build a bound function that will listen for drag events on the target element of a touchstart/mousedown so that
   * if the element is removed from the DOM events will still be received.
   */
  function bindDisconnectedDragListener(target, domNode, eventType, method, documentDragData)
  {
    var disconnectedListener = handleDragOnDifferentTarget.bind(domNode, method, documentDragData);

    target.addEventListener(eventType, disconnectedListener);
    dragTargetElements.push(target, eventType, disconnectedListener);
  }

  /**
   * Check if a node is no longer a descendant of its parent. Used by handleDragOnDifferentTarget to determine if a drag
   * event needs to be fired
   */
  function isNodeDisconnectedFromParent(domNode, expectedParent)
  {
    for (var n = domNode; n != null; n = n.parentNode)
    {
      if (n === expectedParent)
      {
        return false;
      }
    }

    return true;
  }

  /**
   * Method invoked when a drag was started on a descendant of a target node. Checks if the node has become disconnected
   * from the DOM and if so it will invoke the method.
   */
  function handleDragOnDifferentTarget(documentDragMethod, dragData, event)
  {
    var domNode = this;
    var disconnected = isNodeDisconnectedFromParent(event.target, domNode);

    // Only invoke the event listener if the node was disconnected as if it is not the listener will be invoked normally
    if (disconnected)
    {
      var oldData = event.data;

      try
      {
        event.data = dragData;
        documentDragMethod.call(this, event);
      }
      finally
      {
        event.data = oldData;
      }
    }
  }

  function documentDragDrag(e)
  {
    var documentDragData = e.data;
    var options = documentDragData["options"];
    var domNode = documentDragData["domNode"];
    var id = documentDragData["id"];
    var startEvent = documentDragData["startEvent"];
    var startPagePos = documentDragData["startPagePos"];

    // if the drag has not started, check if we need to start it
    if (!documentDragData["dragStarted"] && dragPendingIds[id])
    {
      var currentPagePos = _getEventPagePosition(e);
      var offsetX = (startPagePos.pageX - currentPagePos.pageX);
      var offsetY = (startPagePos.pageY - currentPagePos.pageY);

      // if the diff > threshold, then, we start the drag
      if (Math.abs(offsetX) > options.threshold || Math.abs(offsetY) > options.threshold)
      {
        var dragCtx = adf.mf.internal.amx._getNonPrimitiveElementData(document.documentElement, "dragCtx");
        if (dragCtx == null) // if no drag is already in progress on the element...
        {
          documentDragData["dragStarted"] = true;

          // we cancel any pending tap event
          cancelPendingTap();
          cancelPendingTapHold();

          // create the dragCtx
          adf.mf.internal.amx._setNonPrimitiveElementData(document.documentElement, "dragCtx", {});

          var dragStartExtra = buildDragExtra(startEvent, domNode, DRAGSTART, startPagePos, currentPagePos);
          triggerEvent(domNode, DRAGSTART, dragStartExtra);
        }
      }
    }

    if (documentDragData["dragStarted"] && dragPendingIds[id])
    {
      // making sure they they are canceled
      cancelPendingTap();
      cancelPendingTapHold();

      var dragExtra = buildDragExtra(e, domNode, DRAGDRAG);
      triggerEvent(domNode, DRAGDRAG, dragExtra);

      // since we create "meta events" we consume this event if the meta event was consumed
      if (dragExtra.preventDefault)
        e.preventDefault();
      if (dragExtra.stopPropagation)
        e.stopPropagation();
    }
  }

  function documentDragEnd(e)
  {
    _documentDragFinish(e);
  }

  function documentDragCancel(e)
  {
    _documentDragFinish(e);
  }

  function _documentDragFinish(e)
  {
    var documentDragData = e.data;
    var domNode = documentDragData["domNode"];
    var id = documentDragData["id"];

    if (documentDragData["dragStarted"] && dragPendingIds[id])
    {
      var extra = buildDragExtra(e, domNode, DRAGEND);
      triggerEvent(domNode, DRAGEND, extra);

      // since we create "meta events" we consume this event if the meta event was consumed
      if (extra.preventDefault)
        e.preventDefault();
      if (extra.stopPropagation)
        e.stopPropagation();

      // Let other elements have a chance at handling drag events:
      extra.releaseDragLock();
    }

    // unbind the document event that is specifically tied to this documentDragData instance
    adf.mf.api.amx.removeBubbleEventListener(document.documentElement, dragEvents.drag, documentDragDrag, documentDragData);
    adf.mf.api.amx.removeBubbleEventListener(document.documentElement, dragEvents.end, documentDragEnd, documentDragData);
    if (dragEvents.cancel != "")
      adf.mf.api.amx.removeBubbleEventListener(document.documentElement, dragEvents.cancel, documentDragCancel, documentDragData);
    delete dragPendingIds[id];

    // delete the dragContext
    adf.mf.internal.amx._setNonPrimitiveElementData(document.documentElement, "dragCtx", null);
  }

  var currentDragElementH = null;
  var currentDragElementV = null;

  /**
   * Mechanism to release a reservation for horizontal and/or vertical drag behavior for the given element.
   * @param {HTMLElement} element the element that no longer wants to consume the specified drag events
   * @param {Boolean} horizontal whether you want to reserve drag events for the horizontal axis
   * @param {Boolean} vertical whether you want to reserve drag events for the horizontal axis
   * @return {Boolean} whether your release request was successful for the specified axes
   */
  function releaseDragLock(element, horizontal, vertical)
  {
    var releasedTheLock = false;

    if (element)
    {
      releasedTheLock = true;

      if (horizontal)
      {
        if (currentDragElementH == null || currentDragElementH == element)
          currentDragElementH = null;
        else
          releasedTheLock = false;
        }

      if (vertical)
      {
        if (currentDragElementV == null || currentDragElementV == element)
          currentDragElementV = null;
        else
          releasedTheLock = false;
        }
      }
    else // purge all
    {
      releasedTheLock = true;
      currentDragElementH = null;
      currentDragElementV = null;
    }

    return releasedTheLock;
  }

  /**
   * Mechanism to establish a reservation for horizontal and/or vertical drag behavior for the given element.
   * @param {HTMLElement} element the element that wants to consume the specified drag events
   * @param {Boolean} horizontal whether you want to reserve drag events for the horizontal axis
   * @param {Boolean} vertical whether you want to reserve drag events for the horizontal axis
   * @return {Boolean} whether your reservation request was granted for the specified axes
   */
  function requestDragLock(element, horizontal, vertical)
  {
    var gotTheLock = false;

    if (element)
    {
      gotTheLock = true;

      if (horizontal)
      {
        if (currentDragElementH == null || currentDragElementH == element)
          currentDragElementH = element;
        else
          gotTheLock = false;
      }

      if (vertical)
      {
        if (currentDragElementV == null || currentDragElementV == element)
          currentDragElementV = element;
        else
          gotTheLock = false;
      }
    }

    return gotTheLock;
  }

  /**
   * Build the extra event info for the drag event.
   * @param {Object} event TODO
   * @param {HTMLElement} domNode the dragged element
   * @param {String} dragType the custom drag event name
   * @param {Object} startPagePos optional argument with pageX and pageY properties
   * @param {Object} currentPagePos optional argument with pageX and pageY properties
   */
  function buildDragExtra(event, domNode, dragType, startPagePos, currentPagePos)
  {
    var hasTouch = amx.hasTouch(); // TODO don't use amx.foo!
    var extra = _getEventPagePosition(event); // fetch the pageX and pageY as appropriate
    extra["eventSource"] = event;
    extra["preventDefault"] = false;
    extra["stopPropagation"] = false;
    extra["releaseDragLock"] = releaseDragLock;
    extra["requestDragLock"] = requestDragLock;

    if (hasTouch)
    {
      extra.touches = event.touches;
    }

    var dragCtx = adf.mf.internal.amx._getNonPrimitiveElementData(document.documentElement, "dragCtx");
    if (dragCtx)
    {
      if (dragType === DRAGSTART)
      {
        dragCtx.startPageX = extra.startPageX = extra.pageX;
        dragCtx.startPageY = extra.startPageY = extra.pageY;

        dragCtx.lastPageX = dragCtx.startPageX = extra.startPageX;
        dragCtx.lastPageY = dragCtx.startPageY = extra.startPageY;
      }
      else if (dragType === DRAGEND)
      {
        // because, on iOS, the touchEnd event does not have the .touches[0].pageX
        extra.pageX = dragCtx.lastPageX;
        extra.pageY = dragCtx.lastPageY;
      }

      if (startPagePos != null && dragCtx.originalAngle == null)
      {
        // Calculate, using the start page event location, the angle that the user moved their
        // finger. Allows callers to determine the directionality that the user intends to scroll.
        var diffX = currentPagePos.pageX - startPagePos.pageX;
        var diffY = startPagePos.pageY - currentPagePos.pageY; // Y direction is reversed;

        // Determine the angle
        // angle = arctan(opposite/adjacent) (converted from radians to degrees)
        // Note that this computation uses 0 degrees as east, 90 is north.
        // Angles to the south and west are negative (-90 is south)
        dragCtx.originalAngle = Math.round(Math.atan2(diffY, diffX) * 180 / Math.PI);
      }

      extra.originalAngle = dragCtx.originalAngle;
      extra.startPageX = dragCtx.startPageX;
      extra.startPageY = dragCtx.startPageY;
      extra.deltaPageX = extra.pageX - dragCtx.lastPageX;
      extra.deltaPageY = extra.pageY - dragCtx.lastPageY;

      dragCtx.lastPageX = extra.pageX;
      dragCtx.lastPageY = extra.pageY;
    }
    else
    {
      adf.mf.log.logInfoResource("AMXInfoBundle", adf.mf.log.level.WARNING, "buildDragExtra",
        "MSG_DRAG_CTX_NULL");
    }

    return extra;
  }

  function _getEventPagePosition(e)
  {
    var pageX, pageY;
    if (e.changedTouches && e.changedTouches.length > 0)
    {
      pageX = e.changedTouches[0].pageX;
      pageY = e.changedTouches[0].pageY;
    }
    else if (e.touches && e.touches.length > 0)
    {
      pageX = e.touches[0].pageX;
      pageY = e.touches[0].pageY;
    }
    else
    {
      pageX = e.pageX;
      pageY = e.pageY;
    }

    return {
      "pageX": pageX,
      "pageY": pageY
    };
  }

  // --------- /Drag Event --------- //

  // -------- Swipe Event --------- //

  var swipeThreshold = 5;

  /**
   * Determine if it is a swipe event, and if yes, build the swipeExtra
   */
  function buildSwipeExtra(domNode, event, dragExtra)
  {
    var swipeExtra = null;
    var swipeDone = domNode.getAttribute("data-swipeDone");

    if (swipeDone != "true" && dragExtra)
    {
      var offsetX = (dragExtra.pageX - dragExtra.startPageX);
      var offsetY = (dragExtra.pageY - dragExtra.startPageY);
      var absOffsetX = Math.abs(offsetX);
      var absOffsetY = Math.abs(offsetY);
      if (absOffsetX >= absOffsetY && absOffsetX > swipeThreshold)
      {
        // Only consider it a drag if the angle of the drag is within 30 degrees of due horizontal
        var angle = Math.abs(dragExtra.originalAngle);
        if (angle <= 30 || angle >= 150)
        {
          swipeExtra = {};
          swipeExtra.swipeType = (offsetX > -1)?"swipeRight":"swipeLeft";
          domNode.setAttribute("data-swipeDone", "true");
        }
      }
      else if (absOffsetY >= absOffsetX && absOffsetY > swipeThreshold)
      {
        // Only consider it a drag if the angle of the drag is within 30 degrees of due vertical
        var ang = Math.abs(dragExtra.originalAngle);
        if (ang >= 60 && ang <= 120)
        {
          swipeExtra = {};
          swipeExtra.swipeType = (offsetY > -1)?"swipeDown":"swipeUp";
          domNode.setAttribute("data-swipeDone", "true");
        }
      }
    }

    return swipeExtra;
  }
  // -------- /Swipe Event --------- //

// --------- /events --------- //

// --------- Event Enabler --------- //

  /**
   * Triggers an HTML bubble event listener (e.g. tap, taphold, keydown,
   * touchstart, touchmove, touchend, focus, blur, resize, etc.).
   * It is important to note that web browsers do not support all event types on
   * all DOM nodes. Refer to browser documentation for specifics.
   * @param {DOMNode} eventTarget the target DOM node for this event
   * @param {String} eventName the name of the HTML event to listen for
   */
  adf.mf.api.amx.triggerBubbleEventListener = function(eventTarget, eventName)
  {
    triggerEvent(eventTarget, eventName);
  };

  /**
   * Register a bubble event listener (e.g. tap, taphold, keydown, touchstart, touchmove, touchend, focus,
   * blur, resize, etc.). It is important to note that web browsers do not support all event types on all
   * DOM nodes. Refer to browser documentation for specifics. The eventData is optional and
   * serves as extra data to be made available to your listener function.
   * @param {DOMNode} domNode the target element for this event
   * @param {String} eventType the name of the event to listen for
   * @param {Function} listener the function that will be invoked when the specified element encounters this event (with a parameter that is the DOM event object)
   * @param {Object} eventData extra event data that will be made available on the "data" member of the event object
   */
  adf.mf.api.amx.addBubbleEventListener = function(domNode, eventType, listener, eventData)
  {
    // For special events (ones we made up that delegate to other real events), we have more
    // work to do in order to add the listeners:
    if ("tap" == eventType)
    {
      _addSpecialTapBubbleEventListener(domNode, eventType, listener, eventData);
    }
    else if ("taphold" == eventType)
    {
      _addSpecialTapHoldBubbleEventListener(domNode, eventType, listener, eventData);
    }
    else
    {
      // Adding a real event listener:
      _addBubbleEventListener(domNode, eventType, listener, eventData);
    }
  };

  var _addBubbleEventListener = function(domNode, eventType, listener, eventData)
  {
    // Internal note: we will support eventData using a technique similar to this:
    // domNode.addEventListener("click", function() { var tempData = eventData; yourListener(tempData); }, false)
    // but we need to follow the removeEventListener "handleEvent" guidance noted here and we will need a
    // mechanism to remove all listeners at once (for the removeDomNode function) so that means we need to
    // track the listeners using some ID mechanism).

    if (domNode != null && listener != null)
    {
      var actualListener = function(event)
      {
// TODO integrate .registerFocus and .registerBlur here
        var oldData = event.data;

        if (eventData != null)
        {
          if (oldData == null)
          {
            // No merging necessary (only new data)
            event.data = eventData;
          }
          else // Try merging the 2 pieces of data
          {
            var merged = {};

            if (_mergeSimpleObjects(merged, oldData, eventData))
              event.data = merged; // Use the merged result
            else
              event.data = eventData; // Both are not objects so we can't merge; use only new data
          }
        }

        var result = listener.call(this, event, event.triggerExtra);

        event.data = oldData;

        if (result !== undefined)
        {
          if ((event.result = result) === false)
          {
            // Stop the event from continuing (e.g. max length hit in an inputText)
            event.preventDefault();
            event.stopPropagation();
          }
        }
      };

      var newListener = {
        "actualListener": actualListener,
        "eventType": eventType,
        "listener": listener,
        "eventData": eventData
      };

      if (domNode._amxListeners == null)
        domNode._amxListeners = [];

      domNode._amxListeners.push(newListener);
      domNode.addEventListener(eventType, actualListener, false);
    }
  };

  var _addSpecialBubbleEventListener = function(domNode, eventType, eventKey, eventData, backingListeners)
  {
    // specialEventsMap is a map with keys like "tap", "taphold", "amxdrag":
    var specialEventsMap = domNode._amxSpecialEvents;

    if (specialEventsMap == null)
    {
      specialEventsMap = {};
      domNode._amxSpecialEvents = specialEventsMap;
    }

    // Since there can be multiple instances of each special event type, each type points to an instance map.
    // The eventKeysMap is keyed by something that allows unique removal.
    // This key could be the developer's passed-in listener function (in the case of "tap" and "taphold") or
    // the developer's payload object (in the case of "amxdrag").
    var eventKeysMap = specialEventsMap[eventType];

    if (eventKeysMap == null)
    {
      eventKeysMap = {};
      specialEventsMap[eventType] = eventKeysMap;
    }

    // Each entry in eventKeysMap is a map keyed by the event data (possibly null):
    var eventDataMap = eventKeysMap[eventKey];

    if (eventDataMap == null)
    {
      eventDataMap = {};
      eventKeysMap[eventKey] = eventDataMap;
    }

    // Each entry in eventDataMap is an array of instance listeners.
    var instanceListenersArray = eventDataMap[eventData];

    if (instanceListenersArray == null)
    {
      instanceListenersArray = [];
      eventDataMap[eventData] = instanceListenersArray;
    }

    // Each member of instanceListeners is a backing listener array where index 0 is an
    // DOM event type and index 1 is a DOM event handler function.
    for (var i = 0, count = backingListeners.length; i < count; ++i)
    {
      var backingListener = backingListeners[i];

      _addBubbleEventListener(domNode, backingListener[0], backingListener[1], eventData);
      instanceListenersArray.push(backingListener);
    }
  };

  /**
   * Unregister a bubble event listener that was added via adf.mf.api.amx.addBubbleEventListener.
   * If eventType is not specified, all listeners registered by the add function will be removed.
   * If listener is not specified, all listeners registered by the add function of the given type will be removed.
   * @param {DOMNode} domNode the target element for which an event listener was previously added
   * @param {String} eventType the name of the event
   * @param {Function} listener the event listener function
   * @param {Object} eventData the extra event data
   */
  adf.mf.api.amx.removeBubbleEventListener = function(
    domNode,
    eventType,
    listener,
    eventData)
  {
    if (domNode != null)
    {
      if (eventType == null)
      {
        // Remove all special event listeners:
        _removeSpecialBubbleEventListener(domNode);
        delete domNode._amxSpecialEvents;

        // Remove all real event listeners:
        _removeBubbleEventListener(domNode);
      }
      else if ("tap" == eventType || "taphold" == eventType || "amxdrag" == eventType)
      {
        // For special events (ones we made up that delegate to other real events), we have more
        // work to do in order to remove the listeners:
        var eventKey = listener; // for "tap" and "taphold", the listener is the eventKey
        _removeSpecialBubbleEventListener(domNode, eventType, eventKey, eventData);
      }
      else
      {
        // Removing a real event listener:
        _removeBubbleEventListener(domNode, eventType, listener, eventData);
      }
    }
  };

  /**
   * Remove a bubble event listener.
   * @param {DOMNode} domNode the DOM node that owns the event listeners
   * @param {String} eventType the DOM event type (if not specified, all events will be removed)
   * @param {Function} listener the DOM event listener (if not specified, all events of the given type will be removed)
   * @param {Object} eventData the optional event data that is bundled with the event listener
   */
  var _removeBubbleEventListener = function(domNode, eventType, listener, eventData)
  {
    if (domNode != null && listener != null)
    {
      // Account for listeners not added via adf.mf.api.amx.addBubbleEventListener:
      domNode.removeEventListener(eventType, listener, false);
    }

    if (domNode != null && domNode._amxListeners != null)
    {
      // Account for listeners added via adf.mf.api.amx.addBubbleEventListener:
      var savedListeners = domNode._amxListeners;
      var savedListenerCount = savedListeners.length;

      for (var i = savedListenerCount - 1; i >= 0; --i)
      {
        var savedListener = savedListeners[i];
        var removeThisListener = false;
        if (eventType === undefined) // remove all saved listeners
        {
          eventType = savedListener["eventType"];
          removeThisListener = true;
        }
        else if (listener === undefined) // remove all saved listeners of this event type
          removeThisListener = savedListener["eventType"] == eventType;
        else if (eventData === undefined) // remove all saved listeners of this event type and listener function
          removeThisListener = savedListener["eventType"] == eventType && savedListener["listener"] == listener;
        else // remove only listeners that match this type, listener function, and event data
          removeThisListener = savedListener["eventType"] == eventType && savedListener["listener"] == listener &&
            savedListener["eventData"] == eventData;

        if (removeThisListener)
        {
          domNode.removeEventListener(eventType, savedListener["actualListener"], false);
          savedListeners.splice(i, 1); // remove that listener from the array
        }
      }

      if (domNode._amxListeners.length == 0)
        delete domNode._amxListeners;
    }
  };

  /**
   * Remove any special event listeners associated with the given information.
   * @param {DOMNode} domNode the DOM node that owns the event listeners
   * @param {String} eventType optional eventType to limit what gets removed
   * @param {Object} eventKey optional eventKey to limit what gets removed
   * @param {Object} eventData optional eventData to limit what gets removed
   */
  var _removeSpecialBubbleEventListener = function(domNode, eventType, eventKey, eventData)
  {
    var specialEventsMap = domNode._amxSpecialEvents;
    if (specialEventsMap == null)
    {
      return; // nothing was registered so nothing to remove
    }

    if (eventType == null)
    {
      // Remove for all possible special eventType values
      for (var foundEventType in specialEventsMap)
      {
        _removeSpecialEventForKeyAndData(domNode, specialEventsMap[foundEventType]);
        delete specialEventsMap[foundEventType];
      }
    }
    else
    {
      // Restrict removal to just this special eventType
      var eventKeysMap = specialEventsMap[eventType];
      _removeSpecialEventForKeyAndData(domNode, eventKeysMap, eventKey, eventData);
      if (Object.keys(eventKeysMap).length == 0)
        delete specialEventsMap[eventType]; // no more keys for this event type
    }

    if (Object.keys(specialEventsMap).length == 0)
      delete domNode._amxSpecialEvents; // no more special events of any type
  };

  /**
   * Remove special event listeners of a specific type associated with the given information.
   * @param {DOMNode} domNode the DOM node that owns the event listeners
   * @param {Object} eventKeysMap map of all special event keys for a particular eventType
   * @param {Object} eventKey optional eventKey to limit what gets removed
   * @param {Object} eventData optional eventData to limit what gets removed
   */
  var _removeSpecialEventForKeyAndData = function(domNode, eventKeysMap, eventKey, eventData)
  {
    if (eventKeysMap == null)
    {
      return; // nothing was registered so nothing to remove
    }

    if (eventKey == null)
    {
      // Remove all instances of this special eventType
      for (var foundEventKey in eventKeysMap)
      {
        _removeSpecialEventForData(domNode, eventKeysMap[foundEventKey]);
        delete eventKeysMap[foundEventKey];
      }
    }
    else
    {
      // Restrict removal to just this eventKey
      var eventDataMap = eventKeysMap[eventKey];
      _removeSpecialEventForData(domNode, eventDataMap, eventData);
      if (Object.keys(eventDataMap).length == 0)
        delete eventKeysMap[eventKey]; // no more keys for this event type and key combo
    }
  };

  /**
   * Remove special event listeners of a specific eventData associated with the given information.
   * @param {DOMNode} domNode the DOM node that owns the event listeners
   * @param {Object} eventDataMap map of all special eventData for a particular eventType and eventKey
   * @param {Object} eventData optional eventData to limit what gets removed
   * @return {Boolean} whether the specified listeners were removed
   */
  var _removeSpecialEventForData = function(domNode, eventDataMap, eventData)
  {
    if (eventDataMap == null)
    {
      return; // nothing was registered so nothing to remove
    }

    if (eventData == null)
    {
      // Remove all instances of this special eventData
      for (var foundEventData in eventDataMap)
      {
        _removeSpecialEventInstanceListeners(domNode, eventDataMap[foundEventData], foundEventData);
        delete eventDataMap[foundEventData];
      }
    }
    else
    {
      // Restrict removal to just this eventData
      var instanceListeners = eventDataMap[eventData];
      _removeSpecialEventInstanceListeners(domNode, instanceListeners, eventData);
      delete eventDataMap[eventData]; // no more keys for this event type and key combo
    }
  };

  /**
   * Remove special event listeners of associated with the given information.
   * @param {DOMNode} domNode the DOM node that owns the event listeners
   * @param {Object} instanceListeners the backing listener array
   * @param {Object} eventData optional eventData to limit what gets removed
   */
  var _removeSpecialEventInstanceListeners = function(domNode, instanceListeners, eventData)
  {
    if (instanceListeners == null)
    {
      return; // nothing was registered so nothing to remove
    }

    // Remove the real underlying events for this custom event listener
    for (var i=instanceListeners.length-1; i>=0; --i)
    {
      var backingListener = instanceListeners[i];
      // Note, for now we are not passing along eventData so that callers can delete references to
      // instanceListeners.
      _removeBubbleEventListener(domNode, backingListener[0], backingListener[1], eventData);
    }
  };

  /**
   * Allow a DOM node to trigger custom AMX events for amx:showPopupBehavior, amx:setPropertyListener, etc.
   * like "tapHold" and the "swipe".
   * @param {adf.mf.api.amx.AmxNode} amxNode the AmxNode that owns the DOM for the event
   * @param {DOMNode} domNode the DOM node that can trigger the event
   * @param {String} eventType the type of event being associated; either "tapHold" or "swipe"
   */
  adf.mf.api.amx.enableAmxEvent = function(amxNode, domNode, eventType)
  {
    if (eventType == "swipe")
      _enableSwipe(amxNode, domNode);
    else if (eventType == "tapHold")
      _enableTapHold(amxNode, domNode);
  };

  var _enableSwipe = function(amxNode, domNode)
  {
    var handler = function(event, swipeExtra)
    {
      var tag = amxNode.getTag();
      var swipeType = swipeExtra.swipeType;

      // check that we have at least one action with this type
      var childrenTags = tag.getChildren();
      for (var i=0, size=childrenTags.length; i<size; ++i)
      {
        var childTag = childrenTags[i];
        var childType = childTag.getAttribute("type");

        // The event processing doesn't know about start/end so use left/right if applicable:
        if (childType == "swipeStart")
        {
          if (document.documentElement.dir == "rtl")
            childType = "swipeRight";
          else
            childType = "swipeLeft";
        }
        else if (childType == "swipeEnd")
        {
          if (document.documentElement.dir == "rtl")
            childType = "swipeLeft";
          else
            childType = "swipeRight";
        }

        if (childType == swipeType)
        {
          var event = new amx.ActionEvent(); // TODO don't use amx.foo!
          adf.mf.api.amx.processAmxEvent(amxNode, swipeType, undefined, undefined, event);
          return "consumeSwipe";
        }
      }
    };

    var swipeConsumed = false;
    adf.mf.api.amx.addDragListener(
      domNode,
      {
        start: function(event, dragExtra) {},

        drag: function(event, dragExtra)
        {
          if (!swipeConsumed)
          {
            var swipeExtra = buildSwipeExtra(domNode, event, dragExtra);
            if (swipeExtra)
            {
              var result = handler.call(this, event, swipeExtra);
              if (result === "consumeSwipe")
              {
                swipeConsumed = true;
                domNode.removeAttribute("data-swipeDone");
              }
            }
           }
        },

        end: function(event, dragExtra)
        {
          swipeConsumed = false;
          domNode.removeAttribute("data-swipeDone");
        },

        threshold: 5
      });
  };

  var _enableTapHold = function(amxNode, domNode)
  {
    adf.mf.api.amx.addBubbleEventListener(
      domNode,
      "taphold",
      function(event)
      {
        var tag = amxNode.getTag();

        // check that we have at least one action with this type
        var childrenTags = tag.getChildren();
        for (var i=0, size=childrenTags.length; i<size; ++i)
        {
          var childTag = childrenTags[i];
          if (childTag.getAttribute("type") == "tapHold")
          {
            var event = new amx.ActionEvent(); // TODO don't use amx.foo!
            adf.mf.api.amx.processAmxEvent(amxNode, "tapHold", undefined, undefined, event);
            return "consumeTapHold";
          }
        }
      });
  };

  /**
   * Allow a DOM node to trigger AMX drag events.
   * The payload object defines 3 member functions: "start", "drag", "end" where each one's first parameter
   * is the DOM event, the second parameter is a "dragExtra" object with members: "eventSource" (the DOM event
   * source), "pageX" (the x coordinate of the event, "pageY" the y coordinate of the event, "startPageX" (the
   * original pageX), "startPageY" (the original pageY), "deltaPageX" (the change in pageX), "deltaPageY" (the
   * change in pageY), "originalAngle" (if available, it will be the original angle of the drag in degrees
   * where 0 degrees as east, 90 is north, -90 is south, 180 is west), and modifiable member flags:
   * "preventDefault", and "stopPropagation".
   * @param {DOMNode} domNode the DOM node that can trigger the drag event
   * @param {Object} payload the specifics about the drag event
   * @param {Object} eventData the extra event data
   */
  adf.mf.api.amx.addDragListener = function(domNode, payload, eventData)
  {
    var options =
    {
      threshold: 5
    };

    _mergeSimpleObjects(options, payload);

    var backingListeners = [];

    if (options.start)
      backingListeners.push([ DRAGSTART, options.start ]);

    if (options.drag)
      backingListeners.push([ DRAGDRAG, options.drag ]);

    if (options.end)
      backingListeners.push([ DRAGEND, options.end ]);

    var dragEvents = amx.hasTouch() ? touchDragEvents : mouseDragEvents;

    backingListeners.push([ dragEvents.start, function(e)
      {
        domNode.setAttribute("data-amxDragInProgress", "yes");
        handleDragEvent.call(domNode, e, options);
      }]);

    backingListeners.push([ dragEvents.end, function(e)
      {
        cleanElementsWithDragInProgress();
      }]);

    if (dragEvents.cancel != "")
    {
      backingListeners.push([ dragEvents.cancel, function(e)
        {
          cleanElementsWithDragInProgress();
        }]);
    }

    _addSpecialBubbleEventListener(
      domNode,
      "amxdrag",
      payload,
      eventData,
      backingListeners);
  };

  function cleanElementsWithDragInProgress()
  {
    // Since we are not guaranteed to get an "end" for a "start" (e.g. the drag ended
    // on a different element than the start element) then we need to find all drag
    // elements and remove their "in-progress" markers:
    var elementsWithDragInProgress = document.querySelectorAll("*[data-amxDragInProgress]");

    for (var i = 0, count = elementsWithDragInProgress.length; i < count; ++i)
      elementsWithDragInProgress[i].removeAttribute("data-amxDragInProgress");

    // Ensure the drag is concluded:
    cancelPendingDrag(true, true);
  }

  /**
   * Apply innerHTML upon on element (this will call adf.mf.api.amx.emptyHtmlElement for
   * you).
   * @param {HTMLElement} parentElement the parent HTML element whose innerHTML is to be applied
   * @param {string} innerHtml the HTML to apply in the parentElement
   * @param {boolean} scriptEval whether script tags should be evaluated
   */
  adf.mf.api.amx.applyInnerHtml = function(parentElement, innerHtml, scriptEval)
  {
    adf.mf.api.amx.emptyHtmlElement(parentElement);
    parentElement.innerHTML = innerHtml;
    if (scriptEval)
    {
      // Loop through all script nodes in the parent (might be more than just innerHTML's):
      var scriptNodes = parentElement.querySelectorAll("script");
      for (var i = 0; i < scriptNodes.length; i++)
      {
        // Clone the node (if not previously-cloned)
        var scriptNode = scriptNodes[i];
        var scriptClone = cloneScriptNode(scriptNode);
        if (scriptClone)
          scriptNode.parentNode.replaceChild(scriptClone, scriptNode);
      }
    }
  };

  function cloneScriptNode(oldNode)
  {
    if (oldNode == null)
      return oldNode;
    var newNode = document.createElement("script");
    var cloneIdentifier = "data-amx-script-clone";
    newNode.setAttribute(cloneIdentifier, "yes"); // marker to prevent re-cloning
    newNode.text = oldNode.innerHTML;
    var attrs = oldNode.attributes;
    for (var i = attrs.length-1; i >= 0; i--)
    {
      var attr = oldNode.attributes[i];
      var attrName = attr.name;
      if (attrName == cloneIdentifier)
        return null; // found a script node that was previously-cloned
      newNode.setAttribute(attrName, attr.value);
    }
    return newNode;
  }

  /**
   * Remove a DOM node (and its children) but first removes event listeners
   * that were added via adf.mf.api.amx.addBubbleEventListener and ensures any
   * components inside it get cleaned up properly.
   * @param {DOMNode} domNode the DOM node to remove
   */
  adf.mf.api.amx.removeDomNode = function(domNode)
  {
    var i;

    // We need to proceed depth-first:
    if (domNode != null)
    {
      // Cancel pending drags if applicable
      // We need to cancel pending drags because they may have been abandoned
      // due to element removal during their "dragdrag" handlers.
      // This is needed for bug 18775524 but means we can't have a navigationDragBehavior.
      if (domNode.getAttribute && "yes" == domNode.getAttribute("data-amxDragInProgress"))
      {
        cancelPendingDrag(true, true);
      }

      // First we need to clean up any associated AMXNodes before the DOM is
      // removed or else the destroy handlers might lose important context.
      adf.mf.internal.amx.removeAmxDomNode(domNode);

      // Going depth-first, clean up the children:
      var children = domNode.childNodes;
      if (children != null)
      {
        for (i = children.length - 1; i >= 0; --i)
        {
          adf.mf.api.amx.removeDomNode(children[i]);
        }
      }

      // Unregister the event listeners:
      adf.mf.api.amx.removeBubbleEventListener(domNode);

      // In some cases an element delegates event listeners to the document like
      // amx:view for some document events. We need to make sure those get
      // unregistered too or else there would be a leak:
      if (domNode.__amxRemoveFunctions != null)
      {
        var removeFunctionCount = domNode.__amxRemoveFunctions.length;
        for (i = removeFunctionCount - 1; i >= 0; --i)
        {
          var removeFunc = domNode.__amxRemoveFunctions[i];
          try
          {
            removeFunc();
          }
          catch (problem)
          {
            adf.mf.log.logInfoResource(
              "AMXInfoBundle",
              adf.mf.log.level.SEVERE,
              "adf.mf.api.amx.removeDomNode",
              "MSG_ERROR_REMOVE_DOM_NODE_SCRIPT");

            // Only log the details at a fine level for security reasons
            if (adf.mf.log.Framework.isLoggable(adf.mf.log.level.FINE))
            {
              adf.mf.log.Framework.logp(adf.mf.log.level.FINE,
                "adf.mf.api.amx", "removeDomNode",
                "Error in function: " + removeFunc + " error: " + problem);
            }
          }
        }
        domNode.__amxRemoveFunctions = null;
      }

      // Remove the node:
      if (domNode.parentNode != null)
        domNode.parentNode.removeChild(domNode);
    }
  };

  /**
   * Empty an HTML element by removing children DOM nodes and calling adf.mf.api.amx.removeDomNode on each
   * of the children nodes.
   * @param {HTMLElement} element the HTML element to empty
   */
  adf.mf.api.amx.emptyHtmlElement = function(element)
  {
    // HTMLElement element
    if (element != null)
    {
      var children = element.childNodes;
      if (children != null)
      {
        for (var i=children.length-1; i>=0; --i)
          adf.mf.api.amx.removeDomNode(children[i]);
      }
    }
  };

  /**
   * Enable scrolling for the given element.
   * This operation may append a style class to the element so ensure that you
   * do not overwrite the element class name after calling this API.
   */
  adf.mf.api.amx.enableScrolling = function(element)
  {
    // Disable old scrolling strategies and enable new
    adf.mf.api.amx.disableScrolling(element);

    var scrollPolicyClassName = "amx-scrollable";

    // In legacy skins, scrolling is much more aggressive so we have a different class name:
    var args = Array.prototype.slice.call(arguments);
    if (args.length == 2)
    {
      if (args[1] === true) // 2nd magic argument is whether you need legacy scrolling support
        scrollPolicyClassName = "amx-scrollPolicy-auto";
    }

    // Apply the class name:
    element.classList.add(scrollPolicyClassName);
  };

  /**
   * Disable scrolling for the given element.
   * This operation removes the style classes added to the element
   * by adf.mf.api.amx.enableScrolling function.
   */
  adf.mf.api.amx.disableScrolling = function(element)
  {
    // remove class names
    element.classList.remove("amx-scrollable", "amx-scrollPolicy-auto");
  };

  function _shorten(object, limit)
  {
    var result;

    if (object == null)
    {
      result = object;
    }
    else
    {
      var string = "" + object;

      if (string.length > limit)
        result = string.substring(0, limit-3).trim() + "...";
      else
        result = string;

      result = result.replace(/\n/g, " ").trim();
      result = result.replace(/[\s]+/g, " "); // collapse all spaces
    }

    return result;
  }

  /**
   * Generate a debugging string for events associated with a given HTML element.
   * @param {HTMLElement} element the HTML element whose event detail will be generated
   * @param {Number} shortenLimit optional number that can change the limit to the length of debug listener or data text
   * @return {String} a debugging string representing details about events associated with the given HTML element
   */
  adf.mf.api.amx.getEventDebugString = function(element, shortenLimit)
  {
    if (element == null)
      return element;

    if (shortenLimit === undefined)
      shortenLimit = 25;

    var domEventsMessage = "\n  n/a";
    var domListeners = element._amxListeners;
    if (domListeners != null)
    {
      var domListeners = element._amxListeners;
      var domListenerCount = domListeners.length;
      domEventsMessage = "";
      for (var i=0; i<domListenerCount; ++i)
      {
        var domListener = domListeners[i];
        var firstPrefix = "  " + (1+i) + " - ";
        var otherPrefix = Array(1+firstPrefix.length).join(" "); // empty spaces of equal length
        domEventsMessage += "\n" + firstPrefix + "type: " + domListener["eventType"];
        domEventsMessage += "\n" + otherPrefix + "listener: " + _shorten(domListener["listener"], shortenLimit);
        domEventsMessage += "\n" + otherPrefix + "data: " + _shorten(domListener["eventData"], shortenLimit);
      }
    }

    var specialEventsMessage = "\n  n/a";
    var specialEventsMap = element._amxSpecialEvents;
    if (specialEventsMap != null)
    {
      specialEventsMessage = "";
      var eventTypeCounter = 0;
      for (var eventType in specialEventsMap)
      {
        // Since there can be multiple instances of each special event type, each type points to an event key map.
        // The eventKeysMap is keyed by something that allows unique removal.
        // This key could be the developer's passed-in listener function (in the case of "tap" and "taphold") or
        // the developer's payload object (in the case of "amxdrag").
        var eventKeysMap = specialEventsMap[eventType];
        specialEventsMessage += "\n  " + ++eventTypeCounter + " - type: " + eventType;
        var eventKeyCounter = 0;
        for (var eventKey in eventKeysMap)
        {
          // Each entry in eventKeysMap is a eventDataMap.
          var eventDataMap = eventKeysMap[eventKey];
          specialEventsMessage += "\n    " + eventTypeCounter + "." + ++eventKeyCounter + " - key: " + _shorten(eventKey, shortenLimit);
          var eventDataCounter = 0;
          for (var eventData in eventDataMap)
          {
            // Each entry in eventDataMap is an array of instance listeners.
            var instanceListenersArray = eventDataMap[eventData];
            var instanceListenerCount = instanceListenersArray.length;
            specialEventsMessage += "\n      " + eventTypeCounter + "." + eventKeyCounter + "." + ++eventDataCounter + " - data: " + _shorten(eventData, shortenLimit);
            for (var i=0; i<instanceListenerCount; ++i)
            {
              // Each member of instanceListenersArray is a backing listener array where index 0 is an
              // DOM event type and index 1 is a DOM event handler function.
              specialEventsMessage += "\n        " + eventTypeCounter + "." + eventKeyCounter + "." + eventDataCounter + "." + (1+i) + " - DOM type: " + instanceListenersArray[i][0];
            }
          }
        }
      }
    }

    var message =
      "DOM events: " + domEventsMessage +
      "\nSpecial events:" + specialEventsMessage;
    return message;
  };

  //NOTE: The body of this function was removed to allow use of native scrolling in iOS 5.0 by
  // the use of the CSS "-webkit-overflow-scrolling: touch" on the amx-scrollable class, but the
  // binding itself remains because removing it causes AMX-processed touch events to fail
  // altogether.
  //TODO : Do we still need this (was in a jQuery load of amx-core)?
  adf.mf.api.amx.addBubbleEventListener(document.body, "touchmove", function(event) {});

  adf.mf.api.finishAnyLoading().then(
    function()
    {
      // Android workaround for form elements not appearing within visible part of the display
      // when a keyboard is shown (they would otherwise be covered up by the keyboard).
      if (adf.mf.internal.amx.agent["type"] == "Android")
      {
        var lastShowKeyboardTime = 0;
        var lastResizeTime = 0;
        var timeOutRunning = false;

        var scrollActiveElementIntoView = function()
        {
          timeOutRunning = false;

          var ae = document.activeElement;

          // Ignore the document body (when the active element has not been set).
          if (ae != document.body)
          {
            // Not every browser implements scrollIntoViewIfNeeded. The mobile browsers mostly
            // implement it, but check first before falling back on scrollIntoView.
            ae["scrollIntoViewIfNeeded"] ? ae.scrollIntoViewIfNeeded() : ae.scrollIntoView();
          }
        };

        var scrollActiveElementIntoViewIfAppropriate = function(newerTime, olderTime)
        {
          // Determine how long between the most recent showkeyboard and resize events.
          var timeDiff = newerTime - olderTime;

          // Is this resize due to the keyboard (close in time to the event)?
          if (timeDiff <= 750 && !timeOutRunning)
          {
            timeOutRunning = true;

            // Use a timeout to allow the browser time to redraw before trying to bring the
            // element into view.
            window.setTimeout(scrollActiveElementIntoView, 150);
          }
        };

        // Note: showkeyboard is only called on Android and it is called several times per one
        // showing of the keyboard for some unknown reason.
        document.addEventListener("showkeyboard",
          function(event)
          {
            // Record when the event was generated
            lastShowKeyboardTime = (new Date()).getTime();

            scrollActiveElementIntoViewIfAppropriate(lastShowKeyboardTime, lastResizeTime);
          });

        // The android:windowSoftInputMode is set to adjustResize, so the window will resize
        // to fit to the space left without the keyboard. Listen for this event so that we can
        // catch the resize event that happens after the showkeyboard event.
        window.addEventListener("resize",
          function(event)
          {
            // Record when the event was generated
            lastResizeTime = (new Date()).getTime();

            scrollActiveElementIntoViewIfAppropriate(lastResizeTime, lastShowKeyboardTime);
          });
      }
    });

  function _getClosestWithClass(domNode, classNameToMatch)
  {
    // Find the closest ancestor (including self that uses the given class name)
    if (domNode == null || (domNode.classList && domNode.classList.contains(classNameToMatch)))
    {
      return domNode;
    }
    else
    {
      return _getClosestWithClass(domNode.parentNode, classNameToMatch);
    }
  }

  /**
   * An event triggering an outcome-based navigation.
   * See also the Java API oracle.adfmf.amx.event.ActionEvent.
   * @constructor
   */
  adf.mf.api.amx.ActionEvent = function()
  {
    this[".type"] = "oracle.adfmf.amx.event.ActionEvent";
  };
  amx.ActionEvent = adf.mf.api.amx.ActionEvent; // deprecated syntax

  /**
   * A DOM event.
   * @param {string} amxNodeId the component ID
   * @param {Object} eventType the type of event
   * @param {Event} originalEvent the original DOM event object
   * @constructor
   */
  adf.mf.api.amx.DomEvent = function(amxNodeId, eventType, originalEvent)
  {
    this[".type"] = "oracle.adfmf.amx.event.DomEvent";
    this.amxNodeId = amxNodeId;
    this.eventType = eventType;
    this.source = originalEvent.target;
    this.currentTarget = originalEvent.currentTarget;
    this.originalEvent = originalEvent;
  };

  /**
   * An event for notifying that a specified row has been moved.
   * It contains the key for the row that was moved along with the key for the row it was inserted before.
   * See also the Java API oracle.adfmf.amx.event.MoveEvent.
   * @param {Object} rowKeyMoved the rowKey that was moved
   * @param {Object} rowKeyInsertedBefore the rowKey that the moved row was inserted before
   * @constructor
   */
  adf.mf.api.amx.MoveEvent = function(rowKeyMoved, rowKeyInsertedBefore)
  {
    this[".type"] = "oracle.adfmf.amx.event.MoveEvent";
    this.rowKeyMoved = rowKeyMoved;
    this.rowKeyInsertedBefore = rowKeyInsertedBefore;
  };
  adf.mf.internal.amx.MoveEvent = adf.mf.api.amx.MoveEvent; // deprecated syntax

  /**
   * An event for changes of selection for a component.
   * See also the Java API oracle.adfmf.amx.event.SelectionEvent.
   * @param {Object} oldRowKey the rowKey that has just been unselected
   * @param {Array<Object>} selectedRowKeys the array of rowKeys that have just been selected.
   * @constructor
   */
  adf.mf.api.amx.SelectionEvent = function(oldRowKey, selectedRowKeys)
  {
    this.oldRowKey = oldRowKey;
    this.selectedRowKeys = selectedRowKeys;
    this[".type"] = "oracle.adfmf.amx.event.SelectionEvent";
  };
  amx.SelectionEvent = adf.mf.api.amx.SelectionEvent; // deprecated syntax

  /**
   * An event for changes of value for a component.
   * See also the Java API oracle.adfmf.amx.event.ValueChangeEvent.
   * @param {Object} oldValue the previous value of the component.
   * @param {Object} newValue the new value of the component.
   * @constructor
   */
  adf.mf.api.amx.ValueChangeEvent = function(oldValue, newValue)
  {
    this.oldValue = oldValue;
    this.newValue = newValue;
    this[".type"] = "oracle.adfmf.amx.event.ValueChangeEvent";
  };
  amx.ValueChangeEvent = adf.mf.api.amx.ValueChangeEvent; // deprecated syntax

  /**
   * An event for range changes for a component (e.g. load more rows in listView).
   * See also the Java API oracle.adfmf.amx.event.RangeChangeEvent.
   * @param {string} eventSourceId the source ID of the event
   * @param {string} contextFreeValue the context-free value expression or null if not available
   * @param {Object} lastLoadedRowKey the row key of the last row loaded before the requested range or null if not available
   * @param {number} fetchSize the size to fetch or null if not available
   * @constructor
   */
  adf.mf.api.amx.RangeChangeEvent = function(
    eventSourceId,
    contextFreeValue,
    lastLoadedRowKey,
    fetchSize)
  {
    this.eventSourceId = eventSourceId;
    this.contextFreeValue = contextFreeValue;
    this.lastLoadedRowKey = lastLoadedRowKey;
    this.fetchSize = fetchSize;
    this[".type"] = "oracle.adfmf.amx.event.RangeChangeEvent";
    // Consider using: this[".type"] = "oracle.adfmf.framework.event.RangeChangeEvent";
  };

  /**
   * Process an AMX Event. Change the value if attributeValueName is defined, process the appropriate
   * setPropertyListener and actionListener sub tags and then process the [amxEventType]Listener attribute.
   * @param {adf.mf.api.amx.AmxNode} amxNode The node to process the event on.
   * @param {string} amxEventType String that represents the event type that triggered the call.
   * @param {string} attributeValueName The name of the attribute whose value will be changed (or undefined if not applicable).
   * @param {string} newValue The new value to be applied to the attribute sent in (or undefined if not applicable).
   * @param {Object} amxEvent The new AmxEvent being queued.
   * @param {Object} finishedCallback The optional function to invoke once the event has been processed.
   * @deprecated
   */
  amx.processAmxEvent = function(
    amxNode,
    amxEventType,
    attributeValueName,
    newValue,
    amxEvent,
    finishedCallback)
  {
    adf.mf.log.logInfoResource("AMXInfoBundle", adf.mf.log.level.WARNING, "processAmxEvent",
      "MSG_DEPRECATED", "amx.processAmxEvent", "amxNode.processAmxEvent");
    return adf.mf.api.amx.processAmxEvent(amxNode, amxEventType,
      attributeValueName, newValue, amxEvent, finishedCallback);
  };

  //adf.mf.internal.amx._useBatchProcessing = false;

  /**
   * Process an AMX Event. Change the value if attributeValueName is defined, process the
   * appropriate setPropertyListener and actionListener sub tags and then process the
   * [amxEventType]Listener attribute. For valueChange events, the attribute must have already
   * been registered on the node as the input value. Use getInputValueAttribute on the type handler
   * of the AMX node to return the attribute name that accepts the input value for which value
   * changes occur.
   *
   * @param {adf.mf.api.amx.AmxNode} amxNode The node to process the event on.
   * @param {string} amxEventType String that represents the event type that triggered the call.
   * @param {(string|undefined)} attributeValueName The name of the attribute whose value will be
   *        changed (or undefined if not applicable).
   * @param {(string|undefined)} newValue The new value to be applied to the attribute sent in
   *        (or undefined if not applicable).
   * @param {Object} amxEvent The new AmxEvent being queued.
   * @param {function=} successfulCallback An optional function to invoke once the event has been
   *        successfully processed.
   * @param {function=} failureCallback Optional callback function if the processing of the event
   *        fails
   */
  adf.mf.api.amx.processAmxEvent = function(
    amxNode,
    amxEventType,
    attributeValueName,
    newValue,
    amxEvent,
    successfulCallback,
    failureCallback)
  {
    // Show the loading indicator as this could take some time to process.
    adf.mf.api.amx.showLoadingIndicator();

    // Need a wrapper promise incase we are in design time and we will resolve this either in the else
    // or end of phase 4.
    var promise = new adf.mf.internal.BasePromise(
      function(resolve, reject)
      {
        var currPage = amx.getCurrentPageName();
        var nodeId = amxNode.getId();

        adf.mf.internal.amx._pageBusyTracker.startOperation(
          true,
          "Process AMX event",
          adf.mf.log.level.INFO,
          "Time to process event",
          "Page: " + currPage + " event of type " + amxEventType + " on node " + nodeId);

        // No adf.mf.internal.amx._pageBusyTracker.checkComplete will be called from this method. This
        // allows any subsequent data change events to be tracked and included in the current operation

        if (adf.mf.api.amx.getPageRootNode() == null)
        {
          // Do not process any events after the page has been unloaded.
          // This may happen if an event kicks off a navigation and other events are still being
          // delivered.
          reject();
        }
        else
        {
          var processor = new AmxEventProcessor(
            amxNode,
            amxEventType,
            attributeValueName,
            newValue,
            amxEvent,
            {
              "resolve": resolve,
              "reject": reject
            });

          adf.mf.internal.amx._queueCriticalSectionFunction(
            processor.run,
            processor,
            true);
        }
      });

    if (successfulCallback != null)
    {
      promise.then(successfulCallback);
    }

    if (failureCallback != null)
    {
      promise["catch"](failureCallback);
    }

    // Hide the loading indicator once the event is fully done and the callbacks have been fired
    promise.then(adf.mf.api.amx.hideLoadingIndicator, adf.mf.api.amx.hideLoadingIndicator);

    return promise;
  };

  /**
   * @namespace
   */
  adf.mf.internal.amx.AmxEventHandlingMode =
  {
    /** Tag instances and EL evaluation needs to happen serially */
    "SERIAL": 0,
    /** Event is processed inside of a batch request */
    "BATCH": 1,
    /** The embedded side is being used to handle the event */
    "EMBEDDED": 2,

    /**
     * Method that may be used for debugging (should not be used for normal usage) to get
     * the state label for a state value
     *
     * @param {int} state one of the node state values
     * @return {string|null} the label or null if not a valid value
     */
    getLabelForValue: function(state)
    {
      for (var label in adf.mf.internal.amx.AmxEventHandlingMode)
      {
        if (adf.mf.internal.amx.AmxEventHandlingMode[label] == state)
        {
          return label;
        }
      }

      return null;
    }
  };

  // --------- AmxEventProcessor --------- //
  /**
   * Class to invoke all the necessary steps of processing an AMX event, handling the correct
   * context requirements and batch requirements. Maintains the state during the subsequent
   * steps of processing the event.
   */
  function AmxEventProcessor(
    amxNode,
    amxEventType,
    attributeValueName,
    newValue,
    amxEvent,
    promiseArgs)
  {
    // Check if the deprecated API is in use (passing the AMX node as a jQuery object with the
    // root DOM element)
    if (amxNode != null && amxNode.jquery)
    {
      adf.mf.log.logInfoResource("AMXInfoBundle", adf.mf.log.level.WARNING,
        "processAmxEvent", "MSG_AMX_EVENT_JQUERY_DEPRECATED");
      amxNode = amxNode.data("amxNode");
    }

    this._amxNode = amxNode;
    this._amxEventType = amxEventType;
    this._attributeValueName = attributeValueName;
    this._value = newValue;
    this._amxEvent = amxEvent;
    this._promiseArgs = promiseArgs;
    this._inContext = false;
    this._failed = false;
    this._inBatch = false;
    this._validationGroup = null;
    this._resolveInvoked = false;
    this._queue = [];

    if (adf.mf.environment.profile.mockData)
    {
      this._method = adf.mf.internal.amx.AmxEventHandlingMode["SERIAL"];
    }
    else if (adf.mf.internal.amx._embeddedSideHandlingEnabled)
    {
      this._method = adf.mf.internal.amx.AmxEventHandlingMode["EMBEDDED"];
    }
    else
    {
      this._method = adf.mf.internal.amx.AmxEventHandlingMode["BATCH"];
    }
  }

  /**
   * Return the value of the method being used to handle the event
   *
   * @return {number} one of the adf.mf.internal.amx.AmxEventHandlingMode constants
   */
  AmxEventProcessor.prototype.getMethod = function()
  {
    return this._method;
  };

  /**
   * Checks if each steps must be run serially
   *
   * @return {boolean} if steps need to run serially
   */
  AmxEventProcessor.prototype.isSerial = function()
  {
    return this._method === adf.mf.internal.amx.AmxEventHandlingMode["SERIAL"];
  };

  /**
   * Checks if the steps should run inside of an EL batch operation asynchronously
   *
   * @return {boolean} if steps need to run in a batch
   */
  AmxEventProcessor.prototype.isBatch = function()
  {
    return this._method === adf.mf.internal.amx.AmxEventHandlingMode["BATCH"];
  };

  /**
   * Checks if the embedded Dispatch class is handling the event
   *
   * @return {boolean} if the embedded side is handling the event
   */
  AmxEventProcessor.prototype.isDispatch = function()
  {
    return this._method === adf.mf.internal.amx.AmxEventHandlingMode["EMBEDDED"];
  };

  /**
   * Get the AMX node
   *
   * @return {adf.mf.api.amx.AmxNode} the AMX target node for the event
   */
  AmxEventProcessor.prototype.getAmxNode = function()
  {
    return this._amxNode;
  };

  /**
   * Get the event type being fired
   *
   * @return {string} the type of the event
   */
  AmxEventProcessor.prototype.getEventType = function()
  {
    return this._amxEventType;
  };

  /**
   * Get the attribute
   *
   * @return {string|null} the attribute if the event should set an attribute value
   */
  AmxEventProcessor.prototype.getAttributeName = function()
  {
    return this._attributeValueName;
  };

  /**
   * Get the value to set
   *
   * @return the value to set for the attribute
   */
  AmxEventProcessor.prototype.getValue = function()
  {
    return this._value;
  };

  /**
   * Set the value. Used after conversion
   *
   * @param {Object} value the new value
   */
  AmxEventProcessor.prototype.setValue = function(value)
  {
    this._value = value;
  };

  /**
   * Get the AMX event
   *
   * @return {Object} the AMX event object
   */
  AmxEventProcessor.prototype.getEvent = function()
  {
    return this._amxEvent;
  };

  /**
   * Get the validation group
   *
   * @return {Node|null} the validation group or null if there is none
   */
  AmxEventProcessor.prototype.getValidationGroup = function()
  {
    return this._validationGroup;
  };

  /**
   * Sets the validation group
   *
   * @param {Node} validationGroup the validation group node
   */
  AmxEventProcessor.prototype.setValidationGroup = function(validationGroup)
  {
    this._validationGroup = validationGroup;
  };

  /**
   * Method to allow a step to add additional steps to be executed immediately after itself
   *
   * @param {AmxEventProcessorStep} step the step to insert
   */
  AmxEventProcessor.prototype.insertStep = function(step)
  {
    this._queue.unshift(step);
  };

  /**
   * Callback from the HandleFlushBatchRequestStep step to notify the processor the batch has
   * been completed
   */
  AmxEventProcessor.prototype.batchCompleted = function()
  {
    this._inBatch = false;
  };

  /**
   * Execute the queue
   *
   * @return {adf.mf.internal.BasePromise} promise object
   */
  AmxEventProcessor.prototype.run = function()
  {
    if (adf.mf.environment.profile.dtMode)
    {
      return adf.mf.internal.BasePromise.resolve();
    }

    this._rootNode = adf.mf.api.amx.getPageRootNode();

    if (this._rootNode == null)
    {
      return adf.mf.internal.BasePromise.reject();
    }

    this._perf = adf.mf.internal.perf.startMonitorCall("Process AMX batch",
      adf.mf.log.level.FINER, "adf.mf.internal.amx.processAmxEventImplBatch");
    adf.mf.internal.pushNonBlockingCall();

    if (this.isBatch())
    {
      // Start the batch request. This is to prevent us from doing all the set property and
      // action event one at a time and instead process all all the children at once we
      // queue up all the EL that needs to be proccessed in order. Once
      // completed the flush will process all the EL in one round trip.
      adf.mf.util.startBatchRequest();
      this._inBatch = true;
    }

    // See if there is to be validation and if an attribute needs to be set
    if (this._attributeValueName != null)
    {
      this._queue.push(new GetValidationGroupStep(this));

      // The embedded side handles the setting of the attribute, so do not do that here for embedded dispatching
      if (!this.isDispatch())
      {
        this._queue.push(new SetAttributeStep(this));
      }
    }

    // Queue the handling of any tag instances before the embedded call
    this._queue.push(new HandleTagInstancesStep(this, true));

    if (this.isDispatch())
    {
      // Queue the handling of the event itself which also handles the invocation of any listeners
      this._queue.push(new HandleDispatchStep(this));
    }
    else if (this._amxEvent)
    {
      // Process any event listeners on the tag
      this._queue.push(new HandleEventListenersStep(this));

      if (this.isBatch())
      {
        // Queue the handling of the flushBatchRequest
        this._queue.push(new HandleFlushBatchRequestStep(this));
      }
    }
    else if (this.isBatch())
    {
      // Queue the handling of the flushBatchRequest
      this._queue.push(new HandleFlushBatchRequestStep(this));
    }

    // Queue the handling of any tag instances after the embedded call
    this._queue.push(new HandleTagInstancesStep(this, false));

    // Queue the handling of the validation
    this._queue.push(new HandleValidationStep(this));

    var processor = this;

    this._resolveCallback = adf.mf.internal.getProxyFunction(this, this._resolve);
    this._rejectCallback = adf.mf.internal.getProxyFunction(this, this._reject);

    return new adf.mf.internal.BasePromise(
      function (resolve, reject)
      {
        processor._outerResolve = resolve;
        processor._outerReject = reject;
        processor._processQueue();
      });
  };

  /**
   * Method called when a step completes successfully
   */
  AmxEventProcessor.prototype._resolve = function()
  {
    var processor = this;

    this._resolveInvoked = true;

    // If the processor is still in context, the _processQueue method will try to keep processing
    // the steps synchronously. Therefore, allow the _processQueue to keep executing.
    if (!this._inContext)
    {
      // The step either did not execute in context or it was asynchronous. As a result, we need to re-run the queue.
      // Use a promise here to ensure that the queue is processed after the current
      // step has returned. If we were to call _processQueue directly, the method would begin
      // execution before this resolve function returns to the step
      adf.mf.internal.BasePromise.resolve().then(function() { processor._processQueue(); });
    }
  };

  /**
   * Method called when a step fails
   */
  AmxEventProcessor.prototype._reject = function()
  {
    var processor = this;

    this._failed = true;

    function callback()
    {
      processor._perf.stop();
      processor._promiseArgs["reject"]();
      processor._outerReject();
      adf.mf.internal.popNonBlockingCall();
    }

    if (this._inBatch)
    {
      // Don't leave the batch request open
      adf.mf.util.flushBatchRequest(false, [ callback ], [ callback ]);
    }
    else
    {
      callback();
    }
  };

  /**
   * Process the queue and invoke the steps
   */
  AmxEventProcessor.prototype._processQueue = function()
  {
    if (!this._failed && this._queue.length)
    {
      var step = this._queue.shift();

      // Check if the step needs to be in context. If so, perform a visit
      if (step.requiresContext())
      {
        var processor = this;
        var nodeFound = this._rootNode.visit(
          new adf.mf.api.amx.VisitContext({ "amxNodes": [ this._amxNode ] }),
          function (visitContext, amxNode)
          {
            // Try to run synchronously when possible. Use these variables to track the state
            processor._inContext = true;

            try
            {
              while (true)
              {
                // Try to invoke synchronously to avoid repetetive visits to put the node back in context
                processor._resolveInvoked = false;

                step.run(processor._resolveCallback, processor._rejectCallback);

                if (!processor._resolveInvoked)
                {
                  // The resolve method hasn't been executed, therefore the step is asynchronous. Wait for the callback
                  break;
                }
                else if (processor._queue.length)
                {
                  // The resolve method was invoked and there are more steps. Keep running them while still in context
                  step = processor._queue.shift();
                }
                else
                {
                  // No more steps, break out of the loop
                  break;
                }
              }

              processor._inContext = false;
            }
            catch (e)
            {
              processor._inContext = false;
              processor._reject();
            }
          });

        if (!nodeFound)
        {
          this._reject();
        }
      }
      else
      {
        // The step does not have to be in context
        step.run(this._resolveCallback, this._rejectCallback);
      }
    }

    if (!this._failed && this._queue.length == 0)
    {
      this._perf.stop();

      // The queue is empty and there were no failures, resolve the outer promise
      this._promiseArgs["resolve"]();
      this._outerResolve();
      adf.mf.internal.popNonBlockingCall();
    }
  };
  // --------- /AmxEventProcessor --------- //

  // --------- AmxEventProcessorStep --------- //
  /**
   * Base class for any step to be executed as part of processing an AMX event. Provides the
   * necessary APIs to the AmxEventProcessor on how to execute the step and executes the logic
   *
   * @param {AmxEventProcessor} amxEventProcessor the event processor
   */
  function AmxEventProcessorStep(
    amxEventProcessor)
  {
    this.Init(amxEventProcessor);
  }

  adf.mf.api.AdfObject.createSubclass(AmxEventProcessorStep, adf.mf.api.AdfObject, "AmxEventProcessorStep");

  AmxEventProcessorStep.prototype.Init = function(amxEventProcessor)
  {
    this._amxEventProcessor = amxEventProcessor;
  };

  AmxEventProcessorStep.prototype.requiresContext = function()
  {
    return false;
  };

  AmxEventProcessorStep.prototype.run = function(resolve, reject)
  {
    // To be overridden by the subclasses
  };

  AmxEventProcessorStep.prototype.GetProcessor = function()
  {
    return this._amxEventProcessor;
  };
  // --------- /AmxEventProcessorStep --------- //

  // --------- GetValidationGroupStep --------- //
  /**
   * Step that handles the retrieval of the validation group DOM node
   */
  function GetValidationGroupStep(amxEventProcessor)
  {
    this.Init(amxEventProcessor);
  }

  adf.mf.api.AdfObject.createSubclass(GetValidationGroupStep, AmxEventProcessorStep, "GetValidationGroupStep");

  GetValidationGroupStep.prototype.run = function(resolve, reject)
  {
    var processor = this.GetProcessor();
    var amxNode = processor.getAmxNode();

    // detect if we might need to refresh the validation message area
    if (processor.getEventType() === "valueChange" &&
      processor.getAttributeName() === amxNode.__getAttributeToValidate())
    {
      // First find the closest rendered node for validation group purposes
      var renderedAmxNode = amxNode.__getClosestRenderedNode();

      if (renderedAmxNode != null)
      {
        var domNode = document.getElementById(renderedAmxNode.getId());

        if (domNode != null)
        {
          processor.setValidationGroup(_getClosestWithClass(domNode, "amx-validationGroup"));
        }
      }
    }

    resolve();
  };
  // --------- /GetValidationGroupStep --------- //

  // --------- SetAttributeStep --------- //
  /**
   * Step that handles the conversion of the value as well as the setting of the attribute via EL
   */
  function SetAttributeStep(amxEventProcessor)
  {
    this.Init(amxEventProcessor);
  }

  adf.mf.api.AdfObject.createSubclass(SetAttributeStep, AmxEventProcessorStep, "SetAttributeStep");

  SetAttributeStep.prototype.requiresContext = function()
  {
    return true;
  };

  SetAttributeStep.prototype.run = function(resolve, reject)
  {
    var processor = this.GetProcessor();
    var attributeName = processor.getAttributeName();

    var amxNode = processor.getAmxNode();
    var value = processor.getValue();

    if (processor.getEventType() === "valueChange")
    {
      var converter = amxNode.getConverter();
      var convertableAttribute = amxNode.__getConvertableAttribute();

      if (converter && processor.getAttributeName() === convertableAttribute)
      {
        var rawValue = value;

        value = converter.getAsObject(value);

        if (value === "" && rawValue !== "")
        {
          // There was a conversion error, do not process the event
          reject();
          return;
        }
      }
    }

    var promise = null;

    if (processor.isDispatch())
    {
      // The Dispatch.processAmxEvent will handle the setting of the attribute value in the embedded code
      processor.setValue(value);
    }
    else
    {
      var setAttributePromise = amxNode.setAttribute(attributeName, value);

      if (processor.isSerial())
      {
        promise = setAttributePromise;
      }
    }

    if (promise != null)
    {
      promise.then(
        resolve,
        function()
        {
          // Bug 16371894: setValuePromise failed so we abort further processing
          adf.mf.log.logInfoResource("AMXInfoBundle", adf.mf.log.level.SEVERE,
            "adf.mf.api.amx.processAmxEvent",
            "MSG_PROCESS_AMX_EVENT_SET_VALUE_REJECTED");

          // For security purposes, only log at FINE level
          if (adf.mf.log.Framework.isLoggable(adf.mf.log.level.FINE))
          {
            adf.mf.log.Framework.logp(adf.mf.log.level.FINE,
              "adf.mf.api.amx", "processAmxEvent",
              "Value rejected: " + value);
          }
        });
    }
    else
    {
      resolve();
    }
  };
  // --------- /SetAttributeStep --------- //

  // --------- HandleTagInstancesStep --------- //
  /**
   * Step that determines which tag instances need to be invoked for this event and queues
   * additional steps for each one found
   */
  function HandleTagInstancesStep(amxEventProcessor, beforeEmbeddedCall)
  {
    this.Init(amxEventProcessor, beforeEmbeddedCall);
  }

  adf.mf.api.AdfObject.createSubclass(HandleTagInstancesStep, AmxEventProcessorStep, "HandleTagInstancesStep");

  HandleTagInstancesStep.prototype.Init = function(amxEventProcessor, beforeEmbeddedCall)
  {
    HandleTagInstancesStep.superclass.Init.call(this, amxEventProcessor);

    this._beforeEmbeddedCall = beforeEmbeddedCall;
  };

  HandleTagInstancesStep.prototype.requiresContext = function()
  {
    return true;
  };

  HandleTagInstancesStep.prototype.IsBeforeEmbeddedCall = function()
  {
    return this._beforeEmbeddedCall;
  };

  HandleTagInstancesStep.prototype.run = function(resolve, reject)
  {
    var processor = this.GetProcessor();
    var amxNode = processor.getAmxNode();
    var tagInstances = amxNode.__getAllTagInstances();
    var eventType = processor.getEventType();

    for (var i = tagInstances.length - 1; i >= 0; i--)
    {
      var tagInstance = tagInstances[i];

      if (tagInstance.handlesEventType(tagInstance, eventType))
      {
        processor.insertStep(new HandleTagInstanceStep(processor, tagInstance, this._beforeEmbeddedCall));
      }
    }

    resolve();
  };
  // --------- /HandleTagInstancesStep --------- //

  // --------- HandleTagInstanceStep --------- //
  /**
   * Step that handles the invocation of the tag handler via the tag instance for the event
   */
  function HandleTagInstanceStep(amxEventProcessor, tagInstance, beforeEmbeddedCall)
  {
    this.Init(amxEventProcessor, tagInstance, beforeEmbeddedCall);
  }

  adf.mf.api.AdfObject.createSubclass(HandleTagInstanceStep, AmxEventProcessorStep, "HandleTagInstanceStep");

  HandleTagInstanceStep.prototype.Init = function(amxEventProcessor, tagInstance, beforeEmbeddedCall)
  {
    HandleTagInstanceStep.superclass.Init.call(this, amxEventProcessor);

    this._tagInstance = tagInstance;
    this._beforeEmbeddedCall = beforeEmbeddedCall;
  };

  HandleTagInstanceStep.prototype.requiresContext = function()
  {
    return true;
  };

  HandleTagInstanceStep.prototype.run = function(resolve, reject)
  {
    var processor = this.GetProcessor();

    var result = this._tagInstance.handleAmxEvent(
      processor.getAmxNode(),
      processor.getEventType(),
      processor.getEvent(),
      processor.getMethod(),
      this._beforeEmbeddedCall);

    if (result != null)
    {
      result.then(resolve, reject);
    }
    else
    {
      resolve();
    }
  };
  // --------- /HandleTagInstancesStep --------- //

  // --------- HandleDispatchStep --------- //
  function HandleDispatchStep(amxEventProcessor)
  {
    this.Init(amxEventProcessor);
  }

  adf.mf.api.AdfObject.createSubclass(HandleDispatchStep, AmxEventProcessorStep, "HandleDispatchStep");

  HandleDispatchStep.prototype.run = function(resolve, reject)
  {
    var processor = this.GetProcessor();
    var evt = processor.getEvent();

    // Do not broadcast DOM events to the embedded side
    if (evt instanceof adf.mf.api.amx.DomEvent)
    {
      resolve();
    }
    else
    {
      adf.mf.api.invokeMethod(
        "oracle.maf.impl.amx.Dispatch",
        "processAmxEvent",
        processor.getAmxNode().getId(),
        processor.getAttributeName(),
        processor.getValue(),
        processor.getEventType(),
        evt,
        function(req, res)
        {
          // TODO: handle exceptions like the batch call does
          if (typeof res == "string" || res instanceof String)
          {
            adf.mf.api.amx.doNavigation(res);
          }

          resolve();
        },
        function(req, res)
        {
          reject(res);
        });
    }
  };
  // --------- /HandleDispatchStep --------- //

  // --------- HandleEventListenersStep --------- //
  function HandleEventListenersStep(amxEventProcessor)
  {
    this.Init(amxEventProcessor);
  }

  adf.mf.api.AdfObject.createSubclass(HandleEventListenersStep, AmxEventProcessorStep, "HandleEventListenersStep");

  HandleEventListenersStep.prototype.run = function(resolve, reject)
  {
    var processor = this.GetProcessor();
    var amxNode = processor.getAmxNode();
    var amxEvent = processor.getEvent();
    var amxEventType = processor.getEventType();
    var attParams     = [];
    var attParamTypes = [];

    attParams.push(amxEvent);
    attParamTypes.push(amxEvent[".type"]);

    var el = amxNode.getAttributeExpression(amxEventType + "Listener");

    if (el != null)
    {
      var args = [ el, attParams, null, attParamTypes ];

      // Add callbacks if invoking serially
      if (processor.isSerial())
      {
        args.push(resolve, reject);
      }

      adf.mf.api.amx.invokeEl.apply(null, args);

      // In batch mode we don't register callbacks from this function
      if (processor.isBatch())
      {
        resolve();
      }
    }
    else
    {
      resolve();
    }
  };
  // --------- /HandleEventListenersStep --------- //

  // --------- HandleFlushBatchRequestStep --------- //
  function HandleFlushBatchRequestStep(amxEventProcessor)
  {
    this.Init(amxEventProcessor);
  }

  adf.mf.api.AdfObject.createSubclass(
    HandleFlushBatchRequestStep,
    AmxEventProcessorStep,
    "HandleFlushBatchRequestStep");

  HandleFlushBatchRequestStep.prototype.run = function(resolve, reject)
  {
    // Notify the processor the batch request has been flushed
    this.GetProcessor().batchCompleted();
    adf.mf.util.flushBatchRequest(false, [ resolve ], [ reject ]);
  };
  // --------- /HandleFlushBatchRequestStep --------- //

  // --------- HandleValidationStep --------- //
  function HandleValidationStep(amxEventProcessor)
  {
    this.Init(amxEventProcessor);
  }

  adf.mf.api.AdfObject.createSubclass(HandleValidationStep, AmxEventProcessorStep, "HandleValidationStep");

  HandleValidationStep.prototype.requiresContext = function()
  {
    return this._requiresValidation();
  };

  HandleValidationStep.prototype.run = function(resolve, reject)
  {
    if (this._requiresValidation())
    {
      amx.requiredControlValueChanged(validationGroup);

      // The above function is not a promise (probably should be) so we can only just resolve
      resolve();
    }
    else
    {
      resolve();
    }
  };

  HandleValidationStep.prototype._requiresValidation = function()
  {
    var processor = this.GetProcessor();

    return processor.getValidationGroup() != null &&
      adf.mf.api.amx.isValueTrue(processor.getAmxNode().getAttribute("required"));
  };
  // --------- /HandleValidationStep --------- //

  /**
   * Internal function to invoke a clientListener.
   * @param {string} type the event type that occurred
   * @param {Object} amxEvent the AMX event that occurred
   * @param {adf.mf.api.amx.AmxNode} amxNode the AMX node of the component that triggered the event
   * @param {adf.mf.internal.amx.AmxTagInstance} clientListenerTagInstance the AMX tag instance of
   *  the clientListener
   */
  adf.mf.internal._processClientListener = function(
    type,
    amxEvent,
    amxNode,
    clientListenerTagInstance)
  {
    var method = clientListenerTagInstance.getAttribute("method");

    if (method != null && method.length > 0)
    {
      try
      {
        // Produce the client event object by copying over the AMX event properties to it.
        var timeStamp = (new Date()).getTime();
        var clientEvent =
        {
          "toString": function()
          {
            var result = "oracle.adfmf.amx.event.ClientEvent{ ";

            // Always start with these properties (in this order):

            // The ID of the AMX Node
            var value = clientEvent["amxNodeId"];
            if (value != null)
              result += "amxNodeId:\"" + value + "\"";
            else
            {
              value = clientEvent["amxNode"];
              if (value != null && value.getId)
                result += "amxNode.getId():\"" + value.getId() + "\"";
              else
                result += "(no amxNode.getId)";
            }

            // The type
            value = clientEvent["type"];
            if (value != null)
              result += ", type:\"" + clientEvent["type"] + "\"";

            // The timeStamp
            value = clientEvent["timeStamp"];
            if (value != null)
              result += ", timeStamp:\"" + clientEvent["timeStamp"] + "\"";

            // Print the rest of the properties (order not guaranteed):
            for (var key in clientEvent)
            {
              if (key != "amxNodeId" && key != "type" && key != "timeStamp")
              {
                value = clientEvent[key];
                var valueType = typeof value;
                if (valueType != "function")
                {
                  result += ", " + key + ":";
                  if (valueType == "string")
                    result += "\"";
                  result += value;
                  if (valueType == "string")
                    result += "\"";
                }
              }
            }

            result += " }";
            return result;
          }
        };

        for (var key in amxEvent)
        {
          clientEvent[key] = amxEvent[key];
        }

        // Add some additional properties if they don't overwrite ones of the same name from the
        // AMX event.
        if (clientEvent["type"] === undefined)
          clientEvent["type"] = type;

        if (clientEvent["amxNode"] === undefined)
          clientEvent["amxNode"] = amxNode;

        if (clientEvent["timeStamp"] === undefined)
          clientEvent["timeStamp"] = timeStamp;

        // Invoke the clientListener's method as a function.
        // If it is not already a function (e.g. a use case for MAX) then we
        // need to sandbox-convert it to a function via new Function:
        if (typeof method != "function")
          method = (new Function("return " + method))();

        method(clientEvent);
      }
      catch (problem)
      {
        // TODO: this needs to be translated and secured
        var message = "Problem with clientListener type=\"" + type + "\" method=\"" + method + "\":\n\n";
        alert(message + problem);
      }
    }
  };

  /**
   * Internal function to convert bidi types so both bidi and non-bidi equivalents are handled
   * with the same event.
   * @param {string} rawEventType the application developer-specified event type
   * @return {string} the resolved direction-explicit event type
   * @private
   */
  adf.mf.internal._getEventTypeResolvedForBidi = function(rawEventType)
  {
    var resolvedEventType = rawEventType;
    if (resolvedEventType == "swipeStart")
    {
      if (document.documentElement.dir == "rtl")
        resolvedEventType = "swipeRight";
      else
        resolvedEventType = "swipeLeft";
    }
    else if (resolvedEventType == "swipeEnd")
    {
      if (document.documentElement.dir == "rtl")
        resolvedEventType = "swipeLeft";
      else
        resolvedEventType = "swipeRight";
    }
    return resolvedEventType;
  };
})();
